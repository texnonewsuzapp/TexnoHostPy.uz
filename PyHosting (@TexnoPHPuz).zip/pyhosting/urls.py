from django.contrib import admin
from django.urls import path, re_path, include
from django.conf import settings
from django.views.generic import TemplateView
from apps.accounts.views import AuthPageView

urlpatterns = [
    path('admin/', admin.site.urls),

    path('', TemplateView.as_view(template_name='index.html'), name='home'),
    re_path(r'^auth(?:/.*)?$', AuthPageView.as_view(), name='auth'),
    re_path(r'^app(?:/.*)?$', TemplateView.as_view(template_name='app.html'), name='app_spa'),

    path('panel/login/', TemplateView.as_view(template_name='panel_login.html'), name='panel_login'),
    re_path(r'^panel(?:/.*)?$', TemplateView.as_view(template_name='panel.html'), name='panel_spa'),

    path('api/auth/', include('apps.accounts.urls')),
    path('api/files/', include('apps.filemanager.urls')),
    path('api/databases/', include('apps.filemanager.database_urls')),
    path('api/bots/', include('apps.botengine.urls')),
    path('api/dashboard/', include('apps.dashboard.urls')),
    path('api/notifications/', include('apps.notifications.urls')),
    path('api/admin/', include('apps.adminpanel.urls')),
]

from django.views.static import serve as static_serve
from django.contrib.staticfiles import views as staticfiles_views
from django.conf.urls.static import static

def guaranteed_static_serve(request, path):
    """
    Guaranteed static asset fallback serving for Daphne ASGI on Render.
    Checks STATIC_ROOT first, falls back to project static directory,
    and then queries staticfiles finders.
    """
    if settings.STATIC_ROOT.exists() and (settings.STATIC_ROOT / path).exists():
        return static_serve(request, path, document_root=str(settings.STATIC_ROOT))
    if (settings.BASE_DIR / 'static' / path).exists():
        return static_serve(request, path, document_root=str(settings.BASE_DIR / 'static'))
    return staticfiles_views.serve(request, path, insecure=True)

urlpatterns += [
    re_path(r'^static/(?P<path>.*)$', guaranteed_static_serve, name='static_files'),
]

if settings.MEDIA_URL and settings.MEDIA_ROOT:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

