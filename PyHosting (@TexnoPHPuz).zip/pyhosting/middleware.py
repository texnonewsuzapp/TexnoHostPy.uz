"""
PyHosting Enterprise Cybersecurity Middleware
Implements HTTP transport hardening, Content Security Policy (CSP),
Anti-DDoS rate-limiting, Database resilience, and zero-trust framing defense.
"""

import time
import logging
from django.http import JsonResponse, HttpResponse
from django.core.cache import cache

logger = logging.getLogger(__name__)

def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0].strip()
    else:
        ip = request.META.get('REMOTE_ADDR', '')
    return ip or '127.0.0.1'

class DDoSProtectionMiddleware:
    """
    High-performance Anti-DDoS and Traffic Flood Limiter.
    Shields backend resources and database against spam, brute force, and flood attacks.
    """
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        path = request.path

        if path.startswith(('/static/', '/media/', '/favicon.ico', '/robots.txt')):
            return self.get_response(request)

        ip = get_client_ip(request)

        is_auth = path.startswith(('/auth/', '/api/accounts/login/', '/api/accounts/register/', '/api/accounts/token/'))
        limit = 30 if is_auth else 120
        window = 30

        cache_key = f"rl_{'auth_' if is_auth else 'gen_'}{ip}"

        try:
            req_count = cache.get(cache_key, 0)
            if req_count >= limit:
                logger.warning(f"[🚨 Anti-DDoS Blok] IP: {ip} so'rovlar chegarasidan oshdi ({req_count}/{limit})! Path: {path}")
                if path.startswith('/api/'):
                    return JsonResponse({
                        'error': "Juda ko'p so'rov yuborildi (Anti-DDoS Himoyasi). Iltimos, 15 soniya kuting.",
                        'retry_after': 15
                    }, status=429)
                return HttpResponse(
                    self.render_rate_limit_page(),
                    status=429,
                    content_type='text/html; charset=utf-8'
                )

            if req_count == 0:
                cache.set(cache_key, 1, timeout=window)
            else:
                try:
                    cache.incr(cache_key)
                except Exception:
                    cache.set(cache_key, req_count + 1, timeout=window)
        except Exception as e:
            logger.debug(f"Rate limit cache error: {e}")

        return self.get_response(request)

    def render_rate_limit_page(self) -> str:
        return """<!DOCTYPE html>
<html lang="uz">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#0d1117">
  <title>PyHosting — Anti-DDoS Himoyasi</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { background: #0d1117; color: #c9d1d9; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 1.5rem; }
    .card { background: #161b22; border: 1px solid #30363d; border-radius: 16px; padding: 2.5rem 2rem; max-width: 480px; text-align: center; box-shadow: 0 16px 40px rgba(0,0,0,0.5); }
    .icon { font-size: 3.5rem; margin-bottom: 1.25rem; }
    h1 { color: #58a6ff; font-size: 1.5rem; font-weight: 700; margin-bottom: 0.75rem; }
    p { font-size: 0.95rem; color: #8b949e; line-height: 1.6; margin-bottom: 1.5rem; }
    .badge { display: inline-block; background: #21262d; border: 1px solid #f0883e; color: #f0883e; padding: 0.5rem 1.25rem; border-radius: 30px; font-size: 0.9rem; font-weight: 600; }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">🛡️</div>
    <h1>Anti-DDoS Himoyasi Faollashdi</h1>
    <p>Sizning tarmog'ingizdan qisqa vaqt ichida juda ko'p tezkor so'rovlar yuborildi. Server va botlar barqarorligini asrash uchun so'rovlar vaqtincha cheklandi.</p>
    <div class="badge">Iltimos, 15 soniya kuting va sahifani yangilang</div>
  </div>
</body>
</html>"""

class DatabaseResilienceMiddleware:
    """
    Resilience layer for PostgreSQL/Supabase database connections.
    If a transient network disconnect occurs under heavy traffic,
    gracefully recycles connections and retries once, preventing 500 crashes.
    """
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        from django.db import OperationalError, connections
        try:
            return self.get_response(request)
        except OperationalError as err:
            logger.warning(f"[DB Resilience] OperationalError ushlandi: {err}. Ulanishlar yangilanmoqda...")
            try:
                connections.close_all()
                return self.get_response(request)
            except Exception as final_err:
                logger.error(f"[DB Resilience] Qayta ulanish ham xato berdi: {final_err}")
                if request.path.startswith('/api/'):
                    return JsonResponse({
                        'error': "Serverda yuqori yuklama aniqlandi. Iltimos, bir necha soniyadan so'ng qayta urinib ko'ring.",
                        'status': 503
                    }, status=503)
                return HttpResponse(
                    self.render_overload_page(),
                    status=503,
                    content_type='text/html; charset=utf-8'
                )

    def render_overload_page(self) -> str:
        return """<!DOCTYPE html>
<html lang="uz">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#0d1117">
  <title>PyHosting — Vaqtinchalik Yuklama</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { background: #0d1117; color: #c9d1d9; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 1.5rem; }
    .card { background: #161b22; border: 1px solid #30363d; border-radius: 16px; padding: 2.5rem 2rem; max-width: 480px; text-align: center; box-shadow: 0 16px 40px rgba(0,0,0,0.5); }
    .icon { font-size: 3.5rem; margin-bottom: 1.25rem; }
    h1 { color: #f0883e; font-size: 1.5rem; font-weight: 700; margin-bottom: 0.75rem; }
    p { font-size: 0.95rem; color: #8b949e; line-height: 1.6; margin-bottom: 1.5rem; }
    .btn { display: inline-block; background: #238636; color: #ffffff; text-decoration: none; padding: 0.6rem 1.5rem; border-radius: 8px; font-size: 0.95rem; font-weight: 600; cursor: pointer; border: none; }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">⚡</div>
    <h1>Serverda Yuqori Yuklama</h1>
    <p>Hozirda saytga juda ko'p foydalanuvchilar kirganligi sababli ma'lumotlar bazasida qisqa muddatli tirbandlik yuz berdi. Hech qanday ma'lumot yo'qolgani yo'q.</p>
    <button class="btn" onclick="location.reload()">Sahifani yangilash</button>
  </div>
</body>
</html>"""

class SecurityHardeningMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        csp_directives = [
            "default-src 'self'",
            "script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net https://accounts.google.com https://apis.google.com https://challenges.cloudflare.com",
            "style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://fonts.googleapis.com https://cdn.jsdelivr.net https://accounts.google.com",
            "font-src 'self' https://cdnjs.cloudflare.com https://fonts.gstatic.com data:",
            "img-src 'self' data: https: https://lh3.googleusercontent.com",
            "connect-src 'self' ws: wss: https://accounts.google.com https://oauth2.googleapis.com https://www.googleapis.com https://challenges.cloudflare.com",
            "frame-src 'self' https://accounts.google.com https://challenges.cloudflare.com",
            "frame-ancestors 'none'",
            "object-src 'none'",
            "base-uri 'self'",
            "form-action 'self' https://accounts.google.com",
        ]
        response['Content-Security-Policy'] = "; ".join(csp_directives)

        response['Permissions-Policy'] = "camera=(), microphone=(), geolocation=(), payment=(), usb=(), display-capture=()"

        response['X-Content-Type-Options'] = "nosniff"

        response['X-Frame-Options'] = "DENY"

        response['Referrer-Policy'] = "strict-origin-when-cross-origin"

        response['X-Permitted-Cross-Domain-Policies'] = "none"

        response['Cross-Origin-Opener-Policy'] = "same-origin-allow-popups"

        if request.path.startswith('/api/'):
            response['Cache-Control'] = "no-store, no-cache, must-revalidate, max-age=0"
            response['Pragma'] = "no-cache"

        return response
