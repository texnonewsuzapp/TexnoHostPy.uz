// PyHosting - Terminal Real-Time Log Viewer with Live Telemetry HUD
const LogsViewer = {
  container: null,
  fileId: null,
  wsStream: null,
  autoScroll: true,
  logsHistory: [],
  currentFilter: 'ALL',
  pollingInterval: null,
  telemetryInterval: null,
  cpuHistory: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  autoRestart: true,
  restartCount: 0,

  async render(targetEl, params) {
    this.container = targetEl;
    this.fileId = params.fileId;
    this.autoScroll = true;
    this.logsHistory = [];
    this.currentFilter = 'ALL';
    this.cpuHistory = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

    if (this.telemetryInterval) {
      clearInterval(this.telemetryInterval);
      this.telemetryInterval = null;
    }
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
    if (this.wsStream) {
      this.wsStream.close();
      this.wsStream = null;
    }

    this.container.innerHTML = `
      <div class="terminal-wrapper">
        <div class="terminal-header">
          <div class="terminal-title">
            <div class="window-dots">
              <span class="window-dot dot-red"></span>
              <span class="window-dot dot-yellow"></span>
              <span class="window-dot dot-green"></span>
            </div>
            <button class="btn btn-ghost btn-sm" onclick="Router.navigate('/files')" style="display: inline-flex; align-items: center; gap: 6px;">
              ${Icons.arrowLeft(14)} <span>Fayllar</span>
            </button>
            <div style="display: flex; align-items: center; gap: 8px;">
              <span style="display: inline-flex; align-items: center;">${Icons.terminal(16, 'var(--accent-blue)')}</span>
              <span id="term-file-name" style="font-weight: 700; font-family: var(--font-mono);">Bot #${this.fileId}</span>
            </div>
            <span class="status-pill status-stopped" id="term-bot-status" style="font-size: 11px;">
              <span class="status-dot"></span> Yuklanmoqda...
            </span>
          </div>

          <div class="terminal-controls">
            <div class="terminal-filter-tabs" style="display: flex; gap: 4px; background: rgba(255,255,255,0.04); padding: 3px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle); margin-right: 6px;">
              <button class="filter-tab-btn active" data-filter="ALL" onclick="LogsViewer.setFilter('ALL')">Hammasi</button>
              <button class="filter-tab-btn" data-filter="ERROR" onclick="LogsViewer.setFilter('ERROR')">Xatoliklar</button>
              <button class="filter-tab-btn" data-filter="INFO" onclick="LogsViewer.setFilter('INFO')">Info</button>
            </div>
            <button class="btn btn-secondary btn-sm" id="term-toggle-btn" onclick="LogsViewer.toggleBotState()" style="display: inline-flex; align-items: center; gap: 6px;">
              ${Icons.play(12)} <span>Boshqarish</span>
            </button>
            <button class="btn btn-ghost btn-sm" onclick="LogsViewer.clearLogs()" title="Terminalni tozalash" style="display: inline-flex; align-items: center; gap: 5px;">
              ${Icons.trash(14)} <span>Tozalash</span>
            </button>
            <button class="btn btn-ghost btn-sm" onclick="LogsViewer.downloadLogs()" title="Loglarni yuklab olish" style="display: inline-flex; align-items: center; gap: 5px;">
              ${Icons.download(14)} <span>Yuklab olish</span>
            </button>
            <button class="btn btn-secondary btn-sm" onclick="Router.navigate('/editor/' + LogsViewer.fileId)" style="display: inline-flex; align-items: center; gap: 6px;">
              ${Icons.edit(14)} <span>Kod</span>
            </button>
          </div>
        </div>

        <!-- Live Telemetry HUD Strip (Liquid Glass) -->
        <div class="terminal-telemetry-hud" id="term-telemetry-hud">
          <div class="hud-metrics-group">
            <!-- CPU Sparkline Monitor -->
            <div class="hud-metric-card" id="hud-cpu-card" title="vCPU Limiti: 0.25 (25%)">
              <div class="hud-metric-header">
                <span style="display: inline-flex; align-items: center;">${Icons.cpu(13, 'var(--accent-blue)')}</span>
                <span>CPU</span>
                <span class="hud-metric-value" id="hud-cpu-val">0.0%</span>
              </div>
              <div class="hud-sparkline-box">
                <svg id="hud-cpu-sparkline" viewBox="0 0 100 20" preserveAspectRatio="none">
                  <path id="hud-sparkline-area" d="M 0 20 L 100 20 Z" fill="rgba(56, 139, 253, 0.2)"></path>
                  <path id="hud-sparkline-path" d="M 0 20 L 100 20" fill="none" stroke="var(--accent-blue)" stroke-width="2" stroke-linecap="round"></path>
                </svg>
              </div>
            </div>

            <!-- RAM Gauge Monitor -->
            <div class="hud-metric-card" id="hud-ram-card" title="RAM Limiti: 128 MB">
              <div class="hud-metric-header">
                <span style="display: inline-flex; align-items: center;">${Icons.ram(13, 'var(--accent-cyan)')}</span>
                <span>RAM</span>
                <span class="hud-metric-value" id="hud-ram-val">0.0 / 128 MB</span>
              </div>
              <div class="hud-progress-bar">
                <div class="hud-progress-fill" id="hud-ram-fill" style="width: 0%;"></div>
              </div>
            </div>

            <!-- Uptime & Restarts -->
            <div class="hud-meta-card">
              <div class="hud-meta-item" title="Bot uzluksiz ishlash vaqti">
                <span style="color: var(--text-muted); display: inline-flex; align-items: center;">${Icons.clock(12)}</span>
                <span style="color: var(--text-secondary);">Uptime:</span>
                <span class="hud-meta-val" id="hud-uptime-val">--</span>
              </div>
              <div class="hud-meta-item" title="Watchdog qayta ishga tushirishlar soni">
                <span style="color: var(--text-muted); display: inline-flex; align-items: center;">${Icons.refresh(12)}</span>
                <span style="color: var(--text-secondary);">Tiklanishlar:</span>
                <span class="hud-meta-val" id="hud-restarts-val" style="color: var(--accent-cyan);">0</span>
              </div>
            </div>
          </div>

          <!-- Watchdog & Quick Actions -->
          <div class="hud-actions-group">
            <!-- Auto-Restart Toggle Switch -->
            <button class="hud-toggle-btn active" id="hud-autorestart-btn" onclick="LogsViewer.toggleAutoRestart()" title="Avtomatik Qayta Ishga Tushirish (Crash Watchdog)">
              <span id="hud-autorestart-icon" style="display: inline-flex; align-items: center;">${Icons.shieldCheck(14)}</span>
              <span>Auto-Restart:</span>
              <span id="hud-autorestart-status">FAOL</span>
            </button>

            <!-- .env Button -->
            <button class="btn btn-secondary btn-sm hud-action-btn" onclick="Modal.openEnvManager(LogsViewer.fileId)" title="Maxfiy Muhit O'zgaruvchilari" style="display: inline-flex; align-items: center; gap: 5px;">
              ${Icons.key(14, 'var(--accent-yellow)')} <span>.env</span>
            </button>

            <!-- Pip Button -->
            <button class="btn btn-secondary btn-sm hud-action-btn" onclick="Modal.openPipManager(LogsViewer.fileId)" title="Pip Paketlar Menejeri" style="display: inline-flex; align-items: center; gap: 5px;">
              ${Icons.package(14, 'var(--accent-blue)')} <span>Pip</span>
            </button>
          </div>
        </div>

        <div class="terminal-body" id="term-body" onscroll="LogsViewer.handleScroll()">
          <div class="log-line">
            <span class="log-time">${new Date().toTimeString().slice(0, 8)}</span>
            <span class="log-badge INFO">INFO</span>
            <span class="log-text" style="color: var(--accent-blue);">Py Hosting terminaliga ulanilmoqda...</span>
          </div>
        </div>

        <button class="terminal-scroll-btn" id="term-scroll-down-btn" onclick="LogsViewer.scrollToBottom(true)" style="display: inline-flex; align-items: center; gap: 6px;">
          ${Icons.chevronDown(14)} <span>Eng pastga tushish</span>
        </button>
      </div>
    `;

    await this.initStream();
  },

  async initStream() {
    // 1. Fetch file info, status & telemetry
    try {
      const statusData = await API.get(`/api/bots/${this.fileId}/status/`);
      this.updateStatus(statusData.status);
      const nameEl = document.getElementById('term-file-name');
      if (nameEl) nameEl.textContent = statusData.file_name || `Bot #${this.fileId}`;
    } catch {}

    try {
      const telemetryData = await API.get(`/api/bots/${this.fileId}/telemetry/`);
      this.updateTelemetry(telemetryData);
    } catch {}

    // 2. Close previous stream if exists
    if (this.wsStream) {
      this.wsStream.close();
    }
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
    if (this.telemetryInterval) {
      clearInterval(this.telemetryInterval);
      this.telemetryInterval = null;
    }

    // 3. Connect WebSocket
    this.wsStream = new BotLogsStream(this.fileId, {
      onLog: (data) => {
        this.appendLog(data.line, data.level, data.timestamp);
      },
      onStatus: (data) => {
        this.updateStatus(data.status);
        if (data.status === 'running') {
          this.fetchTelemetryFallback();
        }
      },
      onStats: (stats) => {
        this.updateTelemetry(stats);
      },
      onSystem: (msg) => {
        this.appendLog(msg, 'INFO');
      },
      onClose: () => {
        // Fallback polling if WS closed
        if (!this.pollingInterval) {
          this.pollingInterval = setInterval(() => this.fetchLogsFallback(), 3000);
        }
      }
    });

    this.wsStream.connect();

    // 4. Start periodic Telemetry streaming (every 2.5s)
    this.telemetryInterval = setInterval(() => {
      if (this.wsStream && this.wsStream.socket && this.wsStream.socket.readyState === WebSocket.OPEN) {
        this.wsStream.getStats();
      } else {
        this.fetchTelemetryFallback();
      }
    }, 2500);
  },

  updateTelemetry(stats) {
    if (!stats) return;

    // CPU Percent & Sparkline
    const cpuVal = stats.cpu_percent || 0.0;
    const cpuValEl = document.getElementById('hud-cpu-val');
    if (cpuValEl) {
      cpuValEl.textContent = `${cpuVal.toFixed(1)}%`;
      if (cpuVal > 20) {
        cpuValEl.style.color = 'var(--status-crashed)';
      } else if (cpuVal > 10) {
        cpuValEl.style.color = 'var(--status-starting)';
      } else {
        cpuValEl.style.color = 'var(--text-primary)';
      }
    }

    this.cpuHistory.push(cpuVal);
    if (this.cpuHistory.length > 15) {
      this.cpuHistory.shift();
    }
    this.renderCpuSparkline();

    // RAM MB & Fill Bar
    const memMb = stats.memory_mb || 0.0;
    const maxMb = stats.max_memory_mb || 128.0;
    const ramPct = Math.min((memMb / maxMb) * 100, 100);
    const ramValEl = document.getElementById('hud-ram-val');
    const ramFillEl = document.getElementById('hud-ram-fill');

    if (ramValEl) {
      ramValEl.textContent = `${memMb.toFixed(1)} / ${maxMb} MB`;
    }

    if (ramFillEl) {
      ramFillEl.style.width = `${ramPct}%`;
      if (ramPct > 85) {
        ramFillEl.style.background = 'var(--status-crashed)';
      } else if (ramPct > 65) {
        ramFillEl.style.background = 'var(--status-starting)';
      } else {
        ramFillEl.style.background = 'var(--accent-cyan)';
      }
    }

    // Uptime & Restarts
    const uptimeEl = document.getElementById('hud-uptime-val');
    if (uptimeEl) {
      if (stats.status === 'running' && stats.uptime_seconds) {
        uptimeEl.textContent = this.formatUptime(stats.uptime_seconds);
      } else {
        uptimeEl.textContent = '--';
      }
    }

    const restartsEl = document.getElementById('hud-restarts-val');
    if (restartsEl) {
      this.restartCount = stats.restart_count || 0;
      restartsEl.textContent = this.restartCount;
    }

    // Auto-Restart status
    if (typeof stats.auto_restart === 'boolean') {
      this.autoRestart = stats.auto_restart;
      this.updateAutoRestartBtn(this.autoRestart);
    }

    // Status sync
    if (stats.status) {
      this.updateStatus(stats.status);
    }
  },

  renderCpuSparkline() {
    const pathEl = document.getElementById('hud-sparkline-path');
    const areaEl = document.getElementById('hud-sparkline-area');
    if (!pathEl || !areaEl) return;

    const data = this.cpuHistory;
    const n = data.length;
    if (n < 2) return;

    // Max limit is 25% vCPU
    const maxVal = 25.0;
    const coords = data.map((val, idx) => {
      const x = ((idx / (n - 1)) * 100).toFixed(1);
      const normalized = Math.min(Math.max(val / maxVal, 0), 1);
      const y = (19 - (normalized * 17)).toFixed(1);
      return `${x} ${y}`;
    });

    const pathD = `M ${coords.join(' L ')}`;
    const areaD = `M ${coords.join(' L ')} L 100 20 L 0 20 Z`;

    pathEl.setAttribute('d', pathD);
    areaEl.setAttribute('d', areaD);
  },

  updateAutoRestartBtn(isActive) {
    const btn = document.getElementById('hud-autorestart-btn');
    const statusText = document.getElementById('hud-autorestart-status');
    const iconEl = document.getElementById('hud-autorestart-icon');
    if (!btn || !statusText) return;

    if (isActive) {
      btn.className = 'hud-toggle-btn active';
      statusText.textContent = 'FAOL';
      if (iconEl) iconEl.innerHTML = Icons.shieldCheck(14);
    } else {
      btn.className = 'hud-toggle-btn';
      statusText.textContent = "O'CHIQ";
      if (iconEl) iconEl.innerHTML = Icons.shield(14);
    }
  },

  async toggleAutoRestart() {
    try {
      const res = await API.post(`/api/bots/${this.fileId}/auto-restart/`);
      this.autoRestart = res.auto_restart;
      this.updateAutoRestartBtn(this.autoRestart);

      if (this.autoRestart) {
        Toast.success("Avtomatik qayta ishga tushirish (Watchdog) faollashtirildi!");
      } else {
        Toast.info("Avtomatik qayta ishga tushirish o'chirildi.");
      }
    } catch (e) {
      Toast.error("Xatolik: " + e.message);
    }
  },

  formatUptime(sec) {
    if (!sec || sec <= 0) return "0s";
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    if (h > 0) return `${h}h ${m}m ${s}s`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
  },

  async fetchTelemetryFallback() {
    try {
      const data = await API.get(`/api/bots/${this.fileId}/telemetry/`);
      this.updateTelemetry(data);
    } catch {}
  },

  updateStatus(status) {
    const statusEl = document.getElementById('term-bot-status');
    const toggleBtn = document.getElementById('term-toggle-btn');
    if (!statusEl) return;

    statusEl.className = `status-pill status-${status}`;
    const statusText = status === 'running' ? 'Ishlayapti' : status === 'crashed' ? 'Xatolik' : 'To\'xtatilgan';
    statusEl.innerHTML = `<span class="status-dot"></span> ${statusText}`;

    if (toggleBtn) {
      if (status === 'running') {
        toggleBtn.className = 'btn btn-danger btn-sm';
        toggleBtn.innerHTML = `${Icons.square(11)} <span>To'xtatish</span>`;
      } else {
        toggleBtn.className = 'btn btn-success btn-sm';
        toggleBtn.innerHTML = `${Icons.play(11)} <span>Ishga tushirish</span>`;
      }
    }
  },

  async toggleBotState() {
    const statusEl = document.getElementById('term-bot-status');
    const isRunning = statusEl && statusEl.classList.contains('status-running');

    if (isRunning) {
      try {
        Toast.info("Bot to'xtatilmoqda...");
        await API.post(`/api/bots/${this.fileId}/stop/`);
        this.updateStatus('stopped');
        Toast.success("Bot to'xtatildi");
      } catch (e) {
        Toast.error(e.message);
      }
    } else {
      try {
        Toast.info("Bot ishga tushirilmoqda...");
        await API.post(`/api/bots/${this.fileId}/start/`);
        this.updateStatus('running');
        Toast.success("Bot ishga tushdi!");
      } catch (e) {
        Toast.error(e.message);
      }
    }
  },

  appendLog(line, level = 'INFO', timestamp = null) {
    const termBody = document.getElementById('term-body');
    if (!termBody) return;

    const timeStr = timestamp || new Date().toTimeString().slice(0, 8);
    this.logsHistory.push({ time: timeStr, level, text: line });

    const isErr = level === 'ERROR' || line.toLowerCase().includes('traceback') || line.toLowerCase().includes('error:');
    const actualLevel = isErr ? 'ERROR' : level;

    const logDiv = document.createElement('div');
    logDiv.className = 'log-line';
    logDiv.dataset.level = actualLevel;

    if (this.currentFilter !== 'ALL' && this.currentFilter !== actualLevel) {
      logDiv.style.display = 'none';
    }

    logDiv.innerHTML = `
      <span class="log-time">${timeStr}</span>
      <span class="log-badge ${actualLevel}">${actualLevel}</span>
      <span class="log-text ${isErr ? 'error-text' : ''}">${this.escapeHtml(line)}</span>
    `;

    termBody.appendChild(logDiv);

    if (this.autoScroll) {
      this.scrollToBottom();
    }
  },

  setFilter(filter) {
    this.currentFilter = filter;
    const filterBtns = document.querySelectorAll('.filter-tab-btn');
    filterBtns.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.filter === filter);
    });

    const lines = document.querySelectorAll('.log-line');
    lines.forEach(line => {
      const lineLevel = line.dataset.level || 'INFO';
      if (filter === 'ALL' || lineLevel === filter) {
        line.style.display = 'flex';
      } else {
        line.style.display = 'none';
      }
    });

    if (this.autoScroll) {
      this.scrollToBottom();
    }
  },

  handleScroll() {
    const termBody = document.getElementById('term-body');
    const scrollBtn = document.getElementById('term-scroll-down-btn');
    if (!termBody || !scrollBtn) return;

    const threshold = 40;
    const isAtBottom = termBody.scrollHeight - termBody.scrollTop - termBody.clientHeight <= threshold;

    this.autoScroll = isAtBottom;
    scrollBtn.classList.toggle('active', !isAtBottom);
  },

  scrollToBottom(force = false) {
    const termBody = document.getElementById('term-body');
    if (termBody) {
      termBody.scrollTop = termBody.scrollHeight;
      if (force) {
        this.autoScroll = true;
        const scrollBtn = document.getElementById('term-scroll-down-btn');
        if (scrollBtn) scrollBtn.classList.remove('active');
      }
    }
  },

  clearLogs() {
    const termBody = document.getElementById('term-body');
    if (termBody) {
      termBody.innerHTML = '';
      this.logsHistory = [];
      Toast.info("Loglar tozalandi");
    }
  },

  downloadLogs() {
    if (this.logsHistory.length === 0) {
      Toast.info("Yuklab olish uchun loglar mavjud emas");
      return;
    }
    const plainLines = this.logsHistory.map(l => `[${l.time}] [${l.level}] ${l.text}`);
    const blob = new Blob([plainLines.join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bot_${this.fileId}_logs.txt`;
    a.click();
    URL.revokeObjectURL(url);
    Toast.success("Log fayli yuklab olindi");
  },

  async fetchLogsFallback() {
    try {
      const data = await API.get(`/api/bots/${this.fileId}/logs/?limit=50`);
      if (data.logs && data.logs.length) {
        const termBody = document.getElementById('term-body');
        if (!termBody) return;
        termBody.innerHTML = '';
        data.logs.forEach(l => {
          this.appendLog(l.log_line, l.level, l.timestamp_formatted);
        });
      }
    } catch {}
  },

  destroy() {
    if (this.telemetryInterval) {
      clearInterval(this.telemetryInterval);
      this.telemetryInterval = null;
    }
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
    if (this.wsStream) {
      this.wsStream.close();
      this.wsStream = null;
    }
  },

  escapeHtml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
};

window.LogsViewer = LogsViewer;
