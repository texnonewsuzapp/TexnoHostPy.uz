// PyHosting.uz - Monaco Code Editor Integration
const CodeEditor = {
  container: null,
  monacoInstance: null,
  fileId: null,
  fileData: null,
  isDirty: false,

  async render(targetEl, params) {
    this.container = targetEl;
    this.fileId = params.fileId;
    this.isDirty = false;

    this.container.innerHTML = `
      <div class="editor-wrapper">
        <div class="editor-toolbar">
          <div class="editor-file-info">
            <button class="btn btn-ghost btn-sm" onclick="Router.navigate('/files')" style="display: inline-flex; align-items: center; gap: 6px;">
              ${Icons.arrowLeft(14)} <span>Fayllar</span>
            </button>
            <div style="display: flex; align-items: center; gap: 8px;">
              <span id="editor-file-icon" style="display: inline-flex; align-items: center;">${Icons.python(16)}</span>
              <span class="editor-file-title" id="editor-file-name">Yuklanmoqda...</span>
              <span class="editor-dirty-indicator" id="editor-dirty-indicator" title="Saqlanmagan o'zgarishlar"></span>
            </div>
            <span class="status-pill status-stopped" id="editor-bot-status" style="font-size: 11px;">
              <span class="status-dot"></span> To'xtagan
            </span>
          </div>

          <div class="editor-toolbar-actions">
            <button class="btn btn-secondary btn-sm" style="display: inline-flex; align-items: center; gap: 6px;" onclick="Router.navigate('/logs/' + CodeEditor.fileId)">
              ${Icons.terminal(14)} <span>Loglar</span>
            </button>
            <button class="btn btn-secondary btn-sm" id="editor-save-btn" style="display: inline-flex; align-items: center; gap: 6px;" onclick="CodeEditor.save()">
              ${Icons.save(14)} <span>Saqlash</span>
            </button>
            <button class="btn btn-success btn-sm" id="editor-run-btn" style="display: inline-flex; align-items: center; gap: 6px;" onclick="CodeEditor.saveAndRun()">
              ${Icons.play(12)} <span>Ishga tushirish</span>
            </button>
          </div>
        </div>

        <div class="editor-info-banner" style="background: rgba(56, 139, 253, 0.08); border-bottom: 1px solid rgba(56, 139, 253, 0.2); padding: 7px 16px; font-size: 12px; display: flex; align-items: center; justify-content: space-between; color: var(--text-secondary);">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="display: inline-flex; align-items: center; justify-content: center; width: 18px; height: 18px; border-radius: 50%; background: rgba(56, 139, 253, 0.2); color: var(--accent-blue); font-size: 11px; font-weight: 700;">i</span>
            <span>Serverda faqat <strong style="color: var(--accent-blue);">telebot</strong> (pyTelegramBotAPI) va <strong style="color: var(--accent-blue);">requests</strong> kutubxonalari qo'llab-quvvatlanadi (O'rtacha RAM: 20MB).</span>
          </div>
          <span style="font-size: 11px; color: var(--accent-green); font-weight: 600;">🟢 24/7 Barqaror Rejim</span>
        </div>

        <div class="monaco-container" id="monaco-host-element"></div>

        <div class="editor-statusbar">
          <div style="display: flex; gap: 16px;">
            <span id="editor-cursor-pos">Ln 1, Col 1</span>
            <span>UTF-8</span>
            <span>Spaces: 4</span>
          </div>
          <div>
            <span id="editor-mode-label">Python 3.11</span>
          </div>
        </div>
      </div>
    `;

    await this.loadFile();
  },

  async loadFile() {
    try {
      const data = await API.get(`/api/files/${this.fileId}/content/`);
      this.fileData = data;

      document.getElementById('editor-file-name').textContent = data.name;
      const fileIconEl = document.getElementById('editor-file-icon');
      if (fileIconEl) {
        fileIconEl.innerHTML = data.name.endsWith('.py') ? Icons.python(16) : Icons.fileCode(16);
      }

      const statusEl = document.getElementById('editor-bot-status');
      if (statusEl) {
        statusEl.className = `status-pill status-${data.bot_status || 'stopped'}`;
        statusEl.innerHTML = `<span class="status-dot"></span> ${data.bot_status === 'running' ? 'Ishlayapti' : 'To\'xtagan'}`;
      }

      await this.initMonaco(data.content, data.name.endsWith('.py') ? 'python' : 'plaintext');
    } catch (err) {
      Toast.error("Faylni yuklashda xatolik: " + err.message);
    }
  },

  async initMonaco(content, language) {
    const hostEl = document.getElementById('monaco-host-element');
    if (!hostEl) return;

    const createEditor = () => {
      if (this.monacoInstance) {
        this.monacoInstance.dispose();
      }

      const isMobile = window.innerWidth <= 768;
      const initialTheme = (window.Theme && typeof window.Theme.get === 'function' && window.Theme.get() === 'light') ? 'vs' : 'vs-dark';
      this.monacoInstance = monaco.editor.create(hostEl, {
        value: content,
        language: language,
        theme: initialTheme,
        automaticLayout: true,
        wordWrap: 'on',
        fontSize: isMobile ? 12.5 : 14,
        fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
        tabSize: 4,
        insertSpaces: true,
        minimap: { enabled: !isMobile, side: 'right' },
        lineNumbers: 'on',
        renderWhitespace: 'selection',
        scrollBeyondLastLine: false,
        padding: { top: 10, bottom: 10 }
      });

      this.monacoInstance.onDidChangeModelContent(() => {
        this.setDirty(true);
      });

      this.monacoInstance.onDidChangeCursorPosition((e) => {
        const posEl = document.getElementById('editor-cursor-pos');
        if (posEl) {
          posEl.textContent = `Ln ${e.position.lineNumber}, Col ${e.position.column}`;
        }
      });

      // Bind Ctrl+S shortcut
      this.monacoInstance.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, () => {
        this.save();
      });
    };

    if (window.monaco) {
      createEditor();
    } else {
      // Load Monaco AMD loader
      if (!window.require) {
        const loaderScript = document.createElement('script');
        loaderScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs/loader.min.js';
        loaderScript.onload = () => {
          require.config({ paths: { vs: 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs' } });
          require(['vs/editor/editor.main'], () => {
            createEditor();
          });
        };
        document.body.appendChild(loaderScript);
      } else {
        require(['vs/editor/editor.main'], () => {
          createEditor();
        });
      }
    }
  },

  setDirty(dirty) {
    this.isDirty = dirty;
    const dirtyInd = document.getElementById('editor-dirty-indicator');
    if (dirtyInd) {
      dirtyInd.classList.toggle('active', dirty);
    }
  },

  async save() {
    if (!this.monacoInstance) return;
    const content = this.monacoInstance.getValue();
    const saveBtn = document.getElementById('editor-save-btn');
    if (saveBtn) saveBtn.innerHTML = `${Icons.refresh(14)} <span>Saqlanmoqda...</span>`;

    try {
      await API.patch(`/api/files/${this.fileId}/content/`, { content });
      this.setDirty(false);
      Toast.success("Fayl saqlandi!");
    } catch (err) {
      Toast.error("Saqlashda xatolik: " + err.message);
    } finally {
      if (saveBtn) saveBtn.innerHTML = `${Icons.save(14)} <span>Saqlash (Ctrl+S)</span>`;
    }
  },

  async saveAndRun() {
    await this.save();
    try {
      Toast.info("Bot ishga tushirilmoqda...");
      const res = await API.post(`/api/bots/${this.fileId}/start/`);
      Toast.success(res.message);

      const statusEl = document.getElementById('editor-bot-status');
      if (statusEl) {
        statusEl.className = 'status-pill status-running';
        statusEl.innerHTML = '<span class="status-dot"></span> Ishlayapti';
      }

      // Navigate to live logs view so the user can see execution
      setTimeout(() => {
        Router.navigate(`/logs/${this.fileId}`);
      }, 600);
    } catch (err) {
      Toast.error("Ishga tushirishda xatolik: " + err.message);
    }
  }
};

window.CodeEditor = CodeEditor;
