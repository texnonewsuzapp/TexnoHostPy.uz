// PyHosting.uz - Advanced Two-Panel File Manager with Folder Selection & Double-Click Entry
const FileManager = {
  container: null,
  currentFolderId: null,
  currentFolderPath: "Root",
  selectedFolderInView: null,       // Currently selected subfolder on the right panel
  selectedFolderNameInView: null,
  treeData: null,
  rootFiles: [],
  selectedFolderFiles: [],
  selectedFolderSubfolders: [],
  mobileActiveTab: 'files',
  _lastFolderClick: 0,
  _lastFolderClickId: null,

  async render(targetEl) {
    this.container = targetEl;
    this.mobileActiveTab = 'files';
    this.selectedFolderInView = null;
    this.selectedFolderNameInView = null;

    this.container.innerHTML = `
      <div class="filemanager-layout show-files">
        <!-- Mobile Tab Switcher -->
        <div class="fm-mobile-tabs" id="fm-mobile-tabs">
          <button class="fm-mobile-tab-btn" id="fm-tab-folders" onclick="FileManager.setMobileTab('folders')">
            <span style="display: inline-flex; align-items: center;">${Icons.folder(15)}</span>
            <span>Papkalar</span>
          </button>
          <button class="fm-mobile-tab-btn active" id="fm-tab-files" onclick="FileManager.setMobileTab('files')">
            <span style="display: inline-flex; align-items: center;">${Icons.fileCode(15)}</span>
            <span>Fayllar</span>
          </button>
        </div>

        <!-- Left Folder Tree Panel -->
        <div class="fm-tree-panel">
          <div class="fm-panel-header">
            <span style="display: inline-flex; align-items: center; gap: 8px;">
              ${Icons.folder(16, 'var(--accent-blue)')}
              <span>Papkalar</span>
            </span>
            <button class="btn btn-ghost btn-sm" onclick="FileManager.promptNewFolder()" title="Yangi papka yaratish" style="padding: 4px 6px;">
              ${Icons.folderPlus(15)}
            </button>
          </div>
          <div class="fm-tree-content" id="fm-tree-root">
            <div class="skeleton" style="height: 120px;"></div>
          </div>
        </div>

        <!-- Right Contents Panel (Folders + Files) -->
        <div class="fm-files-panel" id="fm-files-dropzone">
          <div class="drag-overlay" id="fm-drag-overlay">
            <div class="drag-icon">${Icons.upload(48, 'var(--accent-blue)')}</div>
            <h3 style="font-size: 18px;">Fayllarni yuklash uchun shu yerga tashlang</h3>
            <p style="color: var(--text-secondary); font-size: 13.5px;">Faqat .py va .txt fayllar (50MB kvota doirasida)</p>
          </div>

          <!-- Main Toolbar -->
          <div class="fm-toolbar">
            <div class="fm-breadcrumbs-group" style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap; min-width: 0;">
              <div class="fm-breadcrumbs" id="fm-breadcrumbs">
                <span class="crumb-link" onclick="FileManager.selectFolder(null, 'Root')">${Icons.home(14)} <span>Root</span></span>
              </div>
              <div id="fm-selected-pill-box"></div>
            </div>

            <div class="fm-toolbar-actions" style="display: flex; gap: 8px; flex-wrap: wrap;">
              <input type="file" id="fm-hidden-file-input" multiple accept=".py,.txt" style="display: none;" onchange="FileManager.handleFileInput(this.files)" />
              <button class="btn btn-secondary btn-sm" id="fm-btn-new-folder" onclick="FileManager.promptNewFolder()" style="display: inline-flex; align-items: center; gap: 6px;">
                ${Icons.folderPlus(14)} <span>Yangi papka</span>
              </button>
              <button class="btn btn-secondary btn-sm" id="fm-btn-upload" onclick="document.getElementById('fm-hidden-file-input').click()" style="display: inline-flex; align-items: center; gap: 6px;">
                ${Icons.upload(14)} <span>Yuklash</span>
              </button>
              <button class="btn btn-secondary btn-sm" id="fm-btn-env" onclick="FileManager.openEnvModalForCurrent()" title="Muhit o'zgaruvchilari (.env)" style="display: inline-flex; align-items: center; gap: 5px;">
                ${Icons.key(14, 'var(--accent-yellow)')} <span>.env</span>
              </button>
              <button class="btn btn-primary btn-sm" id="fm-btn-new-file" onclick="FileManager.promptNewFile()" style="display: inline-flex; align-items: center; gap: 6px;">
                ${Icons.filePlus(14)} <span>Yangi skript (.py)</span>
              </button>
            </div>
          </div>

          <!-- Standard Libraries Banner -->
          <div style="background: rgba(56, 139, 253, 0.08); border-bottom: 1px solid rgba(56, 139, 253, 0.18); padding: 7px 16px; font-size: 12.5px; display: flex; align-items: center; justify-content: space-between; color: var(--text-secondary);">
            <div style="display: flex; align-items: center; gap: 8px;">
              <span style="display: inline-flex; align-items: center; justify-content: center; width: 18px; height: 18px; border-radius: 50%; background: rgba(56, 139, 253, 0.2); color: var(--accent-blue); font-size: 11px; font-weight: 700;">i</span>
              <span>Serverda faqat <strong style="color: var(--accent-blue);">telebot</strong> va <strong style="color: var(--accent-blue);">requests</strong> kutubxonalari qo'llab-quvvatlanadi (O'rtacha RAM: 20MB).</span>
            </div>
            <span style="font-size: 11.5px; color: var(--accent-green); font-weight: 600;">🟢 24/7 Barqaror Rejim</span>
          </div>

          <!-- Dynamic Contents Area -->
          <div class="fm-files-content" id="fm-files-container" onclick="FileManager.handleBackgroundClick(event)">
            <div class="skeleton" style="height: 200px;"></div>
          </div>
        </div>
      </div>
    `;

    this.bindDragAndDrop();
    await this.loadTree();
  },

  async loadTree() {
    try {
      const data = await API.get('/api/files/tree/');
      this.treeData = data.tree || [];
      this.rootFiles = data.root_files || [];

      if (data.quota) {
        DiskIndicator.update(data.quota.used_disk_mb, data.quota.max_disk_mb);
      }

      this.renderFolderTree();
      this.selectFolder(this.currentFolderId, this.currentFolderPath);
    } catch (err) {
      Toast.error("Fayl tizimini yuklashda xatolik: " + err.message);
    }
  },

  renderFolderTree() {
    const treeRoot = document.getElementById('fm-tree-root');
    if (!treeRoot) return;

    let html = `
      <div class="tree-item ${this.currentFolderId === null ? 'selected' : ''}" data-root="true" onclick="FileManager.selectFolder(null, 'Root')">
        <span style="display: inline-flex; align-items: center;">${Icons.home(15)}</span>
        <span style="flex: 1;">Asosiy (Root)</span>
      </div>
    `;

    const renderNodes = (folders, depth = 1) => {
      let out = '';
      folders.forEach(f => {
        const isSelected = this.currentFolderId === f.id;
        const indent = depth * 14;
        out += `
          <div style="padding-left: ${indent}px;">
            <div class="tree-item ${isSelected ? 'selected' : ''}" 
                 data-folder-id="${f.id}" 
                 onclick="FileManager.selectFolder(${f.id}, '${f.name}')"
                 oncontextmenu="FileManager.openFolderContextMenu(event, ${f.id}, '${f.name}')">
              <span class="tree-chevron ${f.folders && f.folders.length > 0 ? 'open' : ''}" style="display: inline-flex; align-items: center;">${Icons.chevronRight(12)}</span>
              <span style="display: inline-flex; align-items: center;">${Icons.folder(15)}</span>
              <span style="flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${f.name}</span>
              <button class="btn btn-ghost btn-sm" style="padding: 2px 6px; font-size: 11px; display: inline-flex; align-items: center;" onclick="event.stopPropagation(); FileManager.confirmDeleteFolder(${f.id}, '${f.name}')" title="Papkani o'chirish">${Icons.trash(12)}</button>
            </div>
            ${f.folders && f.folders.length > 0 ? renderNodes(f.folders, depth + 1) : ''}
          </div>
        `;
      });
      return out;
    };

    html += renderNodes(this.treeData || []);
    treeRoot.innerHTML = html;
  },

  getFolderPath(folderId) {
    if (!folderId) return [{ id: null, name: "Root" }];
    const search = (nodes, currentPath) => {
      for (const node of nodes) {
        const nextPath = [...currentPath, { id: node.id, name: node.name }];
        if (node.id === folderId) return nextPath;
        if (node.folders && node.folders.length) {
          const found = search(node.folders, nextPath);
          if (found) return found;
        }
      }
      return null;
    };
    const res = search(this.treeData || [], []);
    return res ? [{ id: null, name: "Root" }, ...res] : [{ id: null, name: "Root" }, { id: folderId, name: this.currentFolderPath }];
  },

  getCurrentFolderContents(folderId) {
    if (folderId === null) {
      return {
        folders: this.treeData || [],
        files: this.rootFiles || []
      };
    }
    const findNode = (list) => {
      for (const f of list) {
        if (f.id === folderId) return f;
        if (f.folders && f.folders.length) {
          const res = findNode(f.folders);
          if (res) return res;
        }
      }
      return null;
    };
    const node = findNode(this.treeData || []);
    return {
      folders: node ? (node.folders || []) : [],
      files: node ? (node.files || []) : []
    };
  },

  selectFolder(folderId, folderName) {
    this.currentFolderId = folderId;
    this.currentFolderPath = folderName || "Root";
    this.selectedFolderInView = null;
    this.selectedFolderNameInView = null;

    // Update active tree item in left panel
    const treeItems = document.querySelectorAll('.tree-item');
    treeItems.forEach(t => t.classList.remove('selected'));
    if (folderId === null) {
      const rootItem = document.querySelector('.tree-item[data-root="true"]');
      if (rootItem) rootItem.classList.add('selected');
    } else {
      const targetItem = document.querySelector(`.tree-item[data-folder-id="${folderId}"]`);
      if (targetItem) targetItem.classList.add('selected');
    }

    // Render breadcrumbs with Back button and clickable paths
    const breadcrumbs = document.getElementById('fm-breadcrumbs');
    if (breadcrumbs) {
      const path = this.getFolderPath(folderId);
      const parentItem = path.length > 1 ? path[path.length - 2] : null;

      let crumbHtml = '';
      if (parentItem) {
        crumbHtml += `
          <button class="btn btn-ghost btn-sm" onclick="FileManager.selectFolder(${parentItem.id}, '${parentItem.name}')" title="Oldingi papkaga qaytish" style="padding: 3px 8px; margin-right: 6px; display: inline-flex; align-items: center; gap: 4px; font-size: 12px; background: rgba(255,255,255,0.04);">
            ${Icons.arrowLeft(13)} <span>Orqaga</span>
          </button>
        `;
      }

      crumbHtml += path.map((item, idx) => {
        const isLast = idx === path.length - 1;
        if (isLast) {
          return `<span class="crumb-current">${idx === 0 ? Icons.home(13) + ' ' : ''}${item.name}</span>`;
        } else {
          return `<span class="crumb-link" onclick="FileManager.selectFolder(${item.id}, '${item.name}')">${idx === 0 ? Icons.home(13) + ' ' : ''}${item.name}</span> <span style="color: var(--text-muted); margin: 0 4px; font-size: 11px;">${Icons.chevronRight(10)}</span>`;
        }
      }).join('');

      breadcrumbs.innerHTML = crumbHtml;
    }

    this.updateSelectedFolderPill();

    // Get current contents (folders and files)
    const contents = this.getCurrentFolderContents(folderId);
    this.selectedFolderSubfolders = contents.folders;
    this.selectedFolderFiles = contents.files;

    this.renderContents(contents.folders, contents.files);

    // Auto-switch to files tab on mobile
    if (window.innerWidth <= 768) {
      this.setMobileTab('files');
    }
  },

  setMobileTab(tab) {
    this.mobileActiveTab = tab;
    const layout = document.querySelector('.filemanager-layout');
    if (layout) {
      layout.classList.toggle('show-folders', tab === 'folders');
      layout.classList.toggle('show-files', tab === 'files');
    }
    const tabFolders = document.getElementById('fm-tab-folders');
    const tabFiles = document.getElementById('fm-tab-files');
    if (tabFolders && tabFiles) {
      tabFolders.classList.toggle('active', tab === 'folders');
      tabFiles.classList.toggle('active', tab === 'files');
    }
  },

  renderContents(folders, files) {
    const container = document.getElementById('fm-files-container');
    if (!container) return;

    if ((!folders || folders.length === 0) && (!files || files.length === 0)) {
      container.innerHTML = `
        <div style="text-align: center; padding: 60px 20px; color: var(--text-muted);">
          <div style="margin-bottom: 16px; display: flex; justify-content: center;">${Icons.folderOpen(48, 'var(--text-muted)')}</div>
          <h3 style="font-size: 16px; margin-bottom: 6px; color: var(--text-primary);">Bu papka bo'sh</h3>
          <p style="font-size: 13.5px; margin-bottom: 22px;">Papkani yaratishingiz, bot kodini yuklashingiz yoki yangi Python skriptini ochishingiz mumkin</p>
          <div style="display: flex; gap: 10px; justify-content: center; flex-wrap: wrap;">
            <button class="btn btn-secondary btn-sm" onclick="FileManager.promptNewFolder()" style="display: inline-flex; align-items: center; gap: 6px;">
              ${Icons.folderPlus(14)} <span>Yangi papka</span>
            </button>
            <button class="btn btn-primary btn-sm" onclick="FileManager.promptNewFile()" style="display: inline-flex; align-items: center; gap: 6px;">
              ${Icons.filePlus(14)} <span>Yangi skript (.py)</span>
            </button>
          </div>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div class="fm-contents-wrapper">
        <!-- Folders Section -->
        ${folders && folders.length > 0 ? `
          <div class="fm-section-header">
            <div class="fm-section-label">
              ${Icons.folder(14, 'var(--accent-blue)')}
              <span>Papkalar (${folders.length})</span>
            </div>
            <span style="font-size: 11.5px; color: var(--text-muted);">1 marta bosish — tanlash, 2 marta tez bosish — kirish</span>
          </div>

          <div class="folders-grid">
            ${folders.map(f => {
              const fileCount = f.files ? f.files.length : 0;
              const subCount = f.folders ? f.folders.length : 0;
              const isSelected = this.selectedFolderInView === f.id;

              return `
                <div class="folder-card glass-panel ${isSelected ? 'selected' : ''}" 
                     id="folder-card-${f.id}"
                     data-folder-id="${f.id}"
                     data-folder-name="${f.name}"
                     onclick="FileManager.handleFolderClick(${f.id}, '${f.name}', event)"
                     ondblclick="FileManager.handleFolderDblClick(${f.id}, '${f.name}', event)"
                     oncontextmenu="FileManager.openFolderContextMenu(event, ${f.id}, '${f.name}')"
                     title="1 marta bosing: tanlash | 2 marta tez bosing: kirish">
                  <div class="folder-card-main">
                    <div class="folder-icon-box">
                      ${Icons.folder(22, isSelected ? 'var(--accent-cyan)' : 'var(--accent-blue)')}
                    </div>
                    <div class="folder-meta">
                      <span class="folder-title">${f.name}</span>
                      <span class="folder-subinfo">${fileCount} ta fayl${subCount > 0 ? `, ${subCount} ta papka` : ''}</span>
                    </div>
                  </div>
                  <div class="folder-actions">
                    <button class="btn btn-ghost btn-sm folder-enter-btn" onclick="event.stopPropagation(); FileManager.selectFolder(${f.id}, '${f.name}')" title="Papkaga kirish" style="padding: 4px 6px;">
                      ${Icons.chevronRight(16)}
                    </button>
                    <button class="btn btn-ghost btn-icon" onclick="event.stopPropagation(); FileManager.openFolderContextMenu(event, ${f.id}, '${f.name}')" title="Amallar" style="padding: 4px;">
                      ${Icons.moreVertical(16)}
                    </button>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        ` : ''}

        <!-- Files Section -->
        ${files && files.length > 0 ? `
          <div class="fm-section-header" style="${folders && folders.length > 0 ? 'margin-top: 18px;' : ''}">
            <div class="fm-section-label">
              ${Icons.fileCode(14, 'var(--accent-green)')}
              <span>Fayllar (${files.length})</span>
            </div>
          </div>

          <div class="files-grid">
            ${files.map(file => {
              const isPy = file.extension === '.py';
              const icon = isPy ? Icons.python(24) : Icons.fileCode(24, '#8B949E');
              const status = file.bot_status || 'stopped';

              return `
                <div class="file-card glass-panel" onclick="FileManager.handleFileClick(${file.id}, event)">
                  <div class="file-card-top">
                    <div class="file-title-group">
                      <span class="file-icon-badge" style="display: inline-flex; align-items: center;">${icon}</span>
                      <div>
                        <div class="file-name" title="${file.name}">${file.name}</div>
                        <div style="font-size: 12px; color: var(--text-muted);">${file.size_kb.toFixed(1)} KB</div>
                      </div>
                    </div>
                    <button class="btn btn-ghost btn-icon" onclick="event.stopPropagation(); FileManager.openContextMenu(event, ${file.id}, '${file.name}', '${status}')" title="Amallar" style="padding: 4px; display: inline-flex; align-items: center;">
                      ${Icons.moreVertical(16)}
                    </button>
                  </div>

                  <div class="file-card-bottom">
                    <div>
                      ${isPy ? `
                        <span class="status-pill status-${status}">
                          <span class="status-dot"></span> ${status === 'running' ? 'Ishlayapti' : status === 'crashed' ? 'Xatolik' : 'To\'xtatilgan'}
                        </span>
                      ` : `<span style="font-size: 12px; color: var(--text-muted);">Matnli fayl</span>`}
                    </div>
                    <div style="display: flex; gap: 6px;">
                      ${isPy ? `
                        ${status === 'running' ? `
                          <button class="btn btn-danger btn-sm" style="padding: 4px 10px; display: inline-flex; align-items: center; gap: 5px;" onclick="event.stopPropagation(); FileManager.stopBot(${file.id})">
                            ${Icons.square(11)} <span>To'xtatish</span>
                          </button>
                        ` : `
                          <button class="btn btn-success btn-sm" style="padding: 4px 10px; display: inline-flex; align-items: center; gap: 5px;" onclick="event.stopPropagation(); FileManager.startBot(${file.id})">
                            ${Icons.play(11)} <span>Ishga tushirish</span>
                          </button>
                        `}
                        <button class="btn btn-secondary btn-sm" style="padding: 4px 8px; display: inline-flex; align-items: center;" onclick="event.stopPropagation(); Router.navigate('/logs/${file.id}')" title="Loglar">
                          ${Icons.terminal(14)}
                        </button>
                      ` : ''}
                    </div>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        ` : ''}
      </div>
    `;
  },

  handleFolderClick(folderId, folderName, event) {
    if (event) event.stopPropagation();

    const now = Date.now();
    const isFastClick = (this._lastFolderClickId === folderId) && ((now - this._lastFolderClick) < 350);

    if (isFastClick) {
      // Double click detected! Enter folder
      this._lastFolderClick = 0;
      this._lastFolderClickId = null;
      this.selectFolder(folderId, folderName);
      return;
    }

    this._lastFolderClick = now;
    this._lastFolderClickId = folderId;

    // Single click: select folder
    this.selectFolderCard(folderId, folderName);
  },

  handleFolderDblClick(folderId, folderName, event) {
    if (event) event.stopPropagation();
    this.selectFolder(folderId, folderName);
  },

  selectFolderCard(folderId, folderName) {
    this.selectedFolderInView = folderId;
    this.selectedFolderNameInView = folderName;

    const cards = document.querySelectorAll('.folder-card');
    cards.forEach(c => {
      const cId = parseInt(c.dataset.folderId, 10);
      c.classList.toggle('selected', cId === folderId);
    });

    this.updateSelectedFolderPill();
  },

  clearFolderSelection(event) {
    if (event) event.stopPropagation();
    this.selectedFolderInView = null;
    this.selectedFolderNameInView = null;

    const cards = document.querySelectorAll('.folder-card');
    cards.forEach(c => c.classList.remove('selected'));

    this.updateSelectedFolderPill();
  },

  updateSelectedFolderPill() {
    const pillContainer = document.getElementById('fm-selected-pill-box');
    if (!pillContainer) return;

    if (this.selectedFolderInView) {
      pillContainer.innerHTML = `
        <span class="selected-folder-pill" title="Yangi fayl yoki papka '${this.selectedFolderNameInView}' ichiga yaratiladi">
          <span class="status-dot"></span>
          <span>Tanlangan papka: <strong>${this.selectedFolderNameInView}</strong></span>
          <button onclick="FileManager.clearFolderSelection(event)" title="Tanlovni bekor qilish">&times;</button>
        </span>
      `;
    } else {
      pillContainer.innerHTML = '';
    }
  },

  handleFileClick(fileId, event) {
    this.clearFolderSelection();
    Router.navigate('/editor/' + fileId);
  },

  handleBackgroundClick(event) {
    // If clicking outside cards and buttons, clear selection
    if (event.target.closest('.folder-card') || event.target.closest('.file-card') || event.target.closest('button')) {
      return;
    }
    this.clearFolderSelection();
  },

  getTargetFolder() {
    if (this.selectedFolderInView) {
      return {
        id: this.selectedFolderInView,
        name: this.selectedFolderNameInView,
        isSelection: true
      };
    }
    return {
      id: this.currentFolderId,
      name: this.currentFolderPath,
      isSelection: false
    };
  },

  openFolderContextMenu(e, folderId, folderName) {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    this.selectFolderCard(folderId, folderName);

    const items = [
      {
        label: `Papkani ochish ('${folderName}')`,
        icon: Icons.folderOpen(14, 'var(--accent-blue)'),
        onClick: () => this.selectFolder(folderId, folderName)
      },
      { type: 'divider' },
      {
        label: `Ichiga yangi skript (.py) yaratish`,
        icon: Icons.filePlus(14, 'var(--accent-green)'),
        onClick: () => this.promptNewFile()
      },
      {
        label: `Ichiga yangi papka yaratish`,
        icon: Icons.folderPlus(14, 'var(--accent-blue)'),
        onClick: () => this.promptNewFolder()
      },
      { type: 'divider' },
      {
        label: `Papkani o'chirish`,
        icon: Icons.trash(14, 'var(--status-crashed)'),
        isDanger: true,
        onClick: () => this.confirmDeleteFolder(folderId, folderName)
      }
    ];

    ContextMenu.show(e.clientX, e.clientY, items);
  },

  openContextMenu(e, fileId, fileName, status) {
    const isRunning = status === 'running';
    const items = [
      ...(fileName.endsWith('.py') ? [
        isRunning ? {
          label: "Botni to'xtatish",
          icon: Icons.square(14, 'var(--status-crashed)'),
          onClick: () => this.stopBot(fileId)
        } : {
          label: "Botni ishga tushirish",
          icon: Icons.play(14, 'var(--status-running)'),
          onClick: () => this.startBot(fileId)
        },
        {
          label: "Real-vaqt loglar",
          icon: Icons.terminal(14, 'var(--accent-blue)'),
          onClick: () => Router.navigate(`/logs/${fileId}`)
        },
        {
          label: "Xavfsiz .env kalitlari",
          icon: Icons.key(14, 'var(--accent-yellow)'),
          onClick: () => Modal.openEnvManager(fileId)
        },
        {
          label: "Pip paketlar menejeri",
          icon: Icons.package(14, 'var(--accent-blue)'),
          onClick: () => Modal.openPipManager(fileId)
        },
        { type: 'divider' }
      ] : []),
      {
        label: "Kodni tahrirlash",
        icon: Icons.edit(14, 'var(--text-secondary)'),
        onClick: () => Router.navigate(`/editor/${fileId}`)
      },
      {
        label: "Nomini o'zgartirish",
        icon: Icons.edit(14, 'var(--text-secondary)'),
        onClick: () => this.promptRenameFile(fileId, fileName)
      },
      { type: 'divider' },
      {
        label: "O'chirish",
        icon: Icons.trash(14, 'var(--status-crashed)'),
        isDanger: true,
        onClick: () => this.confirmDeleteFile(fileId, fileName)
      }
    ];

    ContextMenu.show(e.clientX, e.clientY, items);
  },

  async startBot(fileId) {
    try {
      Toast.info("Bot ishga tushirilmoqda...");
      const res = await API.post(`/api/bots/${fileId}/start/`);
      Toast.success(res.message);
      await this.loadTree();
    } catch (err) {
      Toast.error("Xatolik: " + err.message);
    }
  },

  async stopBot(fileId) {
    try {
      Toast.info("Bot to'xtatilmoqda...");
      const res = await API.post(`/api/bots/${fileId}/stop/`);
      Toast.success(res.message);
      await this.loadTree();
    } catch (err) {
      Toast.error("Xatolik: " + err.message);
    }
  },

  promptNewFile() {
    const target = this.getTargetFolder();
    const locationName = target.id ? `'${target.name}' papkasi` : "Asosiy (Root)";

    Modal.prompt({
      title: "Yangi Python Skripti (.py)",
      label: `Skript nomi (${locationName} ichida):`,
      defaultValue: "bot.py",
      confirmText: "Yaratish",
      onConfirm: async (fileName) => {
        try {
          await API.post('/api/files/create/', {
            name: fileName,
            folder_id: target.id
          });
          Toast.success(`'${fileName}' fayli (${locationName} ichida) yaratildi!`);
          await this.loadTree();
          // If created inside a selected subfolder, navigate into it so user immediately sees the file
          if (target.isSelection) {
            this.selectFolder(target.id, target.name);
          }
        } catch (err) {
          Toast.error(err.message);
        }
      }
    });
  },

  promptNewFolder() {
    const target = this.getTargetFolder();
    const locationName = target.id ? `'${target.name}' papkasi` : "Asosiy (Root)";

    Modal.prompt({
      title: "Yangi Papka Yaratish",
      label: `Papka nomi (${locationName} ichida):`,
      defaultValue: "yangi_papka",
      confirmText: "Yaratish",
      onConfirm: async (folderName) => {
        try {
          await API.post('/api/files/folder/', {
            name: folderName,
            parent_id: target.id
          });
          Toast.success(`'${folderName}' papkasi (${locationName} ichida) yaratildi!`);
          await this.loadTree();
          // If created inside a selected subfolder, navigate into it so user immediately sees the folder
          if (target.isSelection) {
            this.selectFolder(target.id, target.name);
          }
        } catch (err) {
          Toast.error(err.message);
        }
      }
    });
  },

  promptRenameFile(fileId, oldName) {
    Modal.prompt({
      title: "Fayl nomini o'zgartirish",
      defaultValue: oldName,
      confirmText: "Saqlash",
      onConfirm: async (newName) => {
        try {
          await API.patch(`/api/files/${fileId}/rename/`, { name: newName });
          Toast.success("Fayl nomi o'zgartirildi!");
          await this.loadTree();
        } catch (err) {
          Toast.error(err.message);
        }
      }
    });
  },

  confirmDeleteFile(fileId, fileName) {
    Modal.confirm({
      title: "Faylni o'chirish",
      message: `'${fileName}' faylini o'chirmoqchimisiz? Agar bot ishlayotgan bo'lsa, to'xtatiladi.`,
      isDanger: true,
      confirmText: "O'chirish",
      onConfirm: async () => {
        try {
          await API.delete(`/api/files/${fileId}/`);
          Toast.success("Fayl o'chirildi.");
          await this.loadTree();
        } catch (err) {
          Toast.error(err.message);
        }
      }
    });
  },

  confirmDeleteFolder(folderId, folderName) {
    Modal.confirm({
      title: "Papkani o'chirish",
      message: `'${folderName}' papkasi va uning ichidagi barcha fayllar o'chiriladi. Rozimisiz?`,
      isDanger: true,
      confirmText: "Papkani o'chirish",
      onConfirm: async () => {
        try {
          await API.delete(`/api/files/folder/${folderId}/`);
          Toast.success("Papka o'chirildi.");
          if (this.currentFolderId === folderId || this.selectedFolderInView === folderId) {
            this.currentFolderId = null;
            this.currentFolderPath = "Root";
            this.selectedFolderInView = null;
            this.selectedFolderNameInView = null;
          }
          await this.loadTree();
        } catch (err) {
          Toast.error(err.message);
        }
      }
    });
  },

  bindDragAndDrop() {
    const dropzone = document.getElementById('fm-files-dropzone');
    const overlay = document.getElementById('fm-drag-overlay');
    if (!dropzone || !overlay) return;

    ['dragenter', 'dragover'].forEach(eventName => {
      dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        overlay.classList.add('active');
      }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
      dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        overlay.classList.remove('active');
      }, false);
    });

    dropzone.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      const files = dt.files;
      this.handleFileInput(files);
    }, false);
  },

  async handleFileInput(fileList) {
    if (!fileList || fileList.length === 0) return;

    const target = this.getTargetFolder();
    const locationName = target.id ? `'${target.name}' papkasi` : "Root";

    const formData = new FormData();
    for (let i = 0; i < fileList.length; i++) {
      formData.append('files', fileList[i]);
    }
    if (target.id) {
      formData.append('folder_id', target.id);
    }

    try {
      Toast.info(`Fayllar yuklanmoqda (${locationName} ichiga)...`);
      const res = await API.post('/api/files/upload/', formData, true);
      Toast.success(res.message);
      await this.loadTree();
      if (target.isSelection) {
        this.selectFolder(target.id, target.name);
      }
    } catch (err) {
      Toast.error("Yuklashda xatolik: " + err.message);
    }
  },

  openEnvModalForCurrent() {
    const pyInFolder = this.selectedFolderFiles ? this.selectedFolderFiles.find(f => f.name.endsWith('.py')) : null;
    const pyInRoot = this.rootFiles ? this.rootFiles.find(f => f.name.endsWith('.py')) : null;
    const targetFile = pyInFolder || pyInRoot;

    if (!targetFile) {
      Toast.info("Avval .py skript faylini yarating yoki yuklang");
      return;
    }
    Modal.openEnvManager(targetFile.id);
  },

  openPackagesModal() {
    Modal.alert({
      title: "⚡ O'rnatilgan Kutubxonalar",
      message: `
        <div style="font-size: 13.5px; line-height: 1.6; color: var(--text-secondary); text-align: left;">
          <p style="margin-bottom: 12px;">PyHosting bepul serverida 24/7 barqaror ishlash va xotira (RAM) tejash uchun quyidagi kutubxonalar oldindan o'rnatilgan:</p>
          <ul style="padding-left: 20px; margin-bottom: 14px; color: var(--text-primary);">
            <li><strong style="color: var(--accent-blue);">telebot</strong> (pyTelegramBotAPI) — Telegram botlar uchun (RAM: ~20MB)</li>
            <li><strong style="color: var(--accent-blue);">requests</strong> — Internet va tashqi API so'rovlari uchun</li>
            <li><strong style="color: var(--accent-blue);">sqlite3</strong> — Bot ma'lumotlar bazasi (faylli SQL)</li>
            <li><strong style="color: var(--accent-blue);">Standart Python kutubxonalari:</strong> json, math, random, datetime, time, re, urllib, threading, hashlib va b.</li>
          </ul>
          <div style="background: rgba(248, 81, 73, 0.1); border: 1px solid rgba(248, 81, 73, 0.3); border-radius: 6px; padding: 10px 12px; font-size: 12px; color: var(--accent-red);">
            ⚠️ <strong>Eslatma:</strong> Boshqa og'ir kutubxonalarni (masalan: aiogram, selenium, pandas) import qilish server barqarorligi uchun cheklangan.
          </div>
        </div>
      `,
      confirmText: "Tushundim"
    });
  }
};

window.FileManager = FileManager;
