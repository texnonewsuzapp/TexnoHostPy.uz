// PyHosting.uz - SQLite Database Viewer & Manager (Liquid Glass UI)
const DatabasesPage = {
  container: null,
  databases: [],
  selectedDbId: null,
  schemaData: null,
  selectedTable: null,
  tableData: null,
  searchQuery: '',
  currentPage: 1,
  limit: 20,
  isLoading: false,
  isTableLoading: false,

  escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  },

  async render(targetEl) {
    this.container = targetEl;
    this.databases = [];
    this.selectedDbId = null;
    this.schemaData = null;
    this.selectedTable = null;
    this.tableData = null;
    this.searchQuery = '';
    this.currentPage = 1;

    this.renderSkeleton();
    await this.loadDatabases();
  },

  renderSkeleton() {
    this.container.innerHTML = `
      <div class="view-page">
        <div class="dashboard-header">
          <div>
            <div style="display: flex; align-items: center; gap: 10px;">
              <h1 class="dashboard-title">Ma'lumotlar Bazasi</h1>
              <span class="badge" style="background: rgba(56, 139, 253, 0.15); color: var(--accent-blue); border: 1px solid rgba(56, 139, 253, 0.3);">SQLite 3</span>
            </div>
            <p class="dashboard-subtitle">Telegram botingiz ma'lumotlar bazalarini ko'rish, qidirish va eksport qilish</p>
          </div>
        </div>
        <div class="glass-panel" style="padding: 30px; margin-top: 20px;">
          <div class="skeleton" style="height: 240px;"></div>
        </div>
      </div>
    `;
  },

  async loadDatabases(autoSelectFirst = true) {
    this.isLoading = true;
    try {
      const data = await API.get('/api/databases/');
      this.databases = Array.isArray(data) ? data : [];

      if (this.databases.length === 0) {
        this.renderEmptyState();
        return;
      }

      if (autoSelectFirst || !this.selectedDbId || !this.databases.find(d => d.id === this.selectedDbId)) {
        this.selectedDbId = this.databases[0].id;
      }

      await this.loadSchema(this.selectedDbId);
    } catch (err) {
      this.container.innerHTML = `
        <div class="view-page">
          <div class="glass-panel" style="padding: 40px; text-align: center; color: var(--status-crashed);">
            <h3>Ma'lumotlar bazalarini yuklashda xatolik</h3>
            <p style="color: var(--text-secondary); margin: 10px 0 20px;">${this.escapeHtml(err.message)}</p>
            <button class="btn btn-secondary btn-sm" onclick="DatabasesPage.loadDatabases()">Qayta urinish</button>
          </div>
        </div>
      `;
    } finally {
      this.isLoading = false;
    }
  },

  renderEmptyState() {
    this.container.innerHTML = `
      <div class="view-page">
        <div class="dashboard-header">
          <div>
            <div style="display: flex; align-items: center; gap: 10px;">
              <h1 class="dashboard-title">Ma'lumotlar Bazasi</h1>
              <span class="badge" style="background: rgba(56, 139, 253, 0.15); color: var(--accent-blue); border: 1px solid rgba(56, 139, 253, 0.3);">SQLite 3</span>
            </div>
            <p class="dashboard-subtitle">Telegram botingiz ma'lumotlar bazalarini boshqarish</p>
          </div>
          <div class="dashboard-actions">
            <button class="btn btn-secondary btn-sm" onclick="DatabasesPage.loadDatabases()">
              ${Icons.refresh ? Icons.refresh(14) : ''}
              <span>Yangilash</span>
            </button>
          </div>
        </div>

        <div class="glass-panel db-empty-panel">
          <div class="db-empty-icon-wrap">
            ${Icons.database(48, 'var(--accent-blue)')}
          </div>
          <h2 style="font-size: 20px; font-weight: 700; margin-bottom: 8px;">Hozircha SQLite ma'lumotlar bazasi mavjud emas</h2>
          <p style="color: var(--text-secondary); max-width: 540px; font-size: 14px; line-height: 1.6; margin: 0 auto 24px;">
            Loyihangizda <code>.db</code>, <code>.sqlite</code> yoki <code>.sqlite3</code> kengaytmali fayllar topilmadi.
            Fayl menejeri orqali o'z bazangizni yuklashingiz yoki sinab ko'rish uchun avtomatik namuna baza yaratishingiz mumkin.
          </p>
          <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
            <button class="btn btn-primary" onclick="DatabasesPage.createSampleDatabase()" style="display: inline-flex; align-items: center; gap: 8px;">
              ${Icons.database(16)}
              <span>Namuna Baza Yaratish (Sample DB)</span>
            </button>
            <button class="btn btn-secondary" onclick="Router.navigate('/files')" style="display: inline-flex; align-items: center; gap: 8px;">
              ${Icons.folder ? Icons.folder(16) : ''}
              <span>Fayl Menejeriga O'tish</span>
            </button>
          </div>
        </div>
      </div>
    `;
  },

  async createSampleDatabase() {
    try {
      Toast.show("Namuna baza yaratilmoqda...", "info", 2000);
      const res = await API.post('/api/databases/sample/', {});
      Toast.show(res.message || "Namuna baza yaratildi!", "success");
      await this.loadDatabases(true);
    } catch (err) {
      Toast.show(err.message || "Namuna baza yaratishda xatolik", "error");
    }
  },

  async loadSchema(dbId) {
    try {
      this.selectedDbId = dbId;
      this.schemaData = await API.get(`/api/databases/${dbId}/schema/`);
      
      const tables = this.schemaData.tables || [];
      if (tables.length > 0) {
        // If current selected table exists in new schema, keep it, else pick first
        if (!this.selectedTable || !tables.find(t => t.name === this.selectedTable)) {
          this.selectedTable = tables[0].name;
        }
      } else {
        this.selectedTable = null;
      }

      this.currentPage = 1;
      this.searchQuery = '';
      this.renderMainView();

      if (this.selectedTable) {
        await this.loadTableData();
      }
    } catch (err) {
      Toast.show("Baza strukturasini o'qishda xatolik: " + err.message, "error");
    }
  },

  async selectTable(tableName) {
    if (this.selectedTable === tableName) return;
    this.selectedTable = tableName;
    this.currentPage = 1;
    this.searchQuery = '';
    
    // Update active tab styles immediately
    const tabBtns = document.querySelectorAll('.db-table-pill');
    tabBtns.forEach(btn => {
      if (btn.getAttribute('data-table') === tableName) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    const searchInput = document.getElementById('db-search-input');
    if (searchInput) searchInput.value = '';

    await this.loadTableData();
  },

  async loadTableData() {
    if (!this.selectedDbId || !this.selectedTable) return;
    this.isTableLoading = true;
    this.renderTableContent();

    try {
      const q = encodeURIComponent(this.searchQuery.trim());
      const url = `/api/databases/${this.selectedDbId}/table/?table=${encodeURIComponent(this.selectedTable)}&search=${q}&page=${this.currentPage}&limit=${this.limit}`;
      this.tableData = await API.get(url);
    } catch (err) {
      Toast.show("Jadval ma'lumotlarini yuklashda xatolik: " + err.message, "error");
      this.tableData = null;
    } finally {
      this.isTableLoading = false;
      this.renderTableContent();
    }
  },

  renderMainView() {
    const currentDb = this.databases.find(d => d.id === this.selectedDbId) || this.databases[0];
    const tables = (this.schemaData && this.schemaData.tables) || [];

    this.container.innerHTML = `
      <div class="view-page">
        <!-- Header -->
        <div class="dashboard-header">
          <div>
            <div style="display: flex; align-items: center; gap: 10px;">
              <h1 class="dashboard-title">Ma'lumotlar Bazasi</h1>
              <span class="badge" style="background: rgba(56, 139, 253, 0.15); color: var(--accent-blue); border: 1px solid rgba(56, 139, 253, 0.3);">SQLite 3</span>
            </div>
            <p class="dashboard-subtitle">Telegram botingiz ma'lumotlar bazalarini ko'rish, qidirish va eksport qilish</p>
          </div>
          <div class="dashboard-actions">
            <button class="btn btn-secondary btn-sm" onclick="DatabasesPage.createSampleDatabase()" title="Sinab ko'rish uchun yangi namuna baza yaratish">
              <span style="display: inline-flex; align-items: center;">${Icons.database(15, 'var(--accent-blue)')}</span>
              <span>+ Namuna Baza</span>
            </button>
            <button class="btn btn-secondary btn-sm" onclick="DatabasesPage.loadDatabases(false)" title="Bazalar ro'yxatini yangilash">
              <span style="display: inline-flex; align-items: center;">${Icons.refresh ? Icons.refresh(15) : ''}</span>
              <span>Yangilash</span>
            </button>
          </div>
        </div>

        <!-- Databases Selector Ribbon / Grid -->
        <div class="db-selector-bar glass-panel">
          <div class="db-selector-scroll">
            ${this.databases.map(db => `
              <div class="db-pill-card ${db.id === this.selectedDbId ? 'active' : ''}" onclick="DatabasesPage.loadSchema(${db.id})">
                <span class="db-pill-icon">${Icons.database(18, db.id === this.selectedDbId ? '#fff' : 'var(--accent-blue)')}</span>
                <div class="db-pill-info">
                  <span class="db-pill-name" title="${this.escapeHtml(db.name)}">${this.escapeHtml(db.name)}</span>
                  <span class="db-pill-size">${this.escapeHtml(db.size_formatted)}</span>
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Active Database Meta & Actions -->
        <div class="db-active-meta-card glass-panel">
          <div class="db-active-meta-left">
            <div class="db-active-badge-icon">
              ${Icons.database(22, 'var(--accent-blue)')}
            </div>
            <div>
              <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                <h3 style="font-size: 17px; font-weight: 700; color: var(--text-primary); margin: 0;">${this.escapeHtml(currentDb ? currentDb.name : '')}</h3>
                <span class="badge badge-accent">${this.escapeHtml(currentDb ? currentDb.size_formatted : '')}</span>
                <span class="badge" style="background: rgba(255,255,255,0.06); color: var(--text-secondary); border: 1px solid var(--border-subtle);">${tables.length} ta jadval</span>
              </div>
              <p style="font-size: 12.5px; color: var(--text-muted); margin-top: 3px;">
                Fayl yo'li: <code>${this.escapeHtml(currentDb ? currentDb.name : '')}</code> • Xavfsiz faqat-o'qish (Read-Only) rejimida ochilgan
              </p>
            </div>
          </div>
          <div class="db-active-meta-right">
            <button class="btn btn-primary btn-sm" onclick="DatabasesPage.exportDatabase(${currentDb ? currentDb.id : 0}, '${this.escapeHtml(currentDb ? currentDb.name : 'database.db')}')" style="display: inline-flex; align-items: center; gap: 6px;">
              ${Icons.download(15)}
              <span>Baza Faylini Yuklab Olish (Export)</span>
            </button>
          </div>
        </div>

        <!-- Tables Pills -->
        <div class="db-tables-nav">
          <div class="db-tables-nav-header">
            <span style="display: inline-flex; align-items: center; gap: 6px; font-size: 13.5px; font-weight: 600; color: var(--text-secondary);">
              ${Icons.table(15, 'var(--accent-blue)')}
              <span>Jadvallar:</span>
            </span>
          </div>
          <div class="db-tables-pills-list">
            ${tables.length === 0 ? `
              <span style="font-size: 13px; color: var(--text-muted); font-style: italic;">Bu bazada hech qanday jadval topilmadi</span>
            ` : tables.map(t => `
              <button class="db-table-pill ${t.name === this.selectedTable ? 'active' : ''}" data-table="${this.escapeHtml(t.name)}" onclick="DatabasesPage.selectTable('${this.escapeHtml(t.name)}')">
                <span class="pill-name">${this.escapeHtml(t.name)}</span>
                <span class="pill-count">${t.row_count}</span>
              </button>
            `).join('')}
          </div>
        </div>

        <!-- Table Data Viewer Container -->
        <div class="glass-panel db-viewer-card" id="db-table-viewer-container">
          <!-- Will be filled by renderTableContent() -->
        </div>
      </div>
    `;

    this.renderTableContent();
  },

  renderTableContent() {
    const viewerContainer = document.getElementById('db-table-viewer-container');
    if (!viewerContainer) return;

    if (!this.selectedTable) {
      viewerContainer.innerHTML = `
        <div style="padding: 50px 20px; text-align: center; color: var(--text-muted);">
          <p>Ko'rish uchun yuqoridagi jadvallardan birini tanlang</p>
        </div>
      `;
      return;
    }

    // Find schema info for selected table
    const tableSchema = (this.schemaData && this.schemaData.tables && this.schemaData.tables.find(t => t.name === this.selectedTable)) || null;
    const columns = (tableSchema && tableSchema.columns) || [];

    // Header with Search Bar and Schema Pills
    let html = `
      <div class="db-table-toolbar">
        <div class="db-search-box">
          <span class="db-search-icon">${Icons.search(16, 'var(--text-muted)')}</span>
          <input 
            type="text" 
            id="db-search-input" 
            class="db-search-input" 
            placeholder="${this.escapeHtml(this.selectedTable)} jadvali bo'yicha qidirish (Enter bosing)..." 
            value="${this.escapeHtml(this.searchQuery)}"
            onkeydown="if(event.key === 'Enter'){ DatabasesPage.handleSearch(this.value); }"
          />
          ${this.searchQuery ? `
            <button class="db-search-clear" onclick="DatabasesPage.handleSearch('')" title="Qidiruvni tozalash">✕</button>
          ` : ''}
        </div>
        <div class="db-toolbar-actions">
          <button class="btn btn-secondary btn-sm" onclick="DatabasesPage.handleSearch(document.getElementById('db-search-input').value)">
            ${Icons.search(14)}
            <span>Qidirish</span>
          </button>
          <button class="btn btn-ghost btn-sm" onclick="DatabasesPage.loadTableData()" title="Jadvalni qayta yuklash">
            ${Icons.refresh ? Icons.refresh(14) : ''}
          </button>
        </div>
      </div>

      <!-- Column Schema Pills Ribbon -->
      <div class="db-columns-schema-ribbon">
        <span class="schema-label">Ustunlar:</span>
        <div class="schema-tags">
          ${columns.map(col => `
            <span class="schema-tag ${col.pk ? 'is-pk' : ''}" title="${col.pk ? 'Primary Key' : ''} ${col.notnull ? 'NOT NULL' : ''}">
              ${col.pk ? '<span class="pk-star">★</span>' : ''}
              <strong>${this.escapeHtml(col.name)}</strong>
              <span class="col-type">${this.escapeHtml(col.type || 'ANY')}</span>
            </span>
          `).join('')}
        </div>
      </div>
    `;

    if (this.isTableLoading) {
      html += `
        <div class="db-table-loading-wrap">
          <div class="skeleton" style="height: 48px; margin-bottom: 8px;"></div>
          <div class="skeleton" style="height: 36px; margin-bottom: 6px;"></div>
          <div class="skeleton" style="height: 36px; margin-bottom: 6px;"></div>
          <div class="skeleton" style="height: 36px; margin-bottom: 6px;"></div>
          <div class="skeleton" style="height: 36px;"></div>
        </div>
      `;
      viewerContainer.innerHTML = html;
      return;
    }

    const data = this.tableData;
    if (!data || !data.rows) {
      html += `
        <div style="padding: 40px; text-align: center; color: var(--text-muted);">
          <p>Ma'lumot topilmadi yoki jadval bo'sh.</p>
        </div>
      `;
      viewerContainer.innerHTML = html;
      return;
    }

    const totalRows = data.total_rows || 0;
    const tableCols = data.columns || [];
    const rows = data.rows || [];
    const totalPages = Math.ceil(totalRows / this.limit) || 1;

    html += `
      <!-- Table Grid Wrapper -->
      <div class="db-table-scroll-container">
        <table class="db-data-table">
          <thead>
            <tr>
              <th class="db-th-num">#</th>
              ${tableCols.map(c => `
                <th>
                  <div class="db-th-cell">
                    <span>${this.escapeHtml(c)}</span>
                  </div>
                </th>
              `).join('')}
            </tr>
          </thead>
          <tbody>
            ${rows.length === 0 ? `
              <tr>
                <td colspan="${tableCols.length + 1}" class="db-td-empty">
                  ${this.searchQuery ? `"${this.escapeHtml(this.searchQuery)}" bo'yicha hech qanday natija topilmadi` : 'Bu jadvalda hozircha hech qanday yozuv mavjud emas'}
                </td>
              </tr>
            ` : rows.map((row, idx) => {
              const rowNum = (this.currentPage - 1) * this.limit + idx + 1;
              return `
                <tr>
                  <td class="db-td-num">${rowNum}</td>
                  ${tableCols.map(c => {
                    const val = row[c];
                    if (val === null || val === undefined) {
                      return `<td class="db-td-val"><span class="db-null-pill">NULL</span></td>`;
                    }
                    if (typeof val === 'boolean') {
                      return `<td class="db-td-val"><span class="badge ${val ? 'badge-online' : 'badge-offline'}">${val ? 'TRUE' : 'FALSE'}</span></td>`;
                    }
                    return `<td class="db-td-val" title="${this.escapeHtml(String(val))}">${this.escapeHtml(String(val))}</td>`;
                  }).join('')}
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>

      <!-- Footer with Pagination & Stats -->
      <div class="db-table-footer">
        <div class="db-footer-stats">
          <span>Jami: <strong>${totalRows}</strong> ta yozuv</span>
          ${this.searchQuery ? `<span class="badge badge-accent" style="margin-left: 8px;">Qidiruv filtri faol</span>` : ''}
        </div>
        <div class="db-pagination-controls">
          <button 
            class="btn btn-secondary btn-sm" 
            onclick="DatabasesPage.goToPage(${this.currentPage - 1})" 
            ${this.currentPage <= 1 ? 'disabled style="opacity: 0.5; pointer-events: none;"' : ''}
          >
            ← Oldingi
          </button>
          <span class="db-page-counter">
            Sahifa <strong>${this.currentPage}</strong> / ${totalPages}
          </span>
          <button 
            class="btn btn-secondary btn-sm" 
            onclick="DatabasesPage.goToPage(${this.currentPage + 1})" 
            ${this.currentPage >= totalPages ? 'disabled style="opacity: 0.5; pointer-events: none;"' : ''}
          >
            Keyingi →
          </button>
        </div>
      </div>
    `;

    viewerContainer.innerHTML = html;
  },

  handleSearch(query) {
    this.searchQuery = query || '';
    this.currentPage = 1;
    this.loadTableData();
  },

  goToPage(pageNum) {
    if (pageNum < 1) return;
    this.currentPage = pageNum;
    this.loadTableData();
  },

  async exportDatabase(dbId, filename) {
    if (!dbId) return;
    try {
      Toast.show("Baza fayli yuklab olinmoqda...", "info", 2000);
      const token = API.getToken();
      const response = await fetch(`/api/databases/${dbId}/export/`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        throw new Error("Bazani yuklab olishda xatolik yuz berdi");
      }

      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = filename || 'database.db';
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(downloadUrl);
      Toast.show("Baza muvaffaqiyatli yuklab olindi!", "success");
    } catch (err) {
      Toast.show(err.message || "Eksport qilishda xatolik", "error");
    }
  }
};

window.DatabasesPage = DatabasesPage;
