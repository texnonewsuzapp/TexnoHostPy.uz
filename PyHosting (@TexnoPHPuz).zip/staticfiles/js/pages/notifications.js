/**
 * PyHosting.uz - Bildirishnomalar (Notifications) Page Controller
 */

window.NotificationsPage = {
  currentFilter: 'all',
  notifications: [],
  unreadCount: 0,

  async render(container) {
    container.innerHTML = `
      <div class="view-page notifications-page">
        <!-- Top Header -->
        <div class="page-header" style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 16px; margin-bottom: 24px;">
          <div>
            <div style="display: flex; align-items: center; gap: 10px;">
              <div class="icon-bubble" style="width: 36px; height: 36px; border-radius: 10px; background: rgba(56, 139, 253, 0.15); display: flex; align-items: center; justify-content: center; color: var(--accent-blue);">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                  <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                </svg>
              </div>
              <h1 class="page-title" style="margin: 0; font-size: 24px; font-weight: 700;">Bildirishnomalar</h1>
            </div>
            <p class="page-subtitle" style="margin: 6px 0 0 0; color: var(--text-secondary); font-size: 14px;">
              Tizim yangiliklari, texnik e'lonlar va sizga yuborilgan shaxsiy xabarlar
            </p>
          </div>

          <div style="display: flex; gap: 10px; align-items: center;">
            <button class="btn btn-secondary btn-sm" id="btn-read-all" onclick="NotificationsPage.markAllRead()" style="display: none; align-items: center; gap: 6px;">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"></path></svg>
              <span>Barchasini o'qilgan qilish</span>
            </button>
            <button class="btn btn-ghost btn-sm" onclick="NotificationsPage.loadData(true)" title="Yangilash">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path><path d="M3 3v5h5"></path><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"></path><path d="M16 21h5v-5"></path></svg>
            </button>
          </div>
        </div>

        <!-- Filter Tabs -->
        <div class="notifications-tabs-bar" style="display: flex; gap: 8px; margin-bottom: 20px; border-bottom: 1px solid var(--border-subtle); padding-bottom: 12px;">
          <button class="tab-pill active" data-filter="all" onclick="NotificationsPage.setFilter('all')">
            <span>Barchasi</span>
            <span class="tab-count" id="count-all">0</span>
          </button>
          <button class="tab-pill" data-filter="unread" onclick="NotificationsPage.setFilter('unread')">
            <span>O'qilmaganlar</span>
            <span class="tab-count badge-accent" id="count-unread">0</span>
          </button>
          <button class="tab-pill" data-filter="broadcast" onclick="NotificationsPage.setFilter('broadcast')">
            <span>📢 Tizim e'lonlari</span>
          </button>
        </div>

        <!-- Notifications Container -->
        <div id="notifications-list-container">
          <div class="skeleton" style="height: 90px; margin-bottom: 12px; border-radius: 12px;"></div>
          <div class="skeleton" style="height: 90px; margin-bottom: 12px; border-radius: 12px;"></div>
        </div>
      </div>
    `;

    await this.loadData();
  },

  async loadData(showToast = false) {
    const listEl = document.getElementById('notifications-list-container');
    if (!listEl) return;

    try {
      const res = await API.getNotifications(this.currentFilter);
      this.notifications = res.notifications || [];
      this.unreadCount = res.unread_count || 0;

      // Update badges
      this.updateBadges(this.unreadCount);

      // Update counts
      const countAllEl = document.getElementById('count-all');
      const countUnreadEl = document.getElementById('count-unread');
      const btnReadAll = document.getElementById('btn-read-all');

      if (countAllEl) countAllEl.textContent = res.total_count || this.notifications.length;
      if (countUnreadEl) countUnreadEl.textContent = this.unreadCount;
      if (btnReadAll) {
        btnReadAll.style.display = this.unreadCount > 0 ? 'inline-flex' : 'none';
      }

      this.renderList(listEl);
      if (showToast && window.Toast) {
        Toast.show("Bildirishnomalar yangilandi", "info");
      }
    } catch (err) {
      console.error("Bildirishnomalarni yuklashda xatolik:", err);
      if (listEl) {
        listEl.innerHTML = `
          <div class="empty-state-box glass-panel" style="padding: 40px; text-align: center;">
            <p style="color: var(--accent-red);">Xabarlarni yuklashda xatolik yuz berdi.</p>
            <button class="btn btn-secondary btn-sm" onclick="NotificationsPage.loadData()">Qayta urinish</button>
          </div>
        `;
      }
    }
  },

  renderList(container) {
    if (!this.notifications || this.notifications.length === 0) {
      container.innerHTML = `
        <div class="empty-state-box glass-panel" style="padding: 60px 20px; text-align: center; border-radius: 16px;">
          <div style="width: 56px; height: 56px; border-radius: 50%; background: var(--bg-secondary); margin: 0 auto 16px; display: flex; align-items: center; justify-content: center; color: var(--text-tertiary);">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
              <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
            </svg>
          </div>
          <h3 style="margin: 0 0 6px 0; font-size: 16px; font-weight: 600;">Hozircha yangi bildirishnomalar yo'q</h3>
          <p style="color: var(--text-secondary); font-size: 13px; max-width: 360px; margin: 0 auto;">
            Platforma administratorlari tomonidan e'lon yoki shaxsiy xabar yuborilganda bu yerda ko'rinadi.
          </p>
        </div>
      `;
      return;
    }

    const typeIcons = {
      info: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`,
      success: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`,
      warning: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>`,
      danger: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>`
    };

    const typeColors = {
      info: 'var(--accent-blue)',
      success: 'var(--accent-green)',
      warning: '#D29922',
      danger: 'var(--accent-red)'
    };

    const typeBgs = {
      info: 'rgba(56, 139, 253, 0.12)',
      success: 'rgba(63, 185, 80, 0.12)',
      warning: 'rgba(210, 153, 34, 0.12)',
      danger: 'rgba(248, 81, 73, 0.12)'
    };

    container.innerHTML = `
      <div class="notifications-stream" style="display: flex; flex-direction: column; gap: 12px;">
        ${this.notifications.map(n => {
          const color = typeColors[n.type] || typeColors.info;
          const bg = typeBgs[n.type] || typeBgs.info;
          const icon = typeIcons[n.type] || typeIcons.info;
          const isUnread = !n.is_read;
          const targetBadge = n.target_type === 'all' 
            ? `<span class="badge" style="background: rgba(56, 139, 253, 0.15); color: var(--accent-blue); font-size: 11px; padding: 2px 7px;">📢 Tizim e'loni</span>`
            : `<span class="badge" style="background: rgba(163, 113, 247, 0.15); color: #A371F7; font-size: 11px; padding: 2px 7px;">👤 Shaxsiy xabar</span>`;

          const dateStr = this.formatDate(n.created_at);

          return `
            <div class="notification-card glass-panel ${isUnread ? 'is-unread' : 'is-read'}" 
                 id="notif-${n.id}"
                 style="position: relative; padding: 18px 20px; border-radius: 14px; border-left: 4px solid ${color}; transition: all 0.2s ease;">
              
              <div style="display: flex; align-items: flex-start; gap: 14px;">
                <!-- Type Icon -->
                <div style="width: 36px; height: 36px; border-radius: 10px; background: ${bg}; color: ${color}; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 2px;">
                  ${icon}
                </div>

                <!-- Main Content -->
                <div style="flex: 1; min-width: 0;">
                  <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 6px;">
                    ${targetBadge}
                    <h3 style="margin: 0; font-size: 15px; font-weight: 600; color: var(--text-primary); line-height: 1.3;">
                      ${this.escapeHtml(n.title)}
                    </h3>
                    ${isUnread ? `<span class="unread-dot" title="O'qilmagan" style="width: 8px; height: 8px; border-radius: 50%; background: var(--accent-blue); box-shadow: 0 0 8px var(--accent-blue);"></span>` : ''}
                  </div>

                  <div style="color: var(--text-secondary); font-size: 13.5px; line-height: 1.55; white-space: pre-wrap; word-break: break-word;">
                    ${this.escapeHtml(n.message)}
                  </div>

                  <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 10px; font-size: 11.5px; color: var(--text-tertiary);">
                    <span>${dateStr}</span>
                    ${isUnread ? `
                      <button class="btn btn-ghost btn-xs" onclick="NotificationsPage.markSingleRead(${n.id})" style="font-size: 11.5px; padding: 3px 8px; color: var(--accent-blue);">
                        ✓ O'qildi deb belgilash
                      </button>
                    ` : `
                      <span style="display: inline-flex; align-items: center; gap: 4px; color: var(--text-tertiary);">
                        ✓ O'qilgan
                      </span>
                    `}
                  </div>
                </div>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  },

  async markSingleRead(id) {
    try {
      await API.markNotificationRead(id);
      const card = document.getElementById(`notif-${id}`);
      if (card) {
        card.classList.remove('is-unread');
        card.classList.add('is-read');
      }
      this.unreadCount = Math.max(0, this.unreadCount - 1);
      this.updateBadges(this.unreadCount);
      // Reload list if in unread tab
      if (this.currentFilter === 'unread') {
        this.loadData();
      } else {
        const notif = this.notifications.find(n => n.id === id);
        if (notif) notif.is_read = true;
        const listEl = document.getElementById('notifications-list-container');
        if (listEl) this.renderList(listEl);
      }
    } catch (e) {
      console.error("Xatoni o'qilgan deb belgilashda xatolik:", e);
    }
  },

  async markAllRead() {
    try {
      await API.markAllNotificationsRead();
      if (window.Toast) {
        Toast.show("Barcha bildirishnomalar o'qilgan deb belgilandi", "success");
      }
      this.unreadCount = 0;
      this.updateBadges(0);
      await this.loadData();
    } catch (e) {
      console.error("Barchasini o'qishda xatolik:", e);
    }
  },

  setFilter(filter) {
    this.currentFilter = filter;
    document.querySelectorAll('.tab-pill').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-filter') === filter);
    });
    this.loadData();
  },

  updateBadges(count) {
    // 1. Sidebar badge
    const sidebarBadge = document.getElementById('sidebar-notif-badge');
    if (sidebarBadge) {
      if (count > 0) {
        sidebarBadge.textContent = count > 99 ? '99+' : count;
        sidebarBadge.style.display = 'inline-flex';
      } else {
        sidebarBadge.style.display = 'none';
      }
    }

    // 2. Topbar Bell badge
    const topbarBadge = document.getElementById('topbar-notif-badge');
    if (topbarBadge) {
      if (count > 0) {
        topbarBadge.textContent = count > 99 ? '99+' : count;
        topbarBadge.style.display = 'inline-flex';
      } else {
        topbarBadge.style.display = 'none';
      }
    }
  },

  formatDate(isoStr) {
    if (!isoStr) return '';
    try {
      const d = new Date(isoStr);
      const now = new Date();
      const diffMs = now - d;
      const diffMins = Math.floor(diffMs / (1000 * 60));
      const diffHours = Math.floor(diffMins / 60);

      if (diffMins < 1) return "Hozirgina";
      if (diffMins < 60) return `${diffMins} daqiqa oldin`;
      if (diffHours < 24) return `${diffHours} soat oldin`;

      return d.toLocaleDateString('uz-UZ', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return isoStr;
    }
  },

  escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
};
