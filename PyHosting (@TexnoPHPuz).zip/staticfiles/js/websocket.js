// PyHosting.uz - WebSocket Real-Time Bot Logs Manager
class BotLogsStream {
  constructor(fileId, callbacks = {}) {
    this.fileId = fileId;
    this.callbacks = callbacks; // onLog, onStatus, onSystem, onOpen, onClose
    this.socket = null;
    this.isManualClosed = false;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 5;
    this.reconnectTimeout = null;
    this.pingInterval = null;
  }

  connect() {
    this.isManualClosed = false;
    const token = API.getToken();
    if (!token) {
      console.warn("WebSocket ulanishi uchun JWT token mavjud emas");
      return;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const wsUrl = `${protocol}//${host}/ws/bots/${this.fileId}/logs/?token=${encodeURIComponent(token)}`;

    try {
      this.socket = new WebSocket(wsUrl);

      this.socket.onopen = () => {
        this.reconnectAttempts = 0;
        if (this.callbacks.onOpen) this.callbacks.onOpen();
        this.startPing();
      };

      this.socket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'log' && this.callbacks.onLog) {
            this.callbacks.onLog(data);
          } else if (data.type === 'status' && this.callbacks.onStatus) {
            this.callbacks.onStatus(data);
          } else if (data.type === 'stats' && this.callbacks.onStats) {
            this.callbacks.onStats(data.data);
          } else if (data.type === 'system' && this.callbacks.onSystem) {
            this.callbacks.onSystem(data.message);
          }
        } catch (e) {
          console.error("WS message parse error:", e);
        }
      };

      this.socket.onerror = (err) => {
        console.warn("WS error:", err);
      };

      this.socket.onclose = (event) => {
        this.stopPing();
        if (this.callbacks.onClose) this.callbacks.onClose(event);
        if (!this.isManualClosed && this.reconnectAttempts < this.maxReconnectAttempts) {
          const delay = Math.min(1000 * Math.pow(1.5, this.reconnectAttempts), 8000);
          this.reconnectAttempts++;
          this.reconnectTimeout = setTimeout(() => this.connect(), delay);
        }
      };
    } catch (e) {
      console.error("WS connection exception:", e);
    }
  }

  startPing() {
    this.stopPing();
    this.pingInterval = setInterval(() => {
      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.socket.send(JSON.stringify({ action: 'ping' }));
      }
    }, 25000);
  }

  getStats() {
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify({ action: 'get_stats' }));
    }
  }

  stopPing() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  close() {
    this.isManualClosed = true;
    this.stopPing();
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
      this.reconnectTimeout = null;
    }
    if (this.socket) {
      this.socket.close();
      this.socket = null;
    }
  }
}

window.BotLogsStream = BotLogsStream;
