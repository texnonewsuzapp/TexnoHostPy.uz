// PyHosting Superadmin Dashboard View
const PanelDashboard = {
  timer: null,

  async render(container) {
    if (this.timer) clearInterval(this.timer);

    container.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px;">
        <div>
          <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.02em;">Boshqaruv Doskasi</h1>
          <p style="font-size: 13.5px; color: var(--text-secondary);">PyHosting serveri va botlarining real-vaqt telemetriyasi</p>
        </div>
        <div style="display: flex; gap: 10px;">
          <button class="btn btn-secondary btn-sm" onclick="PanelDashboard.refresh()" style="display: inline-flex; align-items: center; gap: 6px;">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg>
            <span>Yangilash</span>
          </button>
        </div>
      </div>

      <div id="metrics-loading" style="text-align: center; padding: 60px 0; color: var(--text-muted);">
        <p>Telemetriya ma'lumotlari yuklanmoqda...</p>
      </div>

      <div id="dashboard-content" style="display: none;"></div>
    `;

    await this.loadData();

    // Auto-refresh metrics every 15 seconds while on this view
    this.timer = setInterval(() => {
      this.loadData(true);
    }, 15000);
  },

  async loadData(silent = false) {
    try {
      const data = await PanelAPI.getMetrics();
      if (!data) return;

      const loadingEl = document.getElementById('metrics-loading');
      const contentEl = document.getElementById('dashboard-content');

      if (loadingEl) loadingEl.style.display = 'none';
      if (contentEl) {
        contentEl.style.display = 'block';
        contentEl.innerHTML = this.buildHTML(data);
      }

      // Update Topbar chip counters if present
      const topCpu = document.getElementById('topbar-cpu-chip');
      const topRam = document.getElementById('topbar-ram-chip');
      const topBots = document.getElementById('topbar-bots-chip');
      if (topCpu) topCpu.textContent = `CPU: ${data.telemetry.cpu_percent}%`;
      if (topRam) topRam.textContent = `RAM: ${data.telemetry.ram_percent}%`;
      if (topBots) topBots.textContent = `Botlar: ${data.platform.running_bots} faol`;

    } catch (err) {
      console.error("Dashboard error:", err);
      if (!silent) {
        const loadingEl = document.getElementById('metrics-loading');
        if (loadingEl) loadingEl.innerHTML = `<p style="color: var(--status-crashed);">Xatolik: ${err.message}</p>`;
      }
    }
  },

  refresh() {
    this.loadData();
  },

  buildHTML(data) {
    const t = data.telemetry;
    const p = data.platform;
    const s = data.settings;

    return `
      <!-- Server Hardware Telemetry -->
      <div class="metrics-grid">
        <div class="metric-tile">
          <span class="metric-tile-title">CPU Yuklanishi</span>
          <span class="metric-tile-value" style="color: ${t.cpu_percent > 80 ? 'var(--status-crashed)' : 'var(--accent-blue)'};">
            ${t.cpu_percent}%
          </span>
          <span class="metric-tile-sub">Barcha yadrolar o'rtacha yuki</span>
        </div>

        <div class="metric-tile">
          <span class="metric-tile-title">Server RAM</span>
          <span class="metric-tile-value" style="color: ${t.ram_percent > 85 ? 'var(--status-crashed)' : 'var(--accent-green)'};">
            ${t.ram_percent}%
          </span>
          <span class="metric-tile-sub">${t.ram_used_mb} MB / ${t.ram_total_mb} MB</span>
        </div>

        <div class="metric-tile">
          <span class="metric-tile-title">Server Qattiq Diski</span>
          <span class="metric-tile-value">${t.disk_percent}%</span>
          <span class="metric-tile-sub">${t.disk_used_gb} GB / ${t.disk_total_gb} GB</span>
        </div>

        <div class="metric-tile">
          <span class="metric-tile-title">Faol Botlar</span>
          <span class="metric-tile-value" style="color: var(--accent-green);">${p.running_bots}</span>
          <span class="metric-tile-sub">Jami botlar: ${p.total_bots} ta (${p.crashed_bots} crashed)</span>
        </div>
      </div>

      <!-- Platform Quick Stats Row -->
      <div class="metrics-grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));">
        <div class="metric-tile">
          <span class="metric-tile-title">Foydalanuvchilar</span>
          <span class="metric-tile-value">${p.total_users}</span>
          <span class="metric-tile-sub">Bugun qo'shilgan: +${p.today_users} ta</span>
        </div>

        <div class="metric-tile">
          <span class="metric-tile-title">Bloklanganlar</span>
          <span class="metric-tile-value" style="color: ${p.banned_users > 0 ? 'var(--status-crashed)' : 'var(--text-primary)'};">${p.banned_users}</span>
          <span class="metric-tile-sub">Faollar: ${p.active_users} ta</span>
        </div>

        <div class="metric-tile">
          <span class="metric-tile-title">Foydalanuvchi Disklari</span>
          <span class="metric-tile-value">${p.total_disk_used_mb} <span style="font-size: 16px;">MB</span></span>
          <span class="metric-tile-sub">Jami fayllar: ${p.total_files} ta</span>
        </div>

        <div class="metric-tile">
          <span class="metric-tile-title">Tizim Rejimi</span>
          <span class="metric-tile-value" style="font-size: 20px; color: ${s.maintenance_mode ? 'var(--status-crashed)' : 'var(--accent-green)'};">
            ${s.maintenance_mode ? '🔧 Maintenance' : '🟢 Ishlayapti'}
          </span>
          <span class="metric-tile-sub">Registratsiya: ${s.registration_enabled ? 'Ochiq' : 'Yopiq'}</span>
        </div>
      </div>

      <!-- Quick Actions and Recent Audit Logs -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-top: 12px;">
        <!-- Quick System Control -->
        <div class="panel-card">
          <div class="panel-card-header">
            <span class="panel-card-title">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path><circle cx="12" cy="12" r="3"></circle></svg>
              Tezkor Boshqaruv
            </span>
          </div>

          <div style="display: flex; flex-direction: column; gap: 14px;">
            <div style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: rgba(255, 255, 255, 0.03); border-radius: var(--radius-md);">
              <div>
                <div style="font-weight: 600; font-size: 14px;">Texnik Ta'mirlash Rejimi</div>
                <div style="font-size: 12px; color: var(--text-secondary);">Oddiy foydalanuvchilar uchun saytni vaqtincha yopish</div>
              </div>
              <button class="btn btn-sm ${s.maintenance_mode ? 'btn-danger' : 'btn-secondary'}" onclick="PanelDashboard.toggleMaintenance(!${s.maintenance_mode})">
                ${s.maintenance_mode ? 'O\'chirish' : 'Yoqish'}
              </button>
            </div>

            <div style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: rgba(255, 255, 255, 0.03); border-radius: var(--radius-md);">
              <div>
                <div style="font-weight: 600; font-size: 14px;">Yangi Registratsiya</div>
                <div style="font-size: 12px; color: var(--text-secondary);">Yangi hisoblar ochilishiga ruxsat berish</div>
              </div>
              <button class="btn btn-sm ${s.registration_enabled ? 'btn-secondary' : 'btn-primary'}" onclick="PanelDashboard.toggleRegistration(!${s.registration_enabled})">
                ${s.registration_enabled ? 'Vaqtincha yopish' : 'Ruxsat berish'}
              </button>
            </div>

            <div style="display: flex; gap: 10px; margin-top: 6px;">
              <button class="btn btn-primary btn-sm" onclick="PanelRouter.navigate('/broadcast')" style="flex: 1; justify-content: center;">
                📢 E'lon Yuborish
              </button>
              <button class="btn btn-secondary btn-sm" onclick="PanelRouter.navigate('/settings')" style="flex: 1; justify-content: center;">
                ⚙️ Barcha Sozlamalar
              </button>
            </div>
          </div>
        </div>

        <!-- Recent Audit Log History -->
        <div class="panel-card">
          <div class="panel-card-header">
            <span class="panel-card-title">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
              So'nggi Admin Harakatlari
            </span>
            <button class="btn btn-ghost btn-sm" onclick="PanelRouter.navigate('/audit')">
              Barchasi →
            </button>
          </div>

          <div style="display: flex; flex-direction: column; gap: 10px;">
            ${data.recent_audit_logs.length === 0 ? `
              <div style="padding: 24px; text-align: center; color: var(--text-muted); font-size: 13px;">
                Hozircha amallar jurnali bo'sh
              </div>
            ` : data.recent_audit_logs.map(log => `
              <div style="padding: 10px 12px; background: rgba(255, 255, 255, 0.02); border-radius: var(--radius-sm); border: 1px solid var(--border-subtle); display: flex; align-items: center; justify-content: space-between; font-size: 13px;">
                <div>
                  <div style="font-weight: 600;">${log.action_display}</div>
                  <div style="color: var(--text-muted); font-size: 11.5px;">${log.details || 'Amal bajarildi'}</div>
                </div>
                <div style="font-size: 11px; color: var(--text-muted); font-family: var(--font-mono); white-space: nowrap;">
                  ${log.created_at ? new Date(log.created_at).toLocaleTimeString() : ''}
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  },

  async toggleMaintenance(enable) {
    if (!confirm(enable ? "Diqqat: Sayt barcha oddiy foydalanuvchilar uchun yopiladi va Maintenance sahifasi chiqadi. Tasdiqlaysizmi?" : "Saytni qayta faollashtirasizmi?")) {
      return;
    }
    try {
      await PanelAPI.updateSettings({ maintenance_mode: enable });
      await this.loadData();
    } catch (e) {
      alert("Xatolik: " + e.message);
    }
  },

  async toggleRegistration(enable) {
    try {
      await PanelAPI.updateSettings({ registration_enabled: enable });
      await this.loadData();
    } catch (e) {
      alert("Xatolik: " + e.message);
    }
  }
};

window.PanelDashboard = PanelDashboard;
