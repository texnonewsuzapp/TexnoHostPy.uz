// PyHosting Superadmin Bots Management View
const PanelBots = {
  currentFilter: '',
  botsData: [],

  async render(container) {
    container.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px;">
        <div>
          <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.02em;">Botlar & Jarayonlar Nazorati</h1>
          <p style="font-size: 13.5px; color: var(--text-secondary);">Serverdagi barcha botlarni monitoring qilish, loglarini ko'rish va majburiy to'xtatish</p>
        </div>
        <button class="btn btn-secondary btn-sm" onclick="PanelBots.loadBots()" style="display: inline-flex; align-items: center; gap: 6px;">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg>
          <span>Yangilash</span>
        </button>
      </div>

      <!-- Filter Buttons -->
      <div style="display: flex; gap: 8px; margin-bottom: 20px;">
        <button class="btn btn-sm btn-secondary bot-filter-btn active" data-filter="" onclick="PanelBots.setFilter('', this)">Barcha botlar</button>
        <button class="btn btn-sm btn-secondary bot-filter-btn" data-filter="running" onclick="PanelBots.setFilter('running', this)">🟢 Ishlayotganlar</button>
        <button class="btn btn-sm btn-secondary bot-filter-btn" data-filter="crashed" onclick="PanelBots.setFilter('crashed', this)">🔴 Xatolik (Crashed)</button>
        <button class="btn btn-sm btn-secondary bot-filter-btn" data-filter="stopped" onclick="PanelBots.setFilter('stopped', this)">⚪ To'xtaganlar</button>
      </div>

      <div class="panel-card" style="padding: 0; overflow: hidden;">
        <div id="bots-table-container">
          <div style="padding: 50px; text-align: center; color: var(--text-muted);">
            Bot jarayonlari yuklanmoqda...
          </div>
        </div>
      </div>

      <!-- Bot Logs Modal Container -->
      <div id="bot-logs-modal-root"></div>
    `;

    await this.loadBots();
  },

  async loadBots() {
    try {
      const params = {};
      if (this.currentFilter) params.status = this.currentFilter;

      const bots = await PanelAPI.getBots(params);
      if (!bots) return;

      this.botsData = bots;
      this.renderTable(bots);
    } catch (err) {
      const container = document.getElementById('bots-table-container');
      if (container) {
        container.innerHTML = `<div style="padding: 30px; text-align: center; color: var(--status-crashed);">Xatolik: ${err.message}</div>`;
      }
    }
  },

  setFilter(filter, btn) {
    this.currentFilter = filter;
    document.querySelectorAll('.bot-filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    this.loadBots();
  },

  renderTable(bots) {
    const container = document.getElementById('bots-table-container');
    if (!container) return;

    if (bots.length === 0) {
      container.innerHTML = `
        <div style="padding: 50px; text-align: center; color: var(--text-muted);">
          Hech qanday bot jarayoni topilmadi.
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div class="panel-table-wrap">
        <table class="panel-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Bot Fayli</th>
              <th>Egasi</th>
              <th>PID / Konteyner</th>
              <th>Holati</th>
              <th>Oxirgi Yangilanish</th>
              <th style="text-align: right;">Amallar</th>
            </tr>
          </thead>
          <tbody>
            ${bots.map(b => `
              <tr>
                <td style="font-family: var(--font-mono); color: var(--text-muted); font-size: 12px;">#${b.id}</td>
                <td>
                  <div style="font-weight: 600; font-family: var(--font-mono); color: var(--text-primary);">${b.file_name}</div>
                  <div style="font-size: 11px; color: var(--text-muted);">Restart soni: ${b.restart_count}</div>
                </td>
                <td>
                  <span style="font-weight: 600; color: var(--accent-blue);">@${b.owner_username}</span>
                </td>
                <td>
                  <div style="font-family: var(--font-mono); font-size: 12px; color: var(--text-secondary);">
                    ${b.pid ? `PID: <b>${b.pid}</b>` : b.container_id ? b.container_id.substring(0, 12) : '—'}
                  </div>
                </td>
                <td>
                  <span class="badge badge-${b.status}">
                    ${b.status_display}
                  </span>
                </td>
                <td style="color: var(--text-muted); font-size: 12px;">
                  ${new Date(b.updated_at).toLocaleString()}
                </td>
                <td style="text-align: right;">
                  <div style="display: flex; gap: 6px; justify-content: flex-end;">
                    <button class="btn btn-secondary btn-sm" style="padding: 4px 8px; font-size: 12px;" onclick="PanelBots.viewLogs(${b.id})">
                      📋 Loglar
                    </button>
                    ${b.status === 'running' ? `
                      <button class="btn btn-danger btn-sm" style="padding: 4px 8px; font-size: 12px;" onclick="PanelBots.killBot(${b.id}, '${b.file_name}')">
                        🛑 Majburiy To'xtatish
                      </button>
                    ` : ''}
                  </div>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  },

  async killBot(botId, botName) {
    if (!confirm(`Diqqat: '${botName}' bot jarayoni zudlik bilan majburiy to'xtatiladi. Tasdiqlaysizmi?`)) {
      return;
    }

    try {
      await PanelAPI.killBot(botId);
      await this.loadBots();
    } catch (err) {
      alert("Xatolik: " + err.message);
    }
  },

  async viewLogs(botId) {
    const modalRoot = document.getElementById('bot-logs-modal-root');
    modalRoot.innerHTML = `
      <div class="panel-modal-backdrop" onclick="PanelBots.closeLogsModal()">
        <div class="panel-modal-content" style="max-width: 720px;" onclick="event.stopPropagation()">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
            <h3 style="font-size: 17px; font-weight: 700;">Bot Loglari</h3>
            <button class="btn btn-ghost btn-sm" onclick="PanelBots.closeLogsModal()">✕</button>
          </div>
          <div id="bot-logs-body" style="background: #05070A; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; font-family: var(--font-mono); font-size: 12.5px; height: 360px; overflow-y: auto; color: #E6EDF3;">
            Loglar yuklanmoqda...
          </div>
        </div>
      </div>
    `;

    try {
      const res = await PanelAPI.getBotLogs(botId);
      const logBody = document.getElementById('bot-logs-body');
      if (!logBody) return;

      if (!res.logs || res.logs.length === 0) {
        logBody.innerHTML = `<span style="color: var(--text-muted);">Hech qanday log yozuvlari mavjud emas.</span>`;
        return;
      }

      logBody.innerHTML = res.logs.map(l => {
        const color = l.level === 'ERROR' ? '#F85149' : l.level === 'WARNING' ? '#D29922' : '#8B949E';
        return `<div><span style="color: ${color};">[${l.timestamp}] [${l.level}]</span> ${this.escapeHTML(l.message)}</div>`;
      }).join('');
      logBody.scrollTop = logBody.scrollHeight;
    } catch (err) {
      const logBody = document.getElementById('bot-logs-body');
      if (logBody) logBody.innerHTML = `<span style="color: var(--status-crashed);">Xatolik: ${err.message}</span>`;
    }
  },

  closeLogsModal() {
    const modalRoot = document.getElementById('bot-logs-modal-root');
    if (modalRoot) modalRoot.innerHTML = '';
  },

  escapeHTML(str) {
    return (str || '').replace(/[&<>"']/g, function(m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
    });
  }
};

window.PanelBots = PanelBots;
