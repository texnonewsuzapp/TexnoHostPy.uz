// PyHosting Superadmin Users Management View
const PanelUsers = {
  currentFilter: '',
  searchQuery: '',
  usersData: [],

  async render(container) {
    container.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; flex-wrap: wrap; gap: 14px;">
        <div>
          <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.02em;">Foydalanuvchilar Boshqaruvi</h1>
          <p style="font-size: 13.5px; color: var(--text-secondary);">Hisoblar, disk kvotalari va bot limitlarini boshqarish</p>
        </div>

        <div style="display: flex; gap: 10px; align-items: center;">
          <input
            type="text"
            id="user-search-input"
            class="form-control"
            placeholder="Username yoki email qidirish..."
            style="width: 260px; padding: 8px 12px; font-size: 13px;"
            oninput="PanelUsers.handleSearch(this.value)"
          />
        </div>
      </div>

      <!-- Filters Row -->
      <div style="display: flex; gap: 8px; margin-bottom: 20px;">
        <button class="btn btn-sm btn-secondary filter-btn active" data-filter="" onclick="PanelUsers.setFilter('', this)">Barchasi</button>
        <button class="btn btn-sm btn-secondary filter-btn" data-filter="active" onclick="PanelUsers.setFilter('active', this)">Faollar</button>
        <button class="btn btn-sm btn-secondary filter-btn" data-filter="banned" onclick="PanelUsers.setFilter('banned', this)">Bloklanganlar</button>
        <button class="btn btn-sm btn-secondary filter-btn" data-filter="admin" onclick="PanelUsers.setFilter('admin', this)">Adminlar</button>
      </div>

      <div class="panel-card" style="padding: 0; overflow: hidden;">
        <div id="users-table-container">
          <div style="padding: 50px; text-align: center; color: var(--text-muted);">
            Foydalanuvchilar ro'yxati yuklanmoqda...
          </div>
        </div>
      </div>

      <!-- User Edit Modal Container -->
      <div id="user-modal-root"></div>
    `;

    await this.loadUsers();
  },

  async loadUsers() {
    try {
      const params = {};
      if (this.currentFilter) params.status = this.currentFilter;
      if (this.searchQuery) params.q = this.searchQuery;

      const users = await PanelAPI.getUsers(params);
      if (!users) return;

      this.usersData = users;
      this.renderTable(users);
    } catch (err) {
      const container = document.getElementById('users-table-container');
      if (container) {
        container.innerHTML = `<div style="padding: 30px; text-align: center; color: var(--status-crashed);">Xatolik: ${err.message}</div>`;
      }
    }
  },

  handleSearch(val) {
    this.searchQuery = val.trim();
    clearTimeout(this._searchTimer);
    this._searchTimer = setTimeout(() => this.loadUsers(), 300);
  },

  setFilter(filter, btn) {
    this.currentFilter = filter;
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    this.loadUsers();
  },

  renderTable(users) {
    const container = document.getElementById('users-table-container');
    if (!container) return;

    if (users.length === 0) {
      container.innerHTML = `
        <div style="padding: 50px; text-align: center; color: var(--text-muted);">
          Hech qanday foydalanuvchi topilmadi.
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div class="panel-table-wrap">
        <table class="panel-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Foydalanuvchi</th>
              <th>Disk Kvotasi</th>
              <th>Botlar</th>
              <th>Holati</th>
              <th>Sana</th>
              <th style="text-align: right;">Amallar</th>
            </tr>
          </thead>
          <tbody>
            ${users.map(u => `
              <tr>
                <td style="font-family: var(--font-mono); color: var(--text-muted); font-size: 12px;">#${u.id}</td>
                <td>
                  <div style="font-weight: 600; color: var(--text-primary);">${u.username} ${u.is_superuser ? '<span style="color: var(--accent-yellow); font-size: 11px;">[SUPER]</span>' : u.is_staff ? '<span style="color: var(--accent-blue); font-size: 11px;">[ADMIN]</span>' : ''}</div>
                  <div style="font-size: 12px; color: var(--text-secondary);">${u.email}</div>
                </td>
                <td>
                  <div style="font-family: var(--font-mono); font-size: 12.5px;">
                    <b>${u.used_disk_mb}</b> / ${u.max_disk_mb} MB
                  </div>
                  <div style="font-size: 11px; color: var(--text-muted);">${u.files_count} ta fayl</div>
                </td>
                <td>
                  <span style="font-family: var(--font-mono); font-size: 12.5px;">
                    <b style="color: ${u.running_bots_count > 0 ? 'var(--accent-green)' : 'inherit'};">${u.running_bots_count}</b> / ${u.max_running_bots} faol
                  </span>
                </td>
                <td>
                  <span class="badge ${u.is_active ? 'badge-active' : 'badge-banned'}">
                    ${u.is_active ? 'Faol' : 'Bloklangan'}
                  </span>
                </td>
                <td style="color: var(--text-muted); font-size: 12px;">
                  ${new Date(u.date_joined).toLocaleDateString()}
                </td>
                <td style="text-align: right;">
                  <div style="display: flex; gap: 6px; justify-content: flex-end;">
                    <button class="btn btn-secondary btn-sm" style="padding: 4px 8px; font-size: 12px;" onclick="PanelUsers.openEditModal(${u.id})">
                      ⚙️ Kvota
                    </button>
                    <button class="btn btn-sm ${u.is_active ? 'btn-danger' : 'btn-primary'}" style="padding: 4px 8px; font-size: 12px;" onclick="PanelUsers.toggleBan(${u.id}, ${u.is_active})">
                      ${u.is_active ? '🚫 Bloklash' : '✅ Faollashtirish'}
                    </button>
                  </div>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  },

  openEditModal(userId) {
    const user = this.usersData.find(u => u.id === userId);
    if (!user) return;

    const modalRoot = document.getElementById('user-modal-root');
    modalRoot.innerHTML = `
      <div class="panel-modal-backdrop" onclick="PanelUsers.closeModal(event)">
        <div class="panel-modal-content" onclick="event.stopPropagation()">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="font-size: 18px; font-weight: 700;">'${user.username}' hisobini tahrirlash</h3>
            <button class="btn btn-ghost btn-sm" onclick="PanelUsers.closeModal()">✕</button>
          </div>

          <form onsubmit="PanelUsers.saveUserChanges(event, ${user.id})">
            <div class="form-group" style="margin-bottom: 16px;">
              <label style="font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
                Maksimal Disk Kvotasi (MB)
              </label>
              <input type="number" id="edit-max-disk" class="form-control" value="${user.max_disk_mb}" min="1" step="1" required />
              <div style="font-size: 11.5px; color: var(--text-muted); margin-top: 4px;">Hozir ishlatilgan: ${user.used_disk_mb} MB</div>
            </div>

            <div class="form-group" style="margin-bottom: 16px;">
              <label style="font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
                Maksimal Ishlayotgan Botlar Soni
              </label>
              <input type="number" id="edit-max-bots" class="form-control" value="${user.max_running_bots}" min="1" max="50" required />
            </div>

            <div class="form-group" style="margin-bottom: 24px;">
              <label style="font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
                Yangi Parol o'rnatish (ixtiyoriy)
              </label>
              <input type="password" id="edit-new-password" class="form-control" placeholder="Bo'sh qoldirilsa parol o'zgarmaydi" />
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 10px;">
              <button type="button" class="btn btn-secondary btn-sm" onclick="PanelUsers.closeModal()">Bekor qilish</button>
              <button type="submit" class="btn btn-primary btn-sm">O'zgarishlarni saqlash</button>
            </div>
          </form>
        </div>
      </div>
    `;
  },

  closeModal() {
    const modalRoot = document.getElementById('user-modal-root');
    if (modalRoot) modalRoot.innerHTML = '';
  },

  async saveUserChanges(e, userId) {
    e.preventDefault();
    const maxDisk = parseFloat(document.getElementById('edit-max-disk').value);
    const maxBots = parseInt(document.getElementById('edit-max-bots').value, 10);
    const newPass = document.getElementById('edit-new-password').value.trim();

    const payload = {
      max_disk_mb: maxDisk,
      max_running_bots: maxBots
    };
    if (newPass) payload.new_password = newPass;

    try {
      await PanelAPI.updateUser(userId, payload);
      this.closeModal();
      await this.loadUsers();
    } catch (err) {
      alert("Xatolik: " + err.message);
    }
  },

  async toggleBan(userId, currentActive) {
    const actionText = currentActive ? "bloklamoqchimisiz (barcha botlari to'xtatiladi)" : "blokdan chiqarmoqchimisiz";
    if (!confirm(`Foydalanuvchini ${actionText}?`)) return;

    try {
      await PanelAPI.updateUser(userId, { is_active: !currentActive });
      await this.loadUsers();
    } catch (err) {
      alert("Xatolik: " + err.message);
    }
  }
};

window.PanelUsers = PanelUsers;
