// PyHosting Superadmin System Settings View
const PanelSettings = {
  async render(container) {
    container.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px;">
        <div>
          <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.02em;">Tizim Sozlamalari</h1>
          <p style="font-size: 13.5px; color: var(--text-secondary);">PyHosting global konfiguratsiyasi, texnik rejim va standart kvotalar</p>
        </div>
      </div>

      <div id="settings-loading" style="text-align: center; padding: 50px 0; color: var(--text-muted);">
        Sozlamalar yuklanmoqda...
      </div>

      <div id="settings-form-container" style="display: none; max-width: 680px;"></div>
    `;

    await this.loadSettings();
  },

  async loadSettings() {
    try {
      const data = await PanelAPI.getSettings();
      if (!data) return;

      const loadingEl = document.getElementById('settings-loading');
      const formContainer = document.getElementById('settings-form-container');

      if (loadingEl) loadingEl.style.display = 'none';
      if (formContainer) {
        formContainer.style.display = 'block';
        formContainer.innerHTML = `
          <form onsubmit="PanelSettings.saveSettings(event)">
            <!-- Maintenance Mode Card -->
            <div class="panel-card">
              <div style="font-size: 16px; font-weight: 700; margin-bottom: 6px;">🔧 Texnik Ta'mirlash Rejimi (Maintenance Mode)</div>
              <p style="font-size: 13px; color: var(--text-secondary); margin-bottom: 16px;">
                Yoqilganda, oddiy foydalanuvchilar saytga kirsa, ularga "Texnik ta'mirlash ishlari olib borilmoqda" sahifasi ko'rsatiladi. Adminlar esa bemalol ishlashda davom etaveradi.
              </p>
              <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                <input type="checkbox" id="setting-maintenance" ${data.maintenance_mode ? 'checked' : ''} style="width: 18px; height: 18px;" />
                <span style="font-weight: 600; font-size: 14px;">Texnik ta'mirlash rejimini yoqish</span>
              </label>
            </div>

            <!-- Registration Card -->
            <div class="panel-card">
              <div style="font-size: 16px; font-weight: 700; margin-bottom: 6px;">👤 Ro'yxatdan O'tish Boshqaruvi</div>
              <p style="font-size: 13px; color: var(--text-secondary); margin-bottom: 16px;">
                Agar server to'lib qolsa yoki yangi akkauntlar ochilishini to'xtatmoqchi bo'lsangiz, ushbu bandni o'chirib qo'yishingiz mumkin.
              </p>
              <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                <input type="checkbox" id="setting-registration" ${data.registration_enabled ? 'checked' : ''} style="width: 18px; height: 18px;" />
                <span style="font-weight: 600; font-size: 14px;">Yangi foydalanuvchilar ro'yxatdan o'tishiga ruxsat berish</span>
              </label>
            </div>

            <!-- Default Quotas Card -->
            <div class="panel-card">
              <div style="font-size: 16px; font-weight: 700; margin-bottom: 6px;">📦 Yangi Foydalanuvchilar Standart Kvotasi</div>
              <p style="font-size: 13px; color: var(--text-secondary); margin-bottom: 18px;">
                Yangi ro'yxatdan o'tgan foydalanuvchilarga avtomatik beriladigan disk hajmi va botlar soni.
              </p>

              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
                <div class="form-group">
                  <label style="font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
                    Standart Disk (MB)
                  </label>
                  <input type="number" id="setting-disk" class="form-control" value="${data.default_disk_mb}" min="1" step="1" required />
                </div>

                <div class="form-group">
                  <label style="font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
                    Standart Botlar Soni
                  </label>
                  <input type="number" id="setting-bots" class="form-control" value="${data.default_max_bots}" min="1" max="20" required />
                </div>
              </div>

              <div class="form-group">
                <label style="font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
                  Maksimal Fayl Yuklash Hajmi (MB)
                </label>
                <input type="number" id="setting-upload-size" class="form-control" value="${data.max_upload_size_mb}" min="1" max="100" required />
              </div>
            </div>

            <!-- Google OAuth Card -->
            <div class="panel-card">
              <div style="font-size: 16px; font-weight: 700; margin-bottom: 6px;">🔑 Google OAuth Integratsiyasi</div>
              <p style="font-size: 13px; color: var(--text-secondary); margin-bottom: 14px;">
                Saytda "Google orqali kirish va ro'yxatdan o'tish" ishlashi uchun Google Cloud Console'dan olingan OAuth 2.0 Web Client ID va Client Secret ni kiriting.
              </p>

              <div class="form-group" style="margin-bottom: 14px;">
                <label style="font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
                  Google Web Client ID
                </label>
                <input type="text" id="setting-google-client-id" class="form-control" value="${data.google_client_id || ''}" placeholder="Masalan: 123456789-abcdef.apps.googleusercontent.com" />
              </div>

              <div class="form-group">
                <label style="font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
                  Google Client Secret (Ixtiyoriy)
                </label>
                <input type="text" id="setting-google-client-secret" class="form-control" value="${data.google_client_secret || ''}" placeholder="Masalan: GOCSPX-xxxxxxxxxxxxxxxx" />
              </div>
            </div>

            <!-- Cloudflare Turnstile Card -->
            <div class="panel-card">
              <div style="font-size: 16px; font-weight: 700; margin-bottom: 6px;">🛡️ Cloudflare Turnstile (CAPTCHA) Himoyasi</div>
              <p style="font-size: 13px; color: var(--text-secondary); margin-bottom: 14px;">
                Saytda botlar va spam hujumlardan himoyalanish uchun Cloudflare Turnstile (aqlli CAPTCHA) robot tekshiruvini yoqishingiz mumkin.
              </p>

              <label style="display: flex; align-items: center; gap: 10px; cursor: pointer; margin-bottom: 14px;">
                <input type="checkbox" id="setting-turnstile-enabled" ${data.turnstile_enabled ? 'checked' : ''} style="width: 18px; height: 18px;" />
                <span style="font-weight: 600; font-size: 13.5px;">Turnstile (CAPTCHA) himoyasini faollashtirish</span>
              </label>

              <div class="form-group" style="margin-bottom: 14px;">
                <label style="font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
                  Cloudflare Site Key
                </label>
                <input type="text" id="setting-turnstile-site-key" class="form-control" value="${data.turnstile_site_key || ''}" placeholder="Masalan: 0x4AAAAAA..." />
              </div>

              <div class="form-group">
                <label style="font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
                  Cloudflare Secret Key
                </label>
                <input type="text" id="setting-turnstile-secret-key" class="form-control" value="${data.turnstile_secret_key || ''}" placeholder="Masalan: 0x4AAAAAA..." />
              </div>
            </div>

            <!-- Announcement Banner Card -->
            <div class="panel-card">
              <div style="font-size: 16px; font-weight: 700; margin-bottom: 6px;">📢 Umumiy Banner E'loni</div>
              <p style="font-size: 13px; color: var(--text-secondary); margin-bottom: 14px;">
                Maintenance sahifasida yoki sayt boshida chiqadigan maxsus e'lon matni.
              </p>

              <label style="display: flex; align-items: center; gap: 10px; cursor: pointer; margin-bottom: 14px;">
                <input type="checkbox" id="setting-banner-active" ${data.announcement_active ? 'checked' : ''} style="width: 18px; height: 18px;" />
                <span style="font-weight: 600; font-size: 13.5px;">Bannerni faollashtirish</span>
              </label>

              <div class="form-group">
                <textarea id="setting-banner-text" class="form-control" rows="3" placeholder="Masalan: 12-oktabr kuni soat 02:00 dan 04:00 gacha server yangilanishi bo'lib o'tadi.">${data.announcement_banner || ''}</textarea>
              </div>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-bottom: 40px;">
              <button type="submit" id="save-settings-btn" class="btn btn-primary" style="padding: 12px 24px;">
                💾 Sozlamalarni Saqlash
              </button>
            </div>
          </form>
        `;
      }
    } catch (err) {
      const container = document.getElementById('settings-loading');
      if (container) {
        container.innerHTML = `<span style="color: var(--status-crashed);">Xatolik: ${err.message}</span>`;
      }
    }
  },

  async saveSettings(e) {
    e.preventDefault();
    const btn = document.getElementById('save-settings-btn');
    btn.disabled = true;
    btn.textContent = "Saqlanmoqda...";

    const payload = {
      maintenance_mode: document.getElementById('setting-maintenance').checked,
      registration_enabled: document.getElementById('setting-registration').checked,
      default_disk_mb: parseFloat(document.getElementById('setting-disk').value),
      default_max_bots: parseInt(document.getElementById('setting-bots').value, 10),
      max_upload_size_mb: parseInt(document.getElementById('setting-upload-size').value, 10),
      google_client_id: document.getElementById('setting-google-client-id').value.trim(),
      google_client_secret: (document.getElementById('setting-google-client-secret')?.value || '').trim(),
      turnstile_enabled: document.getElementById('setting-turnstile-enabled').checked,
      turnstile_site_key: (document.getElementById('setting-turnstile-site-key')?.value || '').trim(),
      turnstile_secret_key: (document.getElementById('setting-turnstile-secret-key')?.value || '').trim(),
      announcement_active: document.getElementById('setting-banner-active').checked,
      announcement_banner: document.getElementById('setting-banner-text').value.trim()
    };

    try {
      await PanelAPI.updateSettings(payload);
      btn.textContent = "Saqlandi!";
      setTimeout(() => {
        btn.disabled = false;
        btn.textContent = "💾 Sozlamalarni Saqlash";
      }, 1000);
    } catch (err) {
      alert("Xatolik: " + err.message);
      btn.disabled = false;
      btn.textContent = "💾 Sozlamalarni Saqlash";
    }
  }
};

window.PanelSettings = PanelSettings;
