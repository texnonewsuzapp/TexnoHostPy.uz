// PyHosting Superadmin Broadcast Studio View
const PanelBroadcast = {
  async render(container) {
    container.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px;">
        <div>
          <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.02em;">Bildirishnomalar Studiyasi</h1>
          <p style="font-size: 13.5px; color: var(--text-secondary);">Barcha foydalanuvchilarga yoki aniq bir kishiga tezkor tizim e'loni yuborish</p>
        </div>
      </div>

      <div class="panel-card" style="max-width: 680px;">
        <form onsubmit="PanelBroadcast.handleSend(event)">
          <div class="form-group" style="margin-bottom: 18px;">
            <label style="font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
              Bildirishnoma Sarlavhasi
            </label>
            <input type="text" id="broadcast-title" class="form-control" placeholder="Masalan: Tizim yangilandi yoki Server profilaktikasi" required />
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 18px;">
            <div class="form-group">
              <label style="font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
                Xabar Turi
              </label>
              <select id="broadcast-type" class="form-control" style="background: rgba(22, 27, 34, 0.9);">
                <option value="info">ℹ️ Ma'lumot (Moviy)</option>
                <option value="success">✅ Muvaffaqiyat (Yashil)</option>
                <option value="warning">⚠️ Ogohlantirish (Sariq)</option>
                <option value="danger">🚨 Muhim / Xavf (Qizil)</option>
              </select>
            </div>

            <div class="form-group">
              <label style="font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
                Yuborish Qamrovi
              </label>
              <select id="broadcast-target" class="form-control" style="background: rgba(22, 27, 34, 0.9);" onchange="PanelBroadcast.onTargetChange(this.value)">
                <option value="all">📢 Barcha foydalanuvchilar (Broadcast)</option>
                <option value="single">👤 Alohida foydalanuvchiga (Single User)</option>
              </select>
            </div>
          </div>

          <div class="form-group" id="recipient-id-group" style="display: none; margin-bottom: 18px;">
            <label style="font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
              Foydalanuvchi IDsi (User ID)
            </label>
            <input type="number" id="broadcast-recipient-id" class="form-control" placeholder="Masalan: 3" />
          </div>

          <div class="form-group" style="margin-bottom: 24px;">
            <label style="font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
              Xabar Matni
            </label>
            <textarea id="broadcast-message" class="form-control" rows="5" placeholder="Foydalanuvchilarga yetkazilishi kerak bo'lgan to'liq xabar matnini yozing..." required></textarea>
          </div>

          <div style="display: flex; justify-content: flex-end; gap: 12px;">
            <button type="submit" id="broadcast-submit-btn" class="btn btn-primary" style="padding: 12px 24px;">
              🚀 E'lonni Tarqatish
            </button>
          </div>
        </form>
      </div>
    `;
  },

  onTargetChange(val) {
    const group = document.getElementById('recipient-id-group');
    if (group) {
      group.style.display = val === 'single' ? 'block' : 'none';
    }
  },

  async handleSend(e) {
    e.preventDefault();
    const title = document.getElementById('broadcast-title').value.trim();
    const type = document.getElementById('broadcast-type').value;
    const targetType = document.getElementById('broadcast-target').value;
    const message = document.getElementById('broadcast-message').value.trim();
    const recipientInput = document.getElementById('broadcast-recipient-id');

    const payload = {
      title,
      message,
      type,
      target_type: targetType
    };

    if (targetType === 'single') {
      const recId = parseInt(recipientInput.value, 10);
      if (!recId) {
        alert("Alohida foydalanuvchiga yuborish uchun uning ID sini kiriting!");
        return;
      }
      payload.recipient_id = recId;
    }

    const btn = document.getElementById('broadcast-submit-btn');
    btn.disabled = true;
    btn.textContent = "Yuborilmoqda...";

    try {
      await PanelAPI.sendBroadcast(payload);
      alert("Bildirishnoma muvaffaqiyatli yuborildi!");
      document.getElementById('broadcast-title').value = '';
      document.getElementById('broadcast-message').value = '';
      if (recipientInput) recipientInput.value = '';
    } catch (err) {
      alert("Xatolik: " + err.message);
    } finally {
      btn.disabled = false;
      btn.textContent = "🚀 E'lonni Tarqatish";
    }
  }
};

window.PanelBroadcast = PanelBroadcast;
