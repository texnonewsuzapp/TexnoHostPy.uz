// PyHosting.uz - Central API Client with JWT Auth
const API = {
  getToken() {
    return localStorage.getItem('pyh_access_token');
  },

  getRefreshToken() {
    return localStorage.getItem('pyh_refresh_token');
  },

  setTokens(access, refresh) {
    if (access) localStorage.setItem('pyh_access_token', access);
    if (refresh) localStorage.setItem('pyh_refresh_token', refresh);
  },

  clearTokens() {
    localStorage.removeItem('pyh_access_token');
    localStorage.removeItem('pyh_refresh_token');
    localStorage.removeItem('pyh_user');
  },

  getUser() {
    try {
      const u = localStorage.getItem('pyh_user');
      return u ? JSON.parse(u) : null;
    } catch {
      return null;
    }
  },

  setUser(user) {
    localStorage.setItem('pyh_user', JSON.stringify(user));
  },

  async request(endpoint, options = {}) {
    const url = endpoint.startsWith('http') ? endpoint : endpoint;
    const headers = options.headers || {};

    const isPublicAuthEndpoint = endpoint.includes('/api/auth/login/') ||
      endpoint.includes('/api/auth/register/') ||
      endpoint.includes('/api/auth/activate/') ||
      endpoint.includes('/api/auth/resend-activation/') ||
      endpoint.includes('/api/auth/confirm-email-change/') ||
      endpoint.includes('/api/auth/turnstile/config/') ||
      endpoint.includes('/api/auth/google/config/') ||
      endpoint.includes('/api/auth/google/') ||
      endpoint.includes('/api/auth/check/');

    const token = this.getToken();
    if (token && !isPublicAuthEndpoint) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    if (!options.isMultipart && !headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }

    const config = {
      ...options,
      headers
    };

    try {
      const response = await fetch(url, config);

      if (response.status === 401 && !endpoint.includes('/api/auth/login/')) {
        // Token expired or invalid
        const refreshed = await this.tryRefreshToken();
        if (refreshed) {
          headers['Authorization'] = `Bearer ${this.getToken()}`;
          return fetch(url, { ...options, headers }).then(r => r.json());
        } else {
          this.clearTokens();
          if (!window.location.pathname.startsWith('/auth') && window.location.pathname !== '/') {
            window.location.href = '/auth/';
          }
          throw new Error('Sessiya muddati tugadi, iltimos qayta kiring.');
        }
      }

      if (response.status === 204) {
        return null;
      }

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        const errorMsg = data.error || data.detail || (typeof data === 'object' ? Object.values(data)[0] : 'Xatolik yuz berdi');
        const err = new Error(Array.isArray(errorMsg) ? errorMsg[0] : errorMsg);
        err.data = data;
        err.status = response.status;
        throw err;
      }

      return data;
    } catch (err) {
      throw err;
    }
  },

  async tryRefreshToken() {
    const refresh = this.getRefreshToken();
    if (!refresh) return false;
    try {
      const res = await fetch('/api/auth/refresh/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh })
      });
      if (res.ok) {
        const data = await res.json();
        this.setTokens(data.access, data.refresh || refresh);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  },

  get(endpoint) {
    return this.request(endpoint, { method: 'GET' });
  },

  post(endpoint, data = {}, isMultipart = false) {
    return this.request(endpoint, {
      method: 'POST',
      body: isMultipart ? data : JSON.stringify(data),
      isMultipart
    });
  },

  patch(endpoint, data = {}) {
    return this.request(endpoint, {
      method: 'PATCH',
      body: JSON.stringify(data)
    });
  },

  delete(endpoint) {
    return this.request(endpoint, { method: 'DELETE' });
  },

  // Notification endpoints
  getNotifications(filter = 'all') {
    return this.get(`/api/notifications/?filter=${encodeURIComponent(filter)}`);
  },
  getUnreadNotificationCount() {
    return this.get('/api/notifications/unread-count/');
  },
  markNotificationRead(id) {
    return this.post(`/api/notifications/${id}/read/`);
  },
  markAllNotificationsRead() {
    return this.post('/api/notifications/read-all/');
  }
};

window.API = API;
