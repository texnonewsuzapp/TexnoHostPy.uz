// PyHosting.uz - File Action Context Menu Component
const ContextMenu = {
  menuEl: null,

  init() {
    if (!this.menuEl) {
      this.menuEl = document.createElement('div');
      this.menuEl.className = 'context-menu';
      document.body.appendChild(this.menuEl);

      // Close menu on click elsewhere
      document.addEventListener('click', (e) => {
        if (!this.menuEl.contains(e.target)) {
          this.hide();
        }
      });
      window.addEventListener('resize', () => this.hide());
    }
  },

  show(x, y, items) {
    this.init();
    this.menuEl.innerHTML = '';

    items.forEach(item => {
      if (item.type === 'divider') {
        const div = document.createElement('div');
        div.className = 'context-divider';
        this.menuEl.appendChild(div);
      } else {
        const el = document.createElement('div');
        el.className = `context-item ${item.isDanger ? 'danger' : ''}`;
        el.innerHTML = `<span>${item.icon || '•'}</span> <span>${item.label}</span>`;
        el.onclick = (e) => {
          e.stopPropagation();
          this.hide();
          item.onClick();
        };
        this.menuEl.appendChild(el);
      }
    });

    this.menuEl.classList.add('active');

    // Adjust position to stay in viewport
    const menuWidth = this.menuEl.offsetWidth || 190;
    const menuHeight = this.menuEl.offsetHeight || 200;
    const posX = Math.min(x, window.innerWidth - menuWidth - 10);
    const posY = Math.min(y, window.innerHeight - menuHeight - 10);

    this.menuEl.style.left = `${posX}px`;
    this.menuEl.style.top = `${posY}px`;
  },

  hide() {
    if (this.menuEl) {
      this.menuEl.classList.remove('active');
    }
  }
};

window.ContextMenu = ContextMenu;
