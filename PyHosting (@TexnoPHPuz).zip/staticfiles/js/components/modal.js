// PyHosting.uz - Modern Native Modal Dialog Component
const Modal = {
  dialog: null,

  init() {
    if (!this.dialog) {
      this.dialog = document.createElement('dialog');
      this.dialog.className = 'custom-modal';
      document.body.appendChild(this.dialog);

      // Light dismiss when clicking outside dialog content
      this.dialog.addEventListener('click', (e) => {
        const rect = this.dialog.getBoundingClientRect();
        const isInDialog = (
          rect.top <= e.clientY && e.clientY <= rect.top + rect.height &&
          rect.left <= e.clientX && e.clientX <= rect.left + rect.width
        );
        if (!isInDialog) {
          this.close();
        }
      });

      this.dialog.addEventListener('cancel', (e) => {
        e.preventDefault();
        this.close();
      });
    }
  },

  async close() {
    if (!this.dialog || !this.dialog.open) return;
    this.dialog.setAttribute('data-closing', '');
    const animations = this.dialog.getAnimations({ subtree: true });
    if (animations.length > 0) {
      await Promise.race([
        Promise.allSettled(animations.map(a => a.finished)),
        new Promise(r => setTimeout(r, 300))
      ]);
    }
    this.dialog.removeAttribute('data-closing');
    this.dialog.close();
  },

  confirm({ title = "Tasdiqlash", message = "Haqiqatan ham bu amalni bajarmoqchimisiz?", confirmText = "Ha, davom etish", cancelText = "Bekor qilish", isDanger = false, onConfirm = () => {} }) {
    this.init();

    this.dialog.innerHTML = `
      <div class="modal-header">
        <h3 style="font-size: 16px;">${title}</h3>
        <button class="btn btn-ghost btn-sm" id="modal-close-x" style="padding: 6px 8px; display: inline-flex; align-items: center;" title="Yopish">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
        </button>
      </div>
      <div class="modal-body">
        <p style="color: var(--text-secondary); font-size: 14.5px;">${message}</p>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary btn-sm" id="modal-cancel-btn">${cancelText}</button>
        <button class="btn ${isDanger ? 'btn-danger' : 'btn-primary'} btn-sm" id="modal-confirm-btn">${confirmText}</button>
      </div>
    `;

    document.getElementById('modal-close-x').onclick = () => this.close();
    document.getElementById('modal-cancel-btn').onclick = () => this.close();
    document.getElementById('modal-confirm-btn').onclick = async () => {
      await onConfirm();
      this.close();
    };

    this.dialog.showModal();
  },

  prompt({ title = "Kiritish", label = "Nom", defaultValue = "", placeholder = "", confirmText = "Saqlash", onConfirm = () => {} }) {
    this.init();

    this.dialog.innerHTML = `
      <div class="modal-header">
        <h3 style="font-size: 16px;">${title}</h3>
        <button class="btn btn-ghost btn-sm" id="modal-close-x" style="padding: 6px 8px; display: inline-flex; align-items: center;" title="Yopish">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group" style="margin-bottom: 0;">
          <input type="text" id="modal-prompt-input" class="form-control" value="${defaultValue}" placeholder="${placeholder || label}" autofocus />
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary btn-sm" id="modal-cancel-btn">Bekor qilish</button>
        <button class="btn btn-primary btn-sm" id="modal-confirm-btn">${confirmText}</button>
      </div>
    `;

    const input = document.getElementById('modal-prompt-input');
    document.getElementById('modal-close-x').onclick = () => this.close();
    document.getElementById('modal-cancel-btn').onclick = () => this.close();

    const doSubmit = async () => {
      const val = input.value.trim();
      if (!val) {
        Toast.error("Iltimos, maydonni to'ldiring");
        return;
      }
      await onConfirm(val);
      this.close();
    };

    document.getElementById('modal-confirm-btn').onclick = doSubmit;
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') doSubmit();
    });

    this.dialog.showModal();
    setTimeout(() => {
      input.focus();
      input.select();
    }, 50);
  },

  custom({ title, contentHtml, footerHtml = '', maxWidth = '560px', onOpen = null }) {
    this.init();
    this.dialog.style.maxWidth = maxWidth;
    this.dialog.innerHTML = `
      <div class="modal-header">
        <h3 style="font-size: 16px; font-weight: 700; display: inline-flex; align-items: center; gap: 8px;">
          ${title}
        </h3>
        <button class="btn btn-ghost btn-sm" id="modal-close-x" style="padding: 6px 8px; display: inline-flex; align-items: center;" title="Yopish">
          ${Icons.close(14)}
        </button>
      </div>
      <div class="modal-body" style="padding: 18px 22px;">
        ${contentHtml}
      </div>
      ${footerHtml ? `<div class="modal-footer">${footerHtml}</div>` : ''}
    `;

    document.getElementById('modal-close-x').onclick = () => this.close();
    this.dialog.showModal();
    if (onOpen) onOpen(this.dialog);
  },

  async openEnvManager(fileId) {
    this.init();
    if (!fileId) {
      Toast.error("Bot fayli aniqlanmadi");
      return;
    }

    const renderSecrets = (envVars) => {
      const keys = Object.keys(envVars);
      if (keys.length === 0) {
        return `
          <div style="text-align: center; padding: 24px; color: var(--text-muted); font-size: 13px;">
            <div style="margin-bottom: 8px; display: flex; justify-content: center;">${Icons.key(28, 'var(--text-muted)')}</div>
            Hozircha maxfiy o'zgaruvchilar qo'shilmagan.
          </div>
        `;
      }
      return `
        <div class="env-secrets-list">
          ${keys.map(k => {
            const val = envVars[k];
            const safeKey = k.replace(/"/g, '&quot;');
            return `
              <div class="env-item-row" id="env-row-${safeKey}">
                <div style="display: flex; align-items: center; gap: 8px; min-width: 0; flex: 1;">
                  <span class="env-key-badge">${k}</span>
                  <span class="env-val-text" id="env-val-${safeKey}" data-val="${encodeURIComponent(val)}" data-visible="false">••••••••••••</span>
                </div>
                <div style="display: flex; align-items: center; gap: 4px; flex-shrink: 0;">
                  <button class="btn btn-ghost btn-sm" onclick="Modal.toggleEnvVisibility('${safeKey}')" title="Ko'rsatish / Yashirish" style="padding: 4px 6px;">
                    <span id="env-eye-${safeKey}">${Icons.eye(14)}</span>
                  </button>
                  <button class="btn btn-ghost btn-sm" onclick="Modal.copyEnvVal('${safeKey}')" title="Nusxalash" style="padding: 4px 6px;">
                    ${Icons.copy(14)}
                  </button>
                  <button class="btn btn-ghost btn-sm" onclick="Modal.deleteEnvVar(${fileId}, '${safeKey}')" title="O'chirish" style="padding: 4px 6px; color: var(--status-crashed);">
                    ${Icons.trash(14)}
                  </button>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      `;
    };

    try {
      Toast.info("Maxfiy muhit o'zgaruvchilari yuklanmoqda...");
      const res = await API.get(`/api/bots/${fileId}/env/`);
      const envVars = res.env_vars || {};

      this.custom({
        title: `${Icons.key(16, 'var(--accent-yellow)')} <span>Xavfsiz Muhit O'zgaruvchilari (.env)</span>`,
        maxWidth: '620px',
        contentHtml: `
          <div style="margin-bottom: 14px;">
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.5; margin-bottom: 8px;">
              BOT_TOKEN, DB_PASSWORD va API kalitlarni skript ichida ochiq yozmasdan, bu yerda xavfsiz saqlang. Ular bot ishga tushganda <code style="color: var(--accent-cyan); font-family: var(--font-mono);">os.environ</code> orqali o'qiladi.
            </p>
            <div style="background: rgba(56, 139, 253, 0.08); border: 1px solid rgba(56, 139, 253, 0.2); padding: 8px 12px; border-radius: var(--radius-sm); font-size: 12px; display: flex; align-items: center; justify-content: space-between; gap: 8px;">
              <code style="color: var(--accent-blue); font-family: var(--font-mono); font-size: 11.5px;">token = os.environ.get("BOT_TOKEN")</code>
              <button class="btn btn-ghost btn-sm" onclick="navigator.clipboard.writeText('import os\\ntoken = os.environ.get(\"BOT_TOKEN\")'); Toast.success('Namuna nusxalandi!')" style="padding: 2px 8px; font-size: 11px;">
                ${Icons.copy(12)} Nusxalash
              </button>
            </div>
          </div>

          <div id="env-secrets-container">
            ${renderSecrets(envVars)}
          </div>

          <form class="env-add-form" id="env-add-form" onsubmit="event.preventDefault(); Modal.submitNewEnv(${fileId});">
            <input type="text" id="env-input-key" class="form-control" placeholder="Kalit nomi (BOT_TOKEN)" required style="font-family: var(--font-mono); font-size: 12.5px;" />
            <input type="text" id="env-input-val" class="form-control" placeholder="Qiymati" required style="font-family: var(--font-mono); font-size: 12.5px;" />
            <button type="submit" class="btn btn-primary btn-sm" id="env-save-btn" style="display: inline-flex; align-items: center; gap: 5px;">
              ${Icons.save(13)} <span>Qo'shish</span>
            </button>
          </form>
        `,
        footerHtml: `
          <div style="display: flex; align-items: center; justify-content: space-between; width: 100%;">
            <span style="font-size: 11.5px; color: var(--text-muted); display: inline-flex; align-items: center; gap: 5px;">
              ${Icons.shieldCheck(13, 'var(--accent-green)')} Docker va Subprocess uchun himoyalangan
            </span>
            <button class="btn btn-secondary btn-sm" onclick="Modal.close()">Yopish</button>
          </div>
        `
      });
    } catch (e) {
      Toast.error("Xatolik: " + e.message);
    }
  },

  toggleEnvVisibility(key) {
    const el = document.getElementById(`env-val-${key}`);
    const eyeEl = document.getElementById(`env-eye-${key}`);
    if (!el || !eyeEl) return;
    const isVisible = el.dataset.visible === 'true';
    if (isVisible) {
      el.textContent = '••••••••••••';
      el.dataset.visible = 'false';
      eyeEl.innerHTML = Icons.eye(14);
    } else {
      el.textContent = decodeURIComponent(el.dataset.val);
      el.dataset.visible = 'true';
      eyeEl.innerHTML = Icons.eyeOff(14);
    }
  },

  copyEnvVal(key) {
    const el = document.getElementById(`env-val-${key}`);
    if (el) {
      const val = decodeURIComponent(el.dataset.val);
      navigator.clipboard.writeText(val);
      Toast.success(`'${key}' qiymati nusxalandi!`);
    }
  },

  async deleteEnvVar(fileId, key) {
    try {
      await API.delete(`/api/bots/${fileId}/env/`, { key });
      Toast.success(`'${key}' o'chirildi`);
      const row = document.getElementById(`env-row-${key}`);
      if (row) row.remove();
      const list = document.querySelector('.env-secrets-list');
      if (list && list.children.length === 0) {
        Modal.openEnvManager(fileId);
      }
    } catch (e) {
      Toast.error(e.message);
    }
  },

  async submitNewEnv(fileId) {
    const keyInput = document.getElementById('env-input-key');
    const valInput = document.getElementById('env-input-val');
    if (!keyInput || !valInput) return;
    const key = keyInput.value.trim().toUpperCase().replace(/[^A-Z0-9_]/g, '_');
    const value = valInput.value.trim();
    if (!key || !value) {
      Toast.error("Kalit va qiymatni to'ldiring");
      return;
    }

    try {
      const saveBtn = document.getElementById('env-save-btn');
      if (saveBtn) saveBtn.disabled = true;
      await API.post(`/api/bots/${fileId}/env/`, { key, value });
      Toast.success(`'${key}' o'zgaruvchisi saqlandi!`);
      Modal.openEnvManager(fileId);
    } catch (e) {
      Toast.error(e.message);
      const saveBtn = document.getElementById('env-save-btn');
      if (saveBtn) saveBtn.disabled = false;
    }
  },

  async openPipManager(fileId = null) {
    this.init();
    try {
      Toast.info("Pip paketlar ro'yxati tekshirilmoqda...");
      const data = await API.get('/api/bots/pip/');
      const packages = data.popular_packages || [];

      this.custom({
        title: `${Icons.package(16, 'var(--accent-blue)')} <span>Vizual Pip Paketlar Menejeri</span>`,
        maxWidth: '700px',
        contentHtml: `
          <!-- Section 1: requirements.txt 1-click install -->
          <div style="background: rgba(56, 139, 253, 0.07); border: 1px solid rgba(56, 139, 253, 0.2); border-radius: var(--radius-md); padding: 12px 14px; margin-bottom: 14px; display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap;">
            <div>
              <div style="font-weight: 700; font-size: 13.5px; color: var(--text-primary); margin-bottom: 2px;">
                ${Icons.fileCode(14, 'var(--accent-blue)')} requirements.txt orqali o'rnatish
              </div>
              <div style="font-size: 12px; color: var(--text-secondary);">
                Papkadagi requirements.txt faylida ko'rsatilgan barcha kutubxonalarni 1-bosishda o'rnating
              </div>
            </div>
            <button class="btn btn-primary btn-sm" id="pip-req-btn" onclick="Modal.installPipRequirements(${fileId})" style="display: inline-flex; align-items: center; gap: 6px;">
              ${Icons.downloadCloud(13)} <span>Kutubxonalarni o'rnatish</span>
            </button>
          </div>

          <!-- Section 2: Custom install input -->
          <div style="margin-bottom: 16px;">
            <label style="font-size: 12px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: block;">
              Ixtiyoriy paket nomi bilan o'rnatish:
            </label>
            <form onsubmit="event.preventDefault(); Modal.installCustomPip(${fileId});" style="display: flex; gap: 8px;">
              <input type="text" id="pip-custom-input" class="form-control" placeholder="Masalan: openai, beautifulsoup4, redis..." style="font-family: var(--font-mono); font-size: 12.5px;" />
              <button type="submit" class="btn btn-secondary btn-sm" id="pip-custom-btn" style="display: inline-flex; align-items: center; gap: 6px; flex-shrink: 0;">
                ${Icons.downloadCloud(13)} <span>O'rnatish</span>
              </button>
            </form>
          </div>

          <!-- Section 3: Popular packages catalog -->
          <div style="margin-bottom: 10px;">
            <div style="font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: var(--text-secondary); margin-bottom: 8px;">
              Ommabop Bot Kutubxonalari Katalogi:
            </div>
            <div class="pip-catalog-grid">
              ${packages.map(p => {
                const isInstalled = p.installed;
                return `
                  <div class="pip-card">
                    <div>
                      <div class="pip-card-name">${p.name}</div>
                      <div class="pip-card-desc">${p.description}</div>
                    </div>
                    <div class="pip-card-footer">
                      ${isInstalled ? `
                        <span class="status-pill status-running" style="font-size: 10.5px; padding: 2px 7px;">
                          ${Icons.check(11)} O'rnatilgan
                        </span>
                        <button class="btn btn-ghost btn-sm" onclick="Modal.installPipPackage('${p.name}', ${fileId})" title="Yangilash" style="padding: 2px 6px; font-size: 11px;">
                          ${Icons.refresh(11)}
                        </button>
                      ` : `
                        <button class="btn btn-secondary btn-sm" id="pip-btn-${p.name}" onclick="Modal.installPipPackage('${p.name}', ${fileId})" style="width: 100%; justify-content: center; padding: 3px 8px; font-size: 11px; display: inline-flex; align-items: center; gap: 4px;">
                          ${Icons.downloadCloud(12)} <span>O'rnatish</span>
                        </button>
                      `}
                    </div>
                  </div>
                `;
              }).join('')}
            </div>
          </div>

          <!-- Section 4: Live Pip Console Drawer -->
          <div id="pip-console-container" style="display: none;">
            <div style="font-size: 11.5px; font-weight: 600; color: var(--text-muted); margin-bottom: 4px; display: flex; align-items: center; gap: 5px;">
              ${Icons.terminal(12)} Pip Terminal Natijasi:
            </div>
            <div class="pip-console-drawer" id="pip-console-output"></div>
          </div>
        `,
        footerHtml: `
          <div style="display: flex; align-items: center; justify-content: space-between; width: 100%;">
            <span style="font-size: 11.5px; color: var(--text-muted);">
              Izolyatsiyalangan venv muhiti (50MB kvota doirasida)
            </span>
            <button class="btn btn-secondary btn-sm" onclick="Modal.close()">Yopish</button>
          </div>
        `
      });
    } catch (e) {
      Toast.error("Xatolik: " + e.message);
    }
  },

  async installPipPackage(pkgName, fileId) {
    const btn = document.getElementById(`pip-btn-${pkgName}`);
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = `${Icons.refresh(12)} <span>O'rnatilmoqda...</span>`;
    }
    Toast.info(`'${pkgName}' o'rnatilmoqda, kuting...`);

    try {
      const res = await API.post('/api/bots/pip/install/', {
        package: pkgName,
        file_id: fileId
      });
      Toast.success(res.message);
      Modal.showPipConsole(res.stdout || res.message);
      setTimeout(() => Modal.openPipManager(fileId), 1500);
    } catch (e) {
      Toast.error(`O'rnatishda xatolik: ` + e.message);
      Modal.showPipConsole(e.message);
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `${Icons.downloadCloud(12)} <span>O'rnatish</span>`;
      }
    }
  },

  async installCustomPip(fileId) {
    const input = document.getElementById('pip-custom-input');
    const btn = document.getElementById('pip-custom-btn');
    if (!input) return;
    const pkgName = input.value.trim();
    if (!pkgName) {
      Toast.error("Paket nomini kiriting");
      return;
    }

    if (btn) btn.disabled = true;
    Toast.info(`'${pkgName}' o'rnatilmoqda...`);

    try {
      const res = await API.post('/api/bots/pip/install/', {
        package: pkgName,
        file_id: fileId
      });
      Toast.success(res.message);
      Modal.showPipConsole(res.stdout || res.message);
      setTimeout(() => Modal.openPipManager(fileId), 1500);
    } catch (e) {
      Toast.error(`Xatolik: ` + e.message);
      Modal.showPipConsole(e.message);
      if (btn) btn.disabled = false;
    }
  },

  async installPipRequirements(fileId) {
    const btn = document.getElementById('pip-req-btn');
    if (btn) btn.disabled = true;
    Toast.info("requirements.txt bo'yicha paketlar o'rnatilmoqda...");

    try {
      const res = await API.post('/api/bots/pip/install/', {
        file_id: fileId
      });
      Toast.success(res.message);
      Modal.showPipConsole(res.stdout || res.message);
      setTimeout(() => Modal.openPipManager(fileId), 2000);
    } catch (e) {
      Toast.error(e.message);
      Modal.showPipConsole(e.message);
      if (btn) btn.disabled = false;
    }
  },

  showPipConsole(text) {
    const container = document.getElementById('pip-console-container');
    const output = document.getElementById('pip-console-output');
    if (container && output) {
      container.style.display = 'block';
      output.textContent = text;
      output.scrollTop = output.scrollHeight;
    }
  }
};

window.Modal = Modal;
