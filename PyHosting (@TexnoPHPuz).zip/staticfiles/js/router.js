// PyHosting.uz - Modern HTML5 History API Client-Side SPA Router
// Immediate URL sanitization before DOM/scripts execute
(function sanitizeInitialUrl() {
  if (typeof window !== 'undefined' && window.location.hash) {
    const raw = window.location.hash.replace(/^#\/?/, '');
    const cleanSub = raw ? '/' + raw : '/home';
    window.history.replaceState(null, '', '/app' + cleanSub);
  }
})();

const Router = {
  routes: {},
  currentRoute: null,
  basePrefix: '/app',

  init(routes) {
    this.routes = routes;

    // Handle browser back/forward buttons
    window.addEventListener('popstate', () => this.handleRoute());

    // Auto-migrate any hash changes immediately to clean HTML5 URLs
    window.addEventListener('hashchange', () => {
      if (window.location.hash) {
        const raw = window.location.hash.replace(/^#\/?/, '');
        const cleanSub = raw ? '/' + raw : '/home';
        window.history.replaceState(null, '', this.basePrefix + cleanSub);
        this.handleRoute();
      }
    });

    // Intercept clicks on links and data-route attributes for smooth SPA transitions
    document.addEventListener('click', (e) => {
      // 1. Any element with [data-route]
      const routeEl = e.target.closest('[data-route]');
      if (routeEl) {
        e.preventDefault();
        const targetRoute = routeEl.getAttribute('data-route');
        if (targetRoute) {
          this.navigate(targetRoute);
          return;
        }
      }

      // 2. Any standard <a href="/app/..."> link
      const anchor = e.target.closest('a[href^="/app"]');
      if (anchor && !anchor.hasAttribute('target') && !anchor.hasAttribute('download')) {
        e.preventDefault();
        const href = anchor.getAttribute('href');
        this.navigate(href);
      }
    });

    this.handleRoute();
  },

  navigate(path) {
    if (!path) path = '/home';

    // Strip any accidental '#'
    path = path.replace(/^#\/?/, '/');

    // Remove /app prefix if already passed
    if (path.startsWith(this.basePrefix)) {
      path = path.slice(this.basePrefix.length);
    }

    if (!path || path === '/') {
      path = '/home';
    }

    if (!path.startsWith('/')) {
      path = '/' + path;
    }

    const fullUrl = this.basePrefix + path;

    // Push clean state and ensure no hash remains
    if (window.location.pathname !== fullUrl || window.location.hash) {
      window.history.pushState(null, '', fullUrl);
    }

    this.handleRoute();
  },

  handleRoute() {
    // If a hash exists, convert it immediately
    if (window.location.hash) {
      const raw = window.location.hash.replace(/^#\/?/, '');
      const cleanSub = raw ? '/' + raw : '/home';
      window.history.replaceState(null, '', this.basePrefix + cleanSub);
    }

    let currentPath = window.location.pathname;

    // Remove /app prefix to get internal sub-route
    if (currentPath.startsWith(this.basePrefix)) {
      currentPath = currentPath.slice(this.basePrefix.length);
    }

    if (!currentPath || currentPath === '/' || currentPath === '') {
      currentPath = '/home';
    }
    if (!currentPath.startsWith('/')) {
      currentPath = '/' + currentPath;
    }

    // Match routes
    for (const pattern in this.routes) {
      const match = this.matchRoute(pattern, currentPath);
      if (match) {
        if (this.currentRoute && this.currentRoute.startsWith('/logs') && !pattern.startsWith('/logs')) {
          if (window.LogsViewer && typeof window.LogsViewer.destroy === 'function') {
            window.LogsViewer.destroy();
          }
        }
        this.currentRoute = pattern;
        this.updateActiveNav(pattern);
        if (window.App && typeof window.App.toggleSidebar === 'function') {
          window.App.toggleSidebar(false);
        }
        this.routes[pattern](match.params);
        return;
      }
    }

    // Fallback to /home
    if (this.routes['/home'] && currentPath !== '/home') {
      this.navigate('/home');
    }
  },

  matchRoute(pattern, path) {
    const patternParts = pattern.split('/').filter(Boolean);
    const pathParts = path.split('/').filter(Boolean);

    if (patternParts.length !== pathParts.length) return null;

    const params = {};
    for (let i = 0; i < patternParts.length; i++) {
      if (patternParts[i].startsWith(':')) {
        const paramName = patternParts[i].slice(1);
        params[paramName] = pathParts[i];
      } else if (patternParts[i] !== pathParts[i]) {
        return null;
      }
    }

    return { params };
  },

  updateActiveNav(routePattern) {
    const links = document.querySelectorAll('.sidebar-link');
    links.forEach(l => {
      const target = l.getAttribute('data-route') || (l.getAttribute('href') ? l.getAttribute('href').replace(/^\/app/, '') : null);
      if (target && (routePattern === target || (target !== '/home' && routePattern.startsWith(target)))) {
        l.classList.add('active');
      } else {
        l.classList.remove('active');
      }
    });
  }
};

window.Router = Router;
