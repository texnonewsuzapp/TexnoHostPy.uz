
const PanelRouter = {
  routes: {},
  currentRoute: null,
  basePrefix: '/panel',

  init(routes) {
    this.routes = routes;

    window.addEventListener('popstate', () => this.handleRoute());

    document.addEventListener('click', (e) => {
      const link = e.target.closest('[data-panel-route]') || e.target.closest('a[href^="/panel"]');
      if (link && !link.hasAttribute('target') && !link.getAttribute('href')?.includes('/login/')) {
        e.preventDefault();
        const targetRoute = link.getAttribute('data-panel-route') || link.getAttribute('href');
        this.navigate(targetRoute);
      }
    });

    this.handleRoute();
  },

  navigate(path) {
    if (!path) path = '/dashboard';

    path = path.replace(/^#\/?/, '/');

    if (path.startsWith(this.basePrefix)) {
      path = path.slice(this.basePrefix.length);
    }

    if (!path || path === '/') path = '/dashboard';
    if (!path.startsWith('/')) path = '/' + path;

    const fullUrl = this.basePrefix + path;

    if (window.location.pathname !== fullUrl || window.location.hash) {
      window.history.pushState(null, '', fullUrl);
    }

    this.handleRoute();
  },

  handleRoute() {
    let currentPath = window.location.pathname;

    if (currentPath.startsWith(this.basePrefix)) {
      currentPath = currentPath.slice(this.basePrefix.length);
    }

    if (!currentPath || currentPath === '/' || currentPath === '') {
      currentPath = '/dashboard';
    }
    if (!currentPath.startsWith('/')) {
      currentPath = '/' + currentPath;
    }

    for (const pattern in this.routes) {
      if (pattern === currentPath) {
        this.currentRoute = pattern;
        this.updateActiveNav(pattern);
        this.routes[pattern]();
        return;
      }
    }

    if (this.routes['/dashboard'] && currentPath !== '/dashboard') {
      this.navigate('/dashboard');
    }
  },

  updateActiveNav(routePattern) {
    const links = document.querySelectorAll('.panel-nav-link');
    links.forEach(l => {
      const target = l.getAttribute('data-panel-route') || l.getAttribute('href')?.replace(/^\/panel/, '');
      if (target && target === routePattern) {
        l.classList.add('active');
      } else {
        l.classList.remove('active');
      }
    });
  }
};

window.PanelRouter = PanelRouter;
