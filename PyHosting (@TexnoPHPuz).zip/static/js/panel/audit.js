
const PanelAudit = {
  async render(container) {
    container.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px;">
        <div>
          <h1 style="font-size: 24px; font-weight: 800; letter-spacing: -0.02em;">Audit & Xavfsizlik Jurnali</h1>
          <p style="font-size: 13.5px; color: var(--text-secondary);">Superadmin amallari, kvota o'zgartirishlar, banlar va bot to'xtatishlar tarixi</p>
        </div>
        <button class="btn btn-secondary btn-sm" onclick="PanelAudit.loadLogs()" style="display: inline-flex; align-items: center; gap: 6px;">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg>
          <span>Yangilash</span>
        </button>
      </div>

      <div class="panel-card" style="padding: 0; overflow: hidden;">
        <div id="audit-table-container">
          <div style="padding: 50px; text-align: center; color: var(--text-muted);">
            Audit yozuvlari yuklanmoqda...
          </div>
        </div>
      </div>
    `;

    await this.loadLogs();
  },

  async loadLogs() {
    try {
      const logs = await PanelAPI.getAuditLogs();
      if (!logs) return;

      const container = document.getElementById('audit-table-container');
      if (!container) return;

      if (logs.length === 0) {
        container.innerHTML = `
          <div style="padding: 50px; text-align: center; color: var(--text-muted);">
            Hozircha audit jurnali bo'sh.
          </div>
        `;
        return;
      }

      container.innerHTML = `
        <div class="panel-table-wrap">
          <table class="panel-table">
            <thead>
              <tr>
                <th>Vaqt</th>
                <th>Admin</th>
                <th>Harakat</th>
                <th>Nishon Foydalanuvchi</th>
                <th>Tafsilotlar</th>
                <th>IP Manzil</th>
              </tr>
            </thead>
            <tbody>
              ${logs.map(l => `
                <tr>
                  <td style="color: var(--text-muted); font-size: 12px; font-family: var(--font-mono); white-space: nowrap;">
                    ${new Date(l.created_at).toLocaleString()}
                  </td>
                  <td>
                    <span style="font-weight: 600; color: var(--accent-blue);">@${l.admin_username}</span>
                  </td>
                  <td>
                    <span style="font-weight: 600; font-size: 13px;">${l.action_display}</span>
                  </td>
                  <td>
                    ${l.target_username ? `<span style="font-weight: 600; color: #A371F7;">@${l.target_username}</span>` : '—'}
                  </td>
                  <td style="color: var(--text-secondary); font-size: 12.5px; max-width: 320px;">
                    ${l.details || '—'}
                  </td>
                  <td style="font-family: var(--font-mono); color: var(--text-muted); font-size: 12px;">
                    ${l.ip_address || '127.0.0.1'}
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    } catch (err) {
      const container = document.getElementById('audit-table-container');
      if (container) {
        container.innerHTML = `<div style="padding: 30px; text-align: center; color: var(--status-crashed);">Xatolik: ${err.message}</div>`;
      }
    }
  }
};

window.PanelAudit = PanelAudit;
