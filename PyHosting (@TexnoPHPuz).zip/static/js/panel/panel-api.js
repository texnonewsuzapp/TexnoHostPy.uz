
const PanelAPI = {
  getToken() {
    return localStorage.getItem('py_admin_token');
  },

  getUser() {
    const raw = localStorage.getItem('py_admin_user');
    try {
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  },

  logout() {
    localStorage.removeItem('py_admin_token');
    localStorage.removeItem('py_admin_refresh');
    localStorage.removeItem('py_admin_user');
    window.location.href = '/panel/login/';
  },

  async request(endpoint, options = {}) {
    const token = this.getToken();
    if (!token && !endpoint.includes('/auth/login/')) {
      this.logout();
      return null;
    }

    const headers = {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      ...(options.headers || {})
    };

    try {
      const res = await fetch(endpoint, {
        ...options,
        headers
      });

      if (res.status === 401 || res.status === 403) {
        console.warn("Admin sessiyasi eskirgan yoki huquq yetarli emas.");
        this.logout();
        return null;
      }

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || data.detail || "Server xatoligi yuz berdi.");
      }

      return data;
    } catch (err) {
      console.error(`API Error on ${endpoint}:`, err);
      throw err;
    }
  },

  getMetrics() {
    return this.request('/api/admin/metrics/');
  },

  getUsers(params = {}) {
    const query = new URLSearchParams(params).toString();
    return this.request(`/api/admin/users/${query ? '?' + query : ''}`);
  },

  getUserDetail(userId) {
    return this.request(`/api/admin/users/${userId}/`);
  },

  updateUser(userId, data) {
    return this.request(`/api/admin/users/${userId}/`, {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  getBots(params = {}) {
    const query = new URLSearchParams(params).toString();
    return this.request(`/api/admin/bots/${query ? '?' + query : ''}`);
  },

  killBot(botId) {
    return this.request(`/api/admin/bots/${botId}/kill/`, {
      method: 'POST'
    });
  },

  getBotLogs(botId) {
    return this.request(`/api/admin/bots/${botId}/logs/`);
  },

  getSettings() {
    return this.request('/api/admin/settings/');
  },

  updateSettings(data) {
    return this.request('/api/admin/settings/', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  sendBroadcast(data) {
    return this.request('/api/admin/broadcast/', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  getAuditLogs() {
    return this.request('/api/admin/audit-logs/');
  }
};

window.PanelAPI = PanelAPI;
