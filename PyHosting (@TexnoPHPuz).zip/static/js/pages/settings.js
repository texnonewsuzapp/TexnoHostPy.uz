
if (!window.Icons) window.Icons = {};
if (typeof Icons.code !== 'function') {
  Icons.code = (size = 18, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="16 18 22 12 16 6"></polyline>
      <polyline points="8 6 2 12 8 18"></polyline>
    </svg>
  `;
}
if (typeof Icons.shieldCheck !== 'function') {
  Icons.shieldCheck = (size = 18, color = "currentColor") => `
    <svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
      <polyline points="9 12 11 14 15 10"></polyline>
    </svg>
  `;
}

const SettingsPage = {
  container: null,
  activeTab: 'account', 
  profileData: null,
  hostingData: null,
  isLoading: false,

  escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  },

  async render(targetEl, tab = 'account') {
    this.container = targetEl;
    this.activeTab = tab || 'account';
    this.renderSkeleton();

    try {
      await this.loadData();
      this.renderContent();
    } catch (err) {
      this.container.innerHTML = `
        <div class="view-page">
          <div class="glass-panel" style="padding: 40px; text-align: center; color: var(--status-crashed);">
            <h3>Sozlamalarni yuklashda xatolik</h3>
            <p style="color: var(--text-secondary); margin: 10px 0 20px;">${this.escapeHtml(err.message)}</p>
            <button class="btn btn-secondary btn-sm" onclick="SettingsPage.render(SettingsPage.container, SettingsPage.activeTab)">Qayta urinish</button>
          </div>
        </div>
      `;
    }
  },

  renderSkeleton() {
    this.container.innerHTML = `
      <div class="view-page">
        <div class="dashboard-header">
          <div>
            <h1 class="dashboard-title">Sozlamalar</h1>
            <p class="dashboard-subtitle">Akkaunt xavfsizligi va bot hosting parametrlarini boshqarish</p>
          </div>
        </div>
        <div class="glass-panel" style="padding: 30px; margin-top: 20px;">
          <div class="skeleton" style="height: 300px;"></div>
        </div>
      </div>
    `;
  },

  async loadData() {
    const [profile, hosting] = await Promise.all([
      API.get('/api/auth/profile/'),
      API.get('/api/auth/hosting-settings/')
    ]);
    this.profileData = profile;
    this.hostingData = hosting;
    API.setUser(profile);
  },

  setTab(tab) {
    this.activeTab = tab;
    const tabAccount = document.getElementById('settings-tab-account');
    const tabHosting = document.getElementById('settings-tab-hosting');
    const contentAccount = document.getElementById('settings-content-account');
    const contentHosting = document.getElementById('settings-content-hosting');

    if (tab === 'account') {
      if (tabAccount) tabAccount.classList.add('active');
      if (tabHosting) tabHosting.classList.remove('active');
      if (contentAccount) contentAccount.style.display = 'block';
      if (contentHosting) contentHosting.style.display = 'none';
    } else {
      if (tabAccount) tabAccount.classList.remove('active');
      if (tabHosting) tabHosting.classList.add('active');
      if (contentAccount) contentAccount.style.display = 'none';
      if (contentHosting) contentHosting.style.display = 'block';
    }
  },

  renderContent() {
    const p = this.profileData || {};
    const h = this.hostingData || {};
    const quota = h.quota || (p.quota || {});

    const dateJoined = p.date_joined ? new Date(p.date_joined).toLocaleDateString('uz-UZ', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }) : '—';

    this.container.innerHTML = `
      <div class="view-page settings-view">
        <!-- Header -->
        <div class="dashboard-header">
          <div>
            <div style="display: flex; align-items: center; gap: 10px;">
              <h1 class="dashboard-title">Sozlamalar</h1>
              <span class="badge badge-accent">Boshqaruv</span>
            </div>
            <p class="dashboard-subtitle">Akkaunt xavfsizligi, Python muhiti va bot hosting parametrlarini sozlash</p>
          </div>
        </div>

        <!-- Navigation Tabs Ribbon -->
        <div class="settings-nav-tabs glass-panel">
          <button 
            id="settings-tab-account" 
            class="settings-tab-btn ${this.activeTab === 'account' ? 'active' : ''}" 
            onclick="SettingsPage.setTab('account')"
          >
            <span class="settings-tab-icon">${Icons.user(17)}</span>
            <span>Akkaunt Sozlamalari</span>
          </button>
          <button 
            id="settings-tab-hosting" 
            class="settings-tab-btn ${this.activeTab === 'hosting' ? 'active' : ''}" 
            onclick="SettingsPage.setTab('hosting')"
          >
            <span class="settings-tab-icon">${Icons.sliders(17)}</span>
            <span>Hosting & Muhit Sozlamalari</span>
          </button>
        </div>

        <!-- TAB 1: AKKAUNT SOZLAMALARI -->
        <div id="settings-content-account" style="display: ${this.activeTab === 'account' ? 'block' : 'none'};">
          <div class="settings-grid">
            
            <!-- Profile Info Card -->
            <div class="glass-panel settings-card">
              <div class="settings-card-header">
                <div class="settings-card-icon-wrap" style="background: rgba(56, 139, 253, 0.15); color: var(--accent-blue);">
                  ${Icons.user(20, 'var(--accent-blue)')}
                </div>
                <div>
                  <h3 class="settings-card-title">Shaxsiy Ma'lumotlar</h3>
                  <p class="settings-card-desc">Foydalanuvchi hisobingiz parametrlari va aloqa pochtasi</p>
                </div>
              </div>

              <div class="settings-form">
                <div class="form-group">
                  <label class="form-label">Foydalanuvchi nomi (Username)</label>
                  <div class="settings-readonly-field">
                    <span>@${this.escapeHtml(p.username || 'user')}</span>
                    <span class="badge badge-accent" style="font-size: 11px;">O'zgartirib bo'lmaydi</span>
                  </div>
                </div>

                <div class="form-group">
                  <label class="form-label">Ro'yxatdan o'tgan sana</label>
                  <div class="settings-readonly-field">
                    <span>${this.escapeHtml(dateJoined)}</span>
                  </div>
                </div>

                <div class="form-group">
                  <label class="form-label" for="settings-email-input">Elektron pochta (Email)</label>
                  <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <input 
                      type="email" 
                      id="settings-email-input" 
                      class="form-control" 
                      style="flex: 1; min-width: 220px;" 
                      value="${this.escapeHtml(p.email || '')}" 
                      placeholder="nom@domain.uz"
                    />
                    <button class="btn btn-primary" onclick="SettingsPage.saveEmail()" style="display: inline-flex; align-items: center; gap: 6px;">
                      ${Icons.save(15)}
                      <span>Saqlash</span>
                    </button>
                  </div>
                  <span class="form-help-text">Muhim bildirishnomalar va parolni tiklash uchun ishlatiladi</span>
                </div>
              </div>
            </div>

            <!-- Password & Security Card -->
            <div class="glass-panel settings-card">
              <div class="settings-card-header">
                <div class="settings-card-icon-wrap" style="background: rgba(226, 175, 41, 0.15); color: var(--accent-yellow);">
                  ${Icons.lock(20, 'var(--accent-yellow)')}
                </div>
                <div>
                  <h3 class="settings-card-title">Parolni O'zgartirish</h3>
                  <p class="settings-card-desc">Hisobingiz xavfsizligini ta'minlash uchun kuchli paroldan foydalaning</p>
                </div>
              </div>

              <form class="settings-form" onsubmit="event.preventDefault(); SettingsPage.changePassword();">
                <div class="form-group">
                  <label class="form-label" for="pwd-old">Amaldagi eski parol</label>
                  <input type="password" id="pwd-old" class="form-control" placeholder="••••••••" required />
                </div>

                <div class="form-group">
                  <label class="form-label" for="pwd-new">Yangi parol (kamida 6 belgi)</label>
                  <input type="password" id="pwd-new" class="form-control" placeholder="••••••••" minlength="6" required />
                </div>

                <div class="form-group">
                  <label class="form-label" for="pwd-confirm">Yangi parolni tasdiqlash</label>
                  <input type="password" id="pwd-confirm" class="form-control" placeholder="••••••••" minlength="6" required />
                </div>

                <div style="margin-top: 10px;">
                  <button type="submit" id="btn-save-pwd" class="btn btn-primary" style="display: inline-flex; align-items: center; gap: 6px;">
                    ${Icons.lock(15)}
                    <span>Parolni Yangilash</span>
                  </button>
                </div>
              </form>
            </div>

          </div>
        </div>

        <!-- TAB 2: HOSTING & MUHIT SOZLAMALARI -->
        <div id="settings-content-hosting" style="display: ${this.activeTab === 'hosting' ? 'block' : 'none'};">
          <div class="settings-grid">
            
            <!-- Python & Environment Card -->
            <div class="glass-panel settings-card">
              <div class="settings-card-header">
                <div class="settings-card-icon-wrap" style="background: rgba(56, 139, 253, 0.15); color: var(--accent-blue);">
                  ${Icons.python ? Icons.python(22) : (Icons.code ? Icons.code(20) : '')}
                </div>
                <div>
                  <h3 class="settings-card-title">Python Interpretatori</h3>
                  <p class="settings-card-desc">Botlaringizni ishga tushirish uchun standart Python versiyasi</p>
                </div>
              </div>

              <div class="settings-form">
                <div class="form-group">
                  <label class="form-label" for="host-python-ver">Python Versiyasi</label>
                  <select id="host-python-ver" class="form-control" style="cursor: pointer;">
                    <option value="3.10" ${h.python_version === '3.10' ? 'selected' : ''}>Python 3.10 (Barqaror LTS)</option>
                    <option value="3.11" ${h.python_version === '3.11' ? 'selected' : ''}>Python 3.11 (Standart / Tavsiya etiladi)</option>
                    <option value="3.12" ${h.python_version === '3.12' ? 'selected' : ''}>Python 3.12 (Eng so'nggi barqaror)</option>
                    <option value="3.13" ${h.python_version === '3.13' ? 'selected' : ''}>Python 3.13 (Eksperimental)</option>
                  </select>
                  <span class="form-help-text">aiogram 3.x, pyTelegramBotAPI va telethon uchun Python 3.11 tavsiya etiladi.</span>
                </div>
              </div>
            </div>

            <!-- Auto-Restart & Watchdog Card -->
            <div class="glass-panel settings-card">
              <div class="settings-card-header">
                <div class="settings-card-icon-wrap" style="background: rgba(56, 139, 253, 0.15); color: var(--accent-blue);">
                  ${Icons.shieldCheck ? Icons.shieldCheck(20, 'var(--accent-blue)') : Icons.cpu(20, 'var(--accent-blue)')}
                </div>
                <div>
                  <h3 class="settings-card-title">Avtomatik Qayta Ishga Tushirish (Watchdog)</h3>
                  <p class="settings-card-desc">Bot to'satdan to'xtab qolganda avtomatik crash-recovery qilish qoidalari</p>
                </div>
              </div>

              <div class="settings-form">
                <div class="settings-toggle-row">
                  <div>
                    <strong style="color: var(--text-primary); font-size: 14.5px;">Standart Auto-Restart holati</strong>
                    <p style="color: var(--text-muted); font-size: 12.5px; margin-top: 2px;">
                      Yangi botlar uchun avtomatik qayta ishga tushirish funksiyasini sukut bo'yicha yoqish
                    </p>
                  </div>
                  <label class="liquid-switch">
                    <input type="checkbox" id="host-auto-restart" ${h.default_auto_restart ? 'checked' : ''} />
                    <span class="liquid-slider"></span>
                  </label>
                </div>

                <div class="form-group" style="margin-top: 18px;">
                  <label class="form-label" for="host-max-restart">Maksimal qayta urinishlar soni (Limit)</label>
                  <input 
                    type="number" 
                    id="host-max-restart" 
                    class="form-control" 
                    min="1" 
                    max="20" 
                    value="${h.max_restart_attempts || 5}" 
                    style="max-width: 140px;"
                  />
                  <span class="form-help-text">Cheksiz xatolikka tushmaslik uchun ketma-ket maksimal urinish chegarasi (1 - 20)</span>
                </div>
              </div>
            </div>

            <!-- Terminal & Logs Settings Card -->
            <div class="glass-panel settings-card">
              <div class="settings-card-header">
                <div class="settings-card-icon-wrap" style="background: rgba(163, 113, 247, 0.15); color: #A371F7;">
                  ${Icons.terminal ? Icons.terminal(20, '#A371F7') : Icons.fileCode(20, '#A371F7')}
                </div>
                <div>
                  <h3 class="settings-card-title">Terminal va Jonli Loglar</h3>
                  <p class="settings-card-desc">Bot konsol oynasining skroll va bufer parametrlari</p>
                </div>
              </div>

              <div class="settings-form">
                <div class="settings-toggle-row">
                  <div>
                    <strong style="color: var(--text-primary); font-size: 14.5px;">Jonli loglarni avtomatik pastga surish (Auto-scroll)</strong>
                    <p style="color: var(--text-muted); font-size: 12.5px; margin-top: 2px;">
                      Yangi log kelganda terminal avtomatik ravishda eng pastki qatorga siljiydi
                    </p>
                  </div>
                  <label class="liquid-switch">
                    <input type="checkbox" id="host-auto-scroll" ${h.auto_scroll_logs ? 'checked' : ''} />
                    <span class="liquid-slider"></span>
                  </label>
                </div>

                <div class="form-group" style="margin-top: 18px;">
                  <label class="form-label" for="host-log-buffer">Log bufer qatorlari soni</label>
                  <input 
                    type="number" 
                    id="host-log-buffer" 
                    class="form-control" 
                    min="100" 
                    max="2000" 
                    step="50" 
                    value="${h.log_buffer_limit || 500}" 
                    style="max-width: 140px;"
                  />
                  <span class="form-help-text">Terminal xotirasida saqlanadigan maksimal qatorlar soni (100 - 2000)</span>
                </div>
              </div>
            </div>

            <!-- Resource Limits HUD Card -->
            <div class="glass-panel settings-card">
              <div class="settings-card-header">
                <div class="settings-card-icon-wrap" style="background: rgba(56, 139, 253, 0.15); color: var(--accent-blue);">
                  ${Icons.hardDrive(20, 'var(--accent-blue)')}
                </div>
                <div>
                  <h3 class="settings-card-title">Hisob Kvotasi va Resurslar</h3>
                  <p class="settings-card-desc">Sizning tarifingizga ajratilgan hisoblash resurslari</p>
                </div>
              </div>

              <div class="settings-quota-grid">
                <div class="settings-quota-item">
                  <span class="quota-label">Disk Maydoni:</span>
                  <strong class="quota-val">${quota.max_disk_mb || 256} MB</strong>
                </div>
                <div class="settings-quota-item">
                  <span class="quota-label">Ishlatilgan Disk:</span>
                  <strong class="quota-val" style="color: var(--accent-cyan);">${quota.used_disk_mb || 0} MB</strong>
                </div>
                <div class="settings-quota-item">
                  <span class="quota-label">RAM Limiti / Bot:</span>
                  <strong class="quota-val">${quota.max_ram_mb || 128} MB</strong>
                </div>
                <div class="settings-quota-item">
                  <span class="quota-label">Maksimal Faol Bot:</span>
                  <strong class="quota-val" style="color: var(--accent-green);">${quota.max_running_bots || 2} ta</strong>
                </div>
              </div>
            </div>

          </div>

          <!-- Bottom Action Bar for Hosting Settings -->
          <div class="settings-save-bar glass-panel" style="margin-top: 24px; padding: 18px 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px;">
            <span style="font-size: 13.5px; color: var(--text-secondary);">
              O'zgartirishlar darhol barcha botlar konfiguratsiyasiga tatbiq etiladi.
            </span>
            <button class="btn btn-primary" onclick="SettingsPage.saveHostingSettings()" style="display: inline-flex; align-items: center; gap: 8px;">
              ${Icons.save(16)}
              <span>Hosting Sozlamalarini Saqlash</span>
            </button>
          </div>
        </div>

      </div>
    `;
  },

  async saveEmail() {
    const input = document.getElementById('settings-email-input');
    if (!input) return;
    const email = input.value.trim();

    if (!email) {
      Toast.show("Iltimos, elektron pochta manzilini kiriting", "error");
      return;
    }

    try {
      Toast.show("Elektron pochta tekshirilmoqda...", "info", 2000);
      const res = await API.patch('/api/auth/profile/', { email });

      const oldNotice = document.getElementById('settings-email-pending-notice');
      if (oldNotice) oldNotice.remove();

      if (res.email_change_pending) {
        Toast.show(res.message || "Yangi pochtangizga tasdiqlash havolasi yuborildi!", "info", 5000);
        
        const parentGroup = input.closest('.form-group');
        if (parentGroup) {
          const noticeEl = document.createElement('div');
          noticeEl.id = 'settings-email-pending-notice';
          noticeEl.style.cssText = 'margin-top: 10px; padding: 12px 14px; background: rgba(56, 139, 253, 0.1); border: 1px solid rgba(56, 139, 253, 0.3); border-radius: var(--radius-md); font-size: 13px; color: var(--accent-blue); line-height: 1.5; display: flex; align-items: flex-start; gap: 8px;';
          noticeEl.innerHTML = `
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0; margin-top: 1px;"><rect width="20" height="16" x="2" y="4" rx="2"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path></svg>
            <div>
              <strong>📩 Tasdiqlash kutilmoqda:</strong> <em>${this.escapeHtml(res.pending_email || email)}</em> manziliga tasdiqlash havolasi yuborildi. Yangi pochtangizdagi havolani bosganingizdan keyin hisobingiz to'liq yangilanadi.
            </div>
          `;
          parentGroup.appendChild(noticeEl);
        }
      } else {
        this.profileData = res;
        API.setUser(res);
        Toast.show("Elektron pochta muvaffaqiyatli saqlandi!", "success");
      }
    } catch (err) {
      let errMsg = err.message || "Email saqlashda xatolik";
      if (err.data && err.data.email) {
        errMsg = Array.isArray(err.data.email) ? err.data.email[0] : err.data.email;
      }
      Toast.show(errMsg, "error");
    }
  },

  async changePassword() {
    const oldPwdEl = document.getElementById('pwd-old');
    const newPwdEl = document.getElementById('pwd-new');
    const confirmPwdEl = document.getElementById('pwd-confirm');
    const btn = document.getElementById('btn-save-pwd');

    if (!oldPwdEl || !newPwdEl || !confirmPwdEl) return;

    const old_password = oldPwdEl.value;
    const new_password = newPwdEl.value;
    const new_password_confirm = confirmPwdEl.value;

    if (new_password.length < 6) {
      Toast.show("Yangi parol kamida 6 ta belgidan iborat bo'lishi kerak", "error");
      return;
    }

    if (new_password !== new_password_confirm) {
      Toast.show("Yangi parollar bir-biriga mos kelmadi", "error");
      return;
    }

    if (btn) btn.disabled = true;

    try {
      Toast.show("Parol tekshirilmoqda...", "info", 2000);
      const res = await API.post('/api/auth/change-password/', {
        old_password,
        new_password,
        new_password_confirm
      });

      Toast.show(res.message || "Parolingiz muvaffaqiyatli o'zgartirildi!", "success");
      oldPwdEl.value = '';
      newPwdEl.value = '';
      confirmPwdEl.value = '';
    } catch (err) {
      let errMsg = "Parolni o'zgartirishda xatolik";
      if (err.data) {
        if (err.data.old_password) errMsg = err.data.old_password[0] || errMsg;
        else if (err.data.new_password) errMsg = err.data.new_password[0] || errMsg;
        else if (err.data.new_password_confirm) errMsg = err.data.new_password_confirm[0] || errMsg;
      } else if (err.message) {
        errMsg = err.message;
      }
      Toast.show(errMsg, "error");
    } finally {
      if (btn) btn.disabled = false;
    }
  },

  async saveHostingSettings() {
    const pythonVerEl = document.getElementById('host-python-ver');
    const autoRestartEl = document.getElementById('host-auto-restart');
    const maxRestartEl = document.getElementById('host-max-restart');
    const autoScrollEl = document.getElementById('host-auto-scroll');
    const logBufferEl = document.getElementById('host-log-buffer');

    const payload = {
      python_version: pythonVerEl ? pythonVerEl.value : '3.11',
      default_auto_restart: autoRestartEl ? autoRestartEl.checked : true,
      max_restart_attempts: maxRestartEl ? parseInt(maxRestartEl.value, 10) || 5 : 5,
      auto_scroll_logs: autoScrollEl ? autoScrollEl.checked : true,
      log_buffer_limit: logBufferEl ? parseInt(logBufferEl.value, 10) || 500 : 500
    };

    try {
      Toast.show("Hosting sozlamalari saqlanmoqda...", "info", 2000);
      const res = await API.patch('/api/auth/hosting-settings/', payload);
      this.hostingData = res.settings || payload;
      Toast.show(res.message || "Hosting sozlamalari muvaffaqiyatli saqlandi!", "success");
    } catch (err) {
      Toast.show(err.message || "Sozlamalarni saqlashda xatolik", "error");
    }
  }
};

window.SettingsPage = SettingsPage;
