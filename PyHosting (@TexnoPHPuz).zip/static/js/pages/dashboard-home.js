
const DashboardHome = {
  container: null,

  async render(targetEl) {
    this.container = targetEl;

    this.container.innerHTML = `
      <div class="view-page">
        <div style="margin-bottom: 28px;">
          <h1 style="font-size: 26px; font-weight: 800; margin-bottom: 6px;">Boshqaruv Paneli</h1>
          <p style="color: var(--text-secondary); font-size: 14.5px;">Serveringiz va botlaringiz holati real vaqtda</p>
        </div>

        <div class="stats-grid">
          <div class="stat-card glass-panel"><div class="skeleton" style="height: 110px;"></div></div>
          <div class="stat-card glass-panel"><div class="skeleton" style="height: 110px;"></div></div>
          <div class="stat-card glass-panel"><div class="skeleton" style="height: 110px;"></div></div>
          <div class="stat-card glass-panel"><div class="skeleton" style="height: 110px;"></div></div>
        </div>

        <div class="section-card glass-panel" style="margin-top: 24px;">
          <div class="skeleton" style="height: 200px;"></div>
        </div>
      </div>
    `;

    try {
      const stats = await API.get('/api/dashboard/stats/');
      DiskIndicator.update(stats.used_disk_mb, stats.max_disk_mb);

      this.renderContent(stats);
    } catch (err) {
      this.container.innerHTML = `
        <div class="view-page">
          <div class="glass-panel" style="padding: 40px; text-align: center; color: var(--status-crashed);">
            <h3>Ma'lumotlarni yuklashda xatolik</h3>
            <p style="color: var(--text-secondary); margin: 10px 0 20px;">${err.message}</p>
            <button class="btn btn-secondary btn-sm" onclick="DashboardHome.render(DashboardHome.container)">Qayta urinish</button>
          </div>
        </div>
      `;
    }
  },

  renderContent(stats) {
    const diskPercent = stats.disk_percent;
    const runningBots = stats.running_bots;
    const maxBots = stats.max_running_bots;

    this.container.innerHTML = `
      <div class="view-page">
        <div class="dashboard-header">
          <div>
            <h1 class="dashboard-title">Boshqaruv Paneli</h1>
            <p class="dashboard-subtitle">Barcha botlaringiz xavfsiz va 24/7 rejimda nazorat ostida</p>
          </div>
          <div class="dashboard-actions">
            <button class="btn btn-secondary btn-sm" onclick="Router.navigate('/files')" style="display: inline-flex; align-items: center; gap: 6px;">
              ${Icons.folder(15)} <span>Fayllar</span>
            </button>
            <button class="btn btn-primary btn-sm" onclick="Router.navigate('/files')" style="display: inline-flex; align-items: center; gap: 6px;">
              ${Icons.upload(15)} <span>Bot kodini yuklash</span>
            </button>
          </div>
        </div>

        <!-- Stats Cards Grid -->
        <div class="stats-grid">
          <!-- Card 1: Disk Quota -->
          <div class="stat-card glass-panel">
            <div class="stat-header">
              <span class="stat-title">Disk Bandligi</span>
              <div class="stat-icon" style="background: rgba(56, 139, 253, 0.12);">${Icons.hardDrive(20, '#388BFD')}</div>
            </div>
            <div class="stat-value">${stats.used_disk_mb.toFixed(2)} <span style="font-size: 16px; color: var(--text-muted);">/ ${stats.max_disk_mb} MB</span></div>
            <div class="stat-sub">${(stats.max_disk_mb - stats.used_disk_mb).toFixed(2)} MB bo'sh (${(100 - diskPercent).toFixed(1)}%)</div>
            <div class="progress-bar-container">
              <div class="progress-bar-fill" style="width: ${diskPercent}%; background: ${diskPercent > 85 ? 'var(--status-crashed)' : diskPercent > 65 ? 'var(--status-starting)' : 'var(--accent-blue)'};"></div>
            </div>
          </div>

          <!-- Card 2: Running Bots -->
          <div class="stat-card glass-panel">
            <div class="stat-header">
              <span class="stat-title">Faol Botlar</span>
              <div class="stat-icon" style="background: rgba(63, 185, 80, 0.12);">${Icons.bot(20, '#3FB950')}</div>
            </div>
            <div class="stat-value">${runningBots} <span style="font-size: 16px; color: var(--text-muted);">/ ${maxBots} ta</span></div>
            <div class="stat-sub">
              ${runningBots > 0
                ? `<div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-top: 4px;">
                    <span class="status-pill status-running" style="padding: 2px 8px; font-size: 11px;"><span class="status-dot"></span> 24/7 Ishlamoqda</span>
                    <span style="font-size: 11px; color: var(--accent-green); display: inline-flex; align-items: center; gap: 4px;">${Icons.shieldCheck(12)} Watchdog faol</span>
                   </div>`
                : "Hozirda barcha botlar to'xtatilgan"}
            </div>
          </div>

          <!-- Card 3: Total Files -->
          <div class="stat-card glass-panel">
            <div class="stat-header">
              <span class="stat-title">Fayllar Soni</span>
              <div class="stat-icon" style="background: rgba(210, 153, 34, 0.12);">${Icons.fileCode(20, '#D29922')}</div>
            </div>
            <div class="stat-value">${stats.total_files} <span style="font-size: 16px; color: var(--text-muted);">ta fayl</span></div>
            <div class="stat-sub">Jami bot skriptlari: ${stats.total_bots} ta</div>
          </div>

          <!-- Card 4: Allocated Server Resources -->
          <div class="stat-card glass-panel">
            <div class="stat-header">
              <span class="stat-title">Ajratilgan Resurs</span>
              <div class="stat-icon" style="background: rgba(163, 113, 247, 0.12);">${Icons.cpu(20, '#A371F7')}</div>
            </div>
            <div class="stat-value">${stats.max_ram_mb} <span style="font-size: 16px; color: var(--text-muted);">MB RAM</span></div>
            <div class="stat-sub">${stats.max_cpu} vCPU CPU (Har bir botga 128 MB)</div>
          </div>
        </div>

        <!-- Recent Activities Table -->
        <div class="section-card glass-panel">
          <div class="section-header">
            <div>
              <h3 style="font-size: 17px; font-weight: 700;">So'nggi Faolliklar</h3>
              <p style="font-size: 13px; color: var(--text-secondary);">Oxirgi bot boshqaruv va ishga tushirish hodisalari</p>
            </div>
            <button class="btn btn-ghost btn-sm" onclick="Router.navigate('/files')" style="display: inline-flex; align-items: center; gap: 6px;">
              <span>Barcha fayllar</span> ${Icons.arrowRight(14)}
            </button>
          </div>

          ${stats.recent_activity.length === 0 ? `
            <div style="text-align: center; padding: 40px; color: var(--text-muted);">
              <div style="margin-bottom: 12px; display: flex; justify-content: center;">${Icons.bot(38, 'var(--accent-blue)')}</div>
              <p>Hozircha hech qanday bot ishga tushirilmadi.</p>
              <button class="btn btn-primary btn-sm" style="margin-top: 14px; display: inline-flex; align-items: center; gap: 6px;" onclick="Router.navigate('/files')">
                ${Icons.folder(14)} <span>Fayl menejeriga o'tish</span>
              </button>
            </div>
          ` : `
            <div class="table-responsive">
              <table class="activity-table">
                <thead>
                  <tr>
                    <th>Fayl Nomi</th>
                    <th>Holati</th>
                    <th>Oxirgi Hodisa</th>
                    <th>Vaqt</th>
                    <th style="text-align: right;">Amallar</th>
                  </tr>
                </thead>
                <tbody>
                  ${stats.recent_activity.map(item => `
                    <tr>
                      <td>
                        <div style="display: flex; align-items: center; gap: 8px; font-weight: 600; font-family: var(--font-mono); white-space: nowrap;">
                          <span style="display: inline-flex; align-items: center;">${Icons.python(16)}</span> ${item.file_name}
                        </div>
                      </td>
                      <td>
                        <span class="status-pill status-${item.status}" style="white-space: nowrap;">
                          <span class="status-dot"></span> ${item.status === 'running' ? 'Ishlayapti' : item.status === 'crashed' ? 'Xatolik' : 'To\'xtagan'}
                        </span>
                      </td>
                      <td style="color: var(--text-secondary); white-space: nowrap;">${item.action_text}</td>
                      <td style="color: var(--text-muted); font-size: 13px; white-space: nowrap;">${this.formatTimeAgo(item.updated_at)}</td>
                      <td style="text-align: right;">
                        <div style="display: flex; gap: 6px; justify-content: flex-end; white-space: nowrap;">
                          <button class="btn btn-secondary btn-sm" style="padding: 4px 8px; display: inline-flex; align-items: center; gap: 4px;" onclick="Modal.openEnvManager(${item.file_id})" title="Xavfsiz .env kalitlari">
                            ${Icons.key(13, 'var(--accent-yellow)')} <span>.env</span>
                          </button>
                          <button class="btn btn-secondary btn-sm" style="padding: 4px 10px; display: inline-flex; align-items: center; gap: 5px;" onclick="Router.navigate('/logs/${item.file_id}')">
                            ${Icons.terminal(13)} <span>Loglar</span>
                          </button>
                          <button class="btn btn-secondary btn-sm" style="padding: 4px 10px; display: inline-flex; align-items: center; gap: 5px;" onclick="Router.navigate('/editor/${item.file_id}')">
                            ${Icons.edit(13)} <span>Kod</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          `}
        </div>
      </div>
    `;
  },

  formatTimeAgo(isoString) {
    const diffSec = Math.floor((new Date() - new Date(isoString)) / 1000);
    if (diffSec < 60) return "Hozirgina";
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) return `${diffMin} daqiqa oldin`;
    const diffHours = Math.floor(diffMin / 60);
    if (diffHours < 24) return `${diffHours} soat oldin`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} kun oldin`;
  }
};

window.DashboardHome = DashboardHome;
