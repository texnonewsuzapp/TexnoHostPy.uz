
document.addEventListener('DOMContentLoaded', () => {
  
  const nav = document.querySelector('.landing-nav');
  if (nav) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 40) {
        nav.classList.add('scrolled');
      } else {
        nav.classList.remove('scrolled');
      }
    });
  }

  const targetCodeEl = document.getElementById('mockup-typing-line');
  if (targetCodeEl) {
    const codeSnippet = 'bot = telebot.TeleBot(TOKEN)';
    let charIdx = 0;
    targetCodeEl.textContent = '';

    const typeChar = () => {
      if (charIdx < codeSnippet.length) {
        targetCodeEl.textContent += codeSnippet[charIdx];
        charIdx++;
        setTimeout(typeChar, 75);
      }
    };
    setTimeout(typeChar, 600);
  }

  const observerOptions = {
    threshold: 0.15,
    rootMargin: '0px 0px -40px 0px'
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  document.querySelectorAll('.bento-card, .step-card, .spec-card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(24px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
  });
});
