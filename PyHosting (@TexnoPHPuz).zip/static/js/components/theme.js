
const Theme = {
  STORAGE_KEY: 'pyh_theme',

  init() {
    const saved = localStorage.getItem(this.STORAGE_KEY);
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    const currentTheme = saved || (prefersDark ? 'dark' : 'dark');
    this.apply(currentTheme, false);

    if (window.matchMedia) {
      window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
        if (!localStorage.getItem(this.STORAGE_KEY)) {
          this.apply(e.matches ? 'dark' : 'light', false);
        }
      });
    }
  },

  get() {
    return document.documentElement.getAttribute('data-theme') || 'dark';
  },

  toggle() {
    const next = this.get() === 'dark' ? 'light' : 'dark';
    this.apply(next, true);
    if (window.Toast) {
      Toast.info(next === 'dark' ? "Tungi rejim yoqildi" : "Kunduzgi rejim yoqildi");
    }
  },

  apply(theme, save = true) {
    document.documentElement.setAttribute('data-theme', theme);
    if (save) {
      localStorage.setItem(this.STORAGE_KEY, theme);
    }
    this.updateIcons(theme);
    if (window.monaco && window.monaco.editor) {
      window.monaco.editor.setTheme(theme === 'light' ? 'vs' : 'vs-dark');
    }
    window.dispatchEvent(new CustomEvent('pyh-theme-changed', { detail: { theme } }));
  },

  updateIcons(theme) {
    const btns = document.querySelectorAll('.theme-toggle-btn');
    const isDark = theme === 'dark';
    btns.forEach(btn => {
      btn.innerHTML = isDark
        ? `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>`
        : `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>`;
      btn.setAttribute('title', isDark ? "Kunduzgi rejimga o'tish" : "Tungi rejimga o'tish");
    });
  }
};

(function() {
  const saved = localStorage.getItem('pyh_theme');
  if (saved) {
    document.documentElement.setAttribute('data-theme', saved);
  } else {
    document.documentElement.setAttribute('data-theme', 'dark');
  }
})();

document.addEventListener('DOMContentLoaded', () => {
  Theme.init();
});

window.Theme = Theme;
