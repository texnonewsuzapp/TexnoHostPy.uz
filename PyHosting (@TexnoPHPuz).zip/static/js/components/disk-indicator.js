
const DiskIndicator = {
  update(usedMb, maxMb = 50.0) {
    const percent = Math.min(Math.max((usedMb / maxMb) * 100, 0), 100);
    const circle = document.querySelector('.gauge-progress');
    const label = document.querySelector('.gauge-value');

    if (label) {
      label.textContent = `${usedMb.toFixed(1)} / ${maxMb.toFixed(0)} MB`;
    }

    if (circle) {
      const circumference = 88;
      const offset = circumference - (circumference * (percent / 100));
      circle.style.strokeDashoffset = offset;

      if (percent < 65) {
        circle.style.stroke = '#3FB950'; 
      } else if (percent < 85) {
        circle.style.stroke = '#D29922'; 
      } else {
        circle.style.stroke = '#F85149'; 
      }
    }
  }
};

window.DiskIndicator = DiskIndicator;
