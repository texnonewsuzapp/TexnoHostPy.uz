
const Auth = {
  pendingEmail: '',
  resendCooldownTimer: null,

  init() {
    const isAuthPage = window.location.pathname.startsWith('/auth');

    if (isAuthPage) {
      const urlParams = new URLSearchParams(window.location.search);
      const configUid = window.PYH_CONFIG && window.PYH_CONFIG.activate && window.PYH_CONFIG.activate.uid;
      const configToken = window.PYH_CONFIG && window.PYH_CONFIG.activate && window.PYH_CONFIG.activate.token;
      const urlUid = urlParams.get('uid');
      const urlToken = urlParams.get('token');

      const actUid = configUid || urlUid;
      const actToken = configToken || urlToken;

      if (actUid && actToken) {
        this.processActivation(actUid, actToken);
        return;
      }

      const configConfirmToken = window.PYH_CONFIG && window.PYH_CONFIG.confirmEmail && window.PYH_CONFIG.confirmEmail.token;
      const urlConfirmToken = window.location.pathname.includes('confirm-email') ? urlParams.get('token') : null;
      const confirmToken = configConfirmToken || urlConfirmToken;

      if (confirmToken) {
        this.processEmailChangeConfirmation(confirmToken);
        return;
      }

      if (API.getToken()) {
        window.location.href = '/app/';
        return;
      }
      this.bindAuthEvents();
      GoogleAuth.init();
      TurnstileAuth.init();

      const googleCode = urlParams.get('code');
      const googleError = urlParams.get('error');

      if (googleError) {
        window.history.replaceState({}, document.title, window.location.pathname);
        if (googleError !== 'access_denied') {
          Toast.error("Google orqali kirish bekor qilindi yoki xatolik: " + googleError);
        }
      } else if (googleCode) {
        window.history.replaceState({}, document.title, window.location.pathname);
        GoogleAuth.handleOAuthCode(googleCode);
      }
    }
  },

  bindAuthEvents() {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const tabLogin = document.getElementById('tab-login');
    const tabRegister = document.getElementById('tab-register');
    const loginBox = document.getElementById('login-box');
    const registerBox = document.getElementById('register-box');

    if (tabLogin && tabRegister) {
      tabLogin.onclick = () => {
        tabLogin.classList.add('active');
        tabRegister.classList.remove('active');
        loginBox.style.display = 'block';
        registerBox.style.display = 'none';
        const googleLabel = document.getElementById('google-btn-label');
        if (googleLabel) googleLabel.textContent = "Google orqali kirish";
        TurnstileAuth.renderLogin();
      };

      tabRegister.onclick = () => {
        tabRegister.classList.add('active');
        tabLogin.classList.remove('active');
        loginBox.style.display = 'none';
        registerBox.style.display = 'block';
        const googleLabel = document.getElementById('google-btn-label');
        if (googleLabel) googleLabel.textContent = "Google orqali ro'yxatdan o'tish";
        TurnstileAuth.renderRegister();
      };
    }

    if (loginForm) {
      loginForm.onsubmit = async (e) => {
        e.preventDefault();
        const submitBtn = loginForm.querySelector('button[type="submit"]');
        const origText = submitBtn.textContent;
        submitBtn.disabled = true;
        submitBtn.textContent = 'Kirilmoqda...';

        const username = document.getElementById('login-username').value.trim();
        const password = document.getElementById('login-password').value;

        const payload = { username, password };
        if (TurnstileAuth.enabled) {
          const tToken = TurnstileAuth.getLoginToken();
          if (!tToken) {
            Toast.error("Iltimos, robot emasligingizni tasdiqlang (CAPTCHA).");
            submitBtn.disabled = false;
            submitBtn.textContent = origText;
            return;
          }
          payload.turnstile_token = tToken;
        }

        try {
          const res = await API.post('/api/auth/login/', payload);
          API.setTokens(res.access, res.refresh);
          API.setUser(res.user);
          Toast.success("Xush kelibsiz! Dashboard ochilmoqda...");
          setTimeout(() => window.location.href = '/app/', 500);
        } catch (err) {
          TurnstileAuth.resetLogin();
          if (err.data && err.data.not_activated) {
            Toast.warning(err.message || "Akkaunt hali faollashtirilmagan. Pochtangizni tekshiring.");
            Auth.showActivationPending(err.data.email || username);
            return;
          }
          Toast.error(err.message || "Kirishda xatolik");
          loginBox.classList.add('shake');
          setTimeout(() => loginBox.classList.remove('shake'), 500);
        } finally {
          submitBtn.disabled = false;
          submitBtn.textContent = origText;
        }
      };
    }

    if (registerForm) {
      
      const regUsername = document.getElementById('reg-username');
      const regUsernameFeedback = document.getElementById('username-feedback');
      let usernameTimeout = null;

      if (regUsername) {
        regUsername.oninput = () => {
          clearTimeout(usernameTimeout);
          const val = regUsername.value.trim();
          if (val.length < 3) {
            regUsernameFeedback.textContent = '';
            return;
          }
          usernameTimeout = setTimeout(async () => {
            try {
              const res = await API.get(`/api/auth/check/?username=${encodeURIComponent(val)}`);
              if (res.username_available) {
                regUsernameFeedback.innerHTML = `<span style="display: inline-flex; align-items: center; gap: 4px; color: #3FB950;"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg> Bu nom bo'sh</span>`;
              } else {
                regUsernameFeedback.innerHTML = `<span style="display: inline-flex; align-items: center; gap: 4px; color: #F85149;"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg> Bu nom band</span>`;
              }
            } catch {}
          }, 350);
        };
      }

      const regPass = document.getElementById('reg-password');
      const passStrength = document.getElementById('password-strength');
      if (regPass && passStrength) {
        regPass.oninput = () => {
          const v = regPass.value;
          let score = 0;
          if (v.length >= 6) score++;
          if (v.length >= 10) score++;
          if (/[A-Z]/.test(v)) score++;
          if (/[0-9]/.test(v)) score++;
          if (/[^A-Za-z0-9]/.test(v)) score++;

          if (score <= 1) {
            passStrength.style.width = '25%';
            passStrength.style.background = '#F85149';
          } else if (score <= 3) {
            passStrength.style.width = '60%';
            passStrength.style.background = '#D29922';
          } else {
            passStrength.style.width = '100%';
            passStrength.style.background = '#3FB950';
          }
        };
      }

      registerForm.onsubmit = async (e) => {
        e.preventDefault();
        const username = document.getElementById('reg-username').value.trim();
        const email = document.getElementById('reg-email').value.trim();
        const password = document.getElementById('reg-password').value;
        const password_confirm = document.getElementById('reg-password-confirm').value;

        if (password !== password_confirm) {
          Toast.error("Parollar mos kelmadi!");
          return;
        }

        const submitBtn = registerForm.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Yaratilmoqda...';

        const payload = {
          username,
          email,
          password,
          password_confirm
        };

        if (TurnstileAuth.enabled) {
          const tToken = TurnstileAuth.getRegisterToken();
          if (!tToken) {
            Toast.error("Iltimos, robot emasligingizni tasdiqlang (CAPTCHA).");
            submitBtn.disabled = false;
            submitBtn.textContent = "Ro'yxatdan o'tish (50MB Bepul)";
            return;
          }
          payload.turnstile_token = tToken;
        }

        try {
          const res = await API.post('/api/auth/register/', payload);
          if (res.require_activation) {
            Toast.info(res.message || "Faollashtirish havolasi pochtangizga yuborildi!");
            Auth.showActivationPending(res.email || email);
            return;
          }
          if (res.tokens) {
            API.setTokens(res.tokens.access, res.tokens.refresh);
            API.setUser(res.user);
            Toast.success("Ro'yxatdan muvaffaqiyatli o'tdingiz!");
            setTimeout(() => window.location.href = '/app/', 500);
          }
        } catch (err) {
          TurnstileAuth.resetRegister();
          Toast.error(err.message || "Ro'yxatdan o'tishda xatolik");
          registerBox.classList.add('shake');
          setTimeout(() => registerBox.classList.remove('shake'), 500);
        } finally {
          submitBtn.disabled = false;
          submitBtn.textContent = "Ro'yxatdan o'tish (50MB Bepul)";
        }
      };
    }

    const resendBtn = document.getElementById('resend-activation-btn');
    if (resendBtn) {
      resendBtn.onclick = () => this.resendActivation();
    }

    const backBtn = document.getElementById('back-to-login-btn');
    if (backBtn) {
      backBtn.onclick = () => this.showLogin();
    }
  },

  showActivationPending(email) {
    this.pendingEmail = email || '';
    const emailDisplay = document.getElementById('pending-email-display');
    if (emailDisplay) emailDisplay.textContent = email;

    const tabs = document.querySelector('.auth-tabs');
    const loginBox = document.getElementById('login-box');
    const registerBox = document.getElementById('register-box');
    const pendingBox = document.getElementById('activation-pending-box');
    const statusBox = document.getElementById('activation-status-box');
    const divider = document.getElementById('auth-social-divider');
    const googleWrapper = document.getElementById('google-auth-wrapper');

    if (tabs) tabs.style.display = 'none';
    if (loginBox) loginBox.style.display = 'none';
    if (registerBox) registerBox.style.display = 'none';
    if (statusBox) statusBox.style.display = 'none';
    if (divider) divider.style.display = 'none';
    if (googleWrapper) googleWrapper.style.display = 'none';
    if (pendingBox) pendingBox.style.display = 'block';
  },

  showLogin() {
    const tabs = document.querySelector('.auth-tabs');
    const tabLogin = document.getElementById('tab-login');
    const tabRegister = document.getElementById('tab-register');
    const loginBox = document.getElementById('login-box');
    const registerBox = document.getElementById('register-box');
    const pendingBox = document.getElementById('activation-pending-box');
    const statusBox = document.getElementById('activation-status-box');
    const divider = document.getElementById('auth-social-divider');
    const googleWrapper = document.getElementById('google-auth-wrapper');

    if (pendingBox) pendingBox.style.display = 'none';
    if (statusBox) statusBox.style.display = 'none';
    if (registerBox) registerBox.style.display = 'none';
    if (tabs) tabs.style.display = 'grid';
    if (loginBox) loginBox.style.display = 'block';
    if (divider) divider.style.display = 'flex';
    if (googleWrapper) googleWrapper.style.display = 'block';

    if (tabLogin && tabRegister) {
      tabLogin.classList.add('active');
      tabRegister.classList.remove('active');
    }
    const googleLabel = document.getElementById('google-btn-label');
    if (googleLabel) googleLabel.textContent = "Google orqali kirish";
    TurnstileAuth.renderLogin();
  },

  async resendActivation() {
    const btn = document.getElementById('resend-activation-btn');
    if (!this.pendingEmail) {
      Toast.error("Pochta manzili aniqlanmadi.");
      return;
    }
    if (btn && btn.disabled) return;

    if (btn) {
      btn.disabled = true;
      btn.innerHTML = `<span>Yuborilmoqda...</span>`;
    }

    try {
      const res = await API.post('/api/auth/resend-activation/', { email: this.pendingEmail });
      Toast.success(res.message || "Faollashtirish havolasi pochtangizga qayta yuborildi!");
      this.startResendCooldown(60);
    } catch (err) {
      Toast.error(err.message || "Qayta yuborishda xatolik yuz berdi");
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `<span>Qayta havola yuborish</span>`;
      }
    }
  },

  startResendCooldown(seconds) {
    const btn = document.getElementById('resend-activation-btn');
    if (!btn) return;
    if (this.resendCooldownTimer) clearInterval(this.resendCooldownTimer);

    let remain = seconds;
    btn.disabled = true;
    btn.innerHTML = `<span>Qayta yuborish (${remain}s)</span>`;

    this.resendCooldownTimer = setInterval(() => {
      remain--;
      if (remain <= 0) {
        clearInterval(this.resendCooldownTimer);
        btn.disabled = false;
        btn.innerHTML = `<span>Qayta havola yuborish</span>`;
      } else {
        btn.innerHTML = `<span>Qayta yuborish (${remain}s)</span>`;
      }
    }, 1000);
  },

  async processActivation(uid, token) {
    const tabs = document.querySelector('.auth-tabs');
    const loginBox = document.getElementById('login-box');
    const registerBox = document.getElementById('register-box');
    const pendingBox = document.getElementById('activation-pending-box');
    const statusBox = document.getElementById('activation-status-box');
    const divider = document.getElementById('auth-social-divider');
    const googleWrapper = document.getElementById('google-auth-wrapper');

    if (tabs) tabs.style.display = 'none';
    if (loginBox) loginBox.style.display = 'none';
    if (registerBox) registerBox.style.display = 'none';
    if (pendingBox) pendingBox.style.display = 'none';
    if (divider) divider.style.display = 'none';
    if (googleWrapper) googleWrapper.style.display = 'none';
    if (statusBox) statusBox.style.display = 'block';

    const iconEl = document.getElementById('activation-status-icon');
    const titleEl = document.getElementById('activation-status-title');
    const descEl = document.getElementById('activation-status-desc');
    const actBtn = document.getElementById('activation-action-btn');

    if (iconEl) {
      iconEl.style.background = 'rgba(56, 139, 253, 0.12)';
      iconEl.style.border = '1px solid rgba(56, 139, 253, 0.3)';
      iconEl.innerHTML = `<div class="spinner" style="width: 28px; height: 28px; border: 3px solid rgba(56, 139, 253, 0.2); border-top-color: #388BFD; border-radius: 50%; animation: pyhSpin 0.8s linear infinite;"></div>`;
    }
    if (titleEl) titleEl.textContent = "Akkaunt faollashtirilmoqda...";
    if (descEl) descEl.textContent = "Havola tekshirilmoqda, iltimos kuting...";
    if (actBtn) actBtn.style.display = 'none';

    try {
      const res = await API.post('/api/auth/activate/', { uid, token });

      if (iconEl) {
        iconEl.style.background = 'rgba(63, 185, 80, 0.12)';
        iconEl.style.border = '1px solid rgba(63, 185, 80, 0.4)';
        iconEl.innerHTML = `<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#3FB950" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`;
      }
      if (titleEl) titleEl.textContent = "Akkauntingiz faollashtirildi!";
      if (descEl) descEl.textContent = res.message || "Tabriklaymiz! Akkauntingiz muvaffaqiyatli faollashtirildi. Dashboardga yo'naltirilmoqdasiz...";

      if (res.tokens) {
        API.setTokens(res.tokens.access, res.tokens.refresh);
        API.setUser(res.user);
        if (actBtn) {
          actBtn.style.display = 'inline-flex';
          actBtn.innerHTML = `<span>Boshqaruv paneliga o'tish</span> &rarr;`;
          actBtn.onclick = () => window.location.href = '/app/';
        }
        Toast.success("Akkaunt muvaffaqiyatli faollashtirildi!");
        setTimeout(() => {
          window.location.href = '/app/';
        }, 1800);
      } else {
        if (actBtn) {
          actBtn.style.display = 'inline-flex';
          actBtn.innerHTML = `<span>Kirish oynasiga o'tish</span>`;
          actBtn.onclick = () => this.showLogin();
        }
      }
    } catch (err) {
      if (iconEl) {
        iconEl.style.background = 'rgba(248, 81, 73, 0.12)';
        iconEl.style.border = '1px solid rgba(248, 81, 73, 0.4)';
        iconEl.innerHTML = `<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#F85149" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>`;
      }
      if (titleEl) titleEl.textContent = "Faollashtirishda xatolik";
      if (descEl) descEl.textContent = err.message || "Havola eskirgan yoki yaroqsiz bo'lishi mumkin.";

      if (actBtn) {
        actBtn.style.display = 'inline-flex';
        actBtn.innerHTML = `<span>Kirish oynasiga qaytish</span>`;
        actBtn.onclick = () => this.showLogin();
      }
      Toast.error(err.message || "Faollashtirishda xatolik yuz berdi");
    }
  },

  async processEmailChangeConfirmation(token) {
    const tabs = document.querySelector('.auth-tabs');
    const loginBox = document.getElementById('login-box');
    const registerBox = document.getElementById('register-box');
    const pendingBox = document.getElementById('activation-pending-box');
    const statusBox = document.getElementById('activation-status-box');
    const divider = document.getElementById('auth-social-divider');
    const googleWrapper = document.getElementById('google-auth-wrapper');

    if (tabs) tabs.style.display = 'none';
    if (loginBox) loginBox.style.display = 'none';
    if (registerBox) registerBox.style.display = 'none';
    if (pendingBox) pendingBox.style.display = 'none';
    if (divider) divider.style.display = 'none';
    if (googleWrapper) googleWrapper.style.display = 'none';
    if (statusBox) statusBox.style.display = 'block';

    const iconEl = document.getElementById('activation-status-icon');
    const titleEl = document.getElementById('activation-status-title');
    const descEl = document.getElementById('activation-status-desc');
    const actBtn = document.getElementById('activation-action-btn');

    if (iconEl) {
      iconEl.style.background = 'rgba(56, 139, 253, 0.12)';
      iconEl.style.border = '1px solid rgba(56, 139, 253, 0.3)';
      iconEl.innerHTML = `<div class="spinner" style="width: 28px; height: 28px; border: 3px solid rgba(56, 139, 253, 0.2); border-top-color: #388BFD; border-radius: 50%; animation: pyhSpin 0.8s linear infinite;"></div>`;
    }
    if (titleEl) titleEl.textContent = "Pochta tekshirilmoqda...";
    if (descEl) descEl.textContent = "Yangi pochta tasdiqlanmoqda, iltimos kuting...";
    if (actBtn) actBtn.style.display = 'none';

    try {
      const res = await API.post('/api/auth/confirm-email-change/', { token });

      if (iconEl) {
        iconEl.style.background = 'rgba(63, 185, 80, 0.12)';
        iconEl.style.border = '1px solid rgba(63, 185, 80, 0.4)';
        iconEl.innerHTML = `<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#3FB950" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`;
      }
      if (titleEl) titleEl.textContent = "Elektron pochta yangilandi!";
      if (descEl) descEl.textContent = res.message || `Pochtangingiz muvaffaqiyatli ${res.email || ''} ga o'zgartirildi!`;

      if (res.user) {
        API.setUser(res.user);
      }

      if (actBtn) {
        actBtn.style.display = 'inline-flex';
        actBtn.innerHTML = `<span>Boshqaruv paneliga o'tish</span> &rarr;`;
        actBtn.onclick = () => window.location.href = '/app/';
      }
      Toast.success(res.message || "Pochta muvaffaqiyatli yangilandi!");
      if (API.getToken()) {
        setTimeout(() => {
          window.location.href = '/app/';
        }, 1800);
      }
    } catch (err) {
      if (iconEl) {
        iconEl.style.background = 'rgba(248, 81, 73, 0.12)';
        iconEl.style.border = '1px solid rgba(248, 81, 73, 0.4)';
        iconEl.innerHTML = `<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#F85149" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>`;
      }
      if (titleEl) titleEl.textContent = "Tasdiqlashda xatolik";
      if (descEl) descEl.textContent = err.message || "Havola eskirgan yoki yaroqsiz.";

      if (actBtn) {
        actBtn.style.display = 'inline-flex';
        actBtn.innerHTML = `<span>Kirish oynasiga o'tish</span>`;
        actBtn.onclick = () => this.showLogin();
      }
      Toast.error(err.message || "Pochtani tasdiqlashda xatolik");
    }
  },

  logout() {
    API.clearTokens();
    window.location.href = '/auth/';
  }
};

const GoogleAuth = {
  clientId: null,
  isInitialized: false,
  tokenClient: null,

  async init() {
    if (window.PYH_CONFIG && window.PYH_CONFIG.google && window.PYH_CONFIG.google.clientId) {
      this.clientId = window.PYH_CONFIG.google.clientId;
      this.setupGoogleServices(this.clientId);
      return;
    }
    try {
      const config = await API.get('/api/auth/google/config/');
      if (config && config.client_id) {
        this.clientId = config.client_id;
        this.setupGoogleServices(config.client_id);
      }
    } catch (e) {
      console.warn("Google OAuth config yuklanmadi:", e);
    }
  },

  setupGoogleServices(clientId, attempt = 0) {
    if (typeof google === 'undefined' || !google.accounts) {
      if (attempt < 25) {
        setTimeout(() => this.setupGoogleServices(clientId, attempt + 1), 200);
      } else {
        console.warn("Google Identity Services kutubxonasi yuklanmadi.");
      }
      return;
    }

    try {
      
      if (google.accounts.oauth2) {
        this.tokenClient = google.accounts.oauth2.initTokenClient({
          client_id: clientId,
          scope: 'email profile openid',
          callback: async (tokenResponse) => {
            if (tokenResponse && tokenResponse.error) {
              if (tokenResponse.error !== 'access_denied') {
                Toast.error("Google tizimiga ulanishda xatolik: " + (tokenResponse.error_description || tokenResponse.error));
              }
              return;
            }
            if (tokenResponse && tokenResponse.access_token) {
              await this.handleAccessToken(tokenResponse.access_token);
            }
          }
        });
      }

      if (google.accounts.id) {
        google.accounts.id.initialize({
          client_id: clientId,
          callback: this.handleCredentialResponse.bind(this),
          auto_select: false
        });

        const mount = document.getElementById('g_id_signin_placeholder');
        if (mount) {
          google.accounts.id.renderButton(mount, {
            theme: 'outline',
            size: 'large',
            type: 'standard',
            text: 'continue_with',
            shape: 'rectangular',
            logo_alignment: 'left',
            width: 376
          });
        }
      }

      this.isInitialized = true;
    } catch (err) {
      console.error("Google xizmatlarini sozlashda xatolik:", err);
    }
  },

  async handleAccessToken(accessToken) {
    Toast.info("Google orqali tizimga kirilmoqda...");
    const btn = document.getElementById('google-signin-btn');
    if (btn) btn.disabled = true;

    try {
      const res = await API.post('/api/auth/google/', {
        access_token: accessToken
      });

      API.setTokens(res.tokens.access, res.tokens.refresh);
      API.setUser(res.user);
      Toast.success(res.message || "Xush kelibsiz!");
      setTimeout(() => {
        window.location.href = '/app/';
      }, 500);
    } catch (err) {
      Toast.error(err.message || "Google orqali autentifikatsiyada xatolik.");
      if (btn) btn.disabled = false;
    }
  },

  async handleCredentialResponse(response) {
    if (!response || !response.credential) {
      Toast.error("Google orqali ma'lumot qabul qilinmadi.");
      return;
    }

    Toast.info("Google orqali tizimga ulanmoqda...");
    const btn = document.getElementById('google-signin-btn');
    if (btn) btn.disabled = true;

    try {
      const res = await API.post('/api/auth/google/', {
        credential: response.credential
      });

      API.setTokens(res.tokens.access, res.tokens.refresh);
      API.setUser(res.user);
      Toast.success(res.message || "Xush kelibsiz!");
      setTimeout(() => {
        window.location.href = '/app/';
      }, 500);
    } catch (err) {
      Toast.error(err.message || "Google orqali autentifikatsiyada xatolik.");
      if (btn) btn.disabled = false;
    }
  },

  async handleOAuthCode(code) {
    Toast.info("Google orqali tizimga ulanmoqda...");
    const btn = document.getElementById('google-signin-btn');
    if (btn) btn.disabled = true;

    try {
      const redirectUri = window.location.origin + '/auth/';
      const res = await API.post('/api/auth/google/', {
        code: code,
        redirect_uri: redirectUri
      });

      API.setTokens(res.tokens.access, res.tokens.refresh);
      API.setUser(res.user);
      Toast.success(res.message || "Xush kelibsiz!");
      setTimeout(() => {
        window.location.href = '/app/';
      }, 500);
    } catch (err) {
      Toast.error(err.message || "Google orqali autentifikatsiyada xatolik yuz berdi.");
      if (btn) btn.disabled = false;
    }
  },

  signIn() {
    if (!this.clientId) {
      Toast.info("Google orqali kirish uchun Admin Panelda (/panel/settings) Google Client ID o'rnatilishi zarur.");
      return;
    }

    if (typeof google !== 'undefined' && google.accounts && this.tokenClient) {
      try {
        this.tokenClient.requestAccessToken({ prompt: 'select_account' });
        return;
      } catch (err) {
        console.warn("tokenClient request xatosi, redirect qilinmoqda:", err);
      }
    }

    const redirectUri = window.location.origin + '/auth/';
    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${encodeURIComponent(this.clientId)}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=openid%20email%20profile&access_type=offline&prompt=select_account`;

    Toast.info("Google orqali avtorizatsiya oynasiga yo'naltirilmoqda...");
    window.location.href = authUrl;
  }
};

const TurnstileAuth = {
  enabled: (window.PYH_CONFIG && window.PYH_CONFIG.turnstile && window.PYH_CONFIG.turnstile.enabled) || false,
  siteKey: (window.PYH_CONFIG && window.PYH_CONFIG.turnstile && window.PYH_CONFIG.turnstile.siteKey) || null,
  loginWidgetId: null,
  registerWidgetId: null,
  loginToken: null,
  registerToken: null,

  async init() {
    window.addEventListener('pyh-theme-changed', (e) => {
      this.updateTheme(e.detail ? e.detail.theme : 'dark');
    });

    if (!this.siteKey) {
      try {
        const config = await API.get('/api/auth/turnstile/config/');
        if (config && config.enabled && config.site_key) {
          this.enabled = true;
          this.siteKey = config.site_key;
        }
      } catch (e) {
        console.warn("Turnstile config yuklanmadi:", e);
      }
    }

    if (this.enabled && this.siteKey) {
      this.renderWidgets();
    }
  },

  getTheme() {
    if (window.Theme && typeof window.Theme.get === 'function') {
      return window.Theme.get() === 'light' ? 'light' : 'dark';
    }
    const docTheme = document.documentElement.getAttribute('data-theme');
    return docTheme === 'light' ? 'light' : 'dark';
  },

  renderWidgets() {
    if (!this.enabled || !this.siteKey) return;
    this.renderLogin();
  },

  renderLogin(attempt = 0) {
    if (!this.enabled || !this.siteKey || this.loginWidgetId) return;

    const container = document.getElementById('turnstile-login-container');
    if (!container) return;
    container.style.display = 'flex';

    if (typeof turnstile === 'undefined') {
      if (attempt < 40) {
        setTimeout(() => this.renderLogin(attempt + 1), 150);
      }
      return;
    }

    const doRender = () => {
      if (this.loginWidgetId) return;
      try {
        const currentTheme = this.getTheme();
        this.loginWidgetId = turnstile.render('#turnstile-login-container', {
          sitekey: this.siteKey,
          theme: currentTheme,
          callback: (token) => {
            this.loginToken = token;
          },
          'expired-callback': () => {
            this.loginToken = null;
          },
          'error-callback': () => {
            this.loginToken = null;
          }
        });
      } catch (e) {
        console.warn("Turnstile login render xatosi:", e);
      }
    };

    if (typeof turnstile.render === 'function') {
      doRender();
    } else if (typeof turnstile.ready === 'function') {
      turnstile.ready(doRender);
    }
  },

  renderRegister(attempt = 0) {
    if (!this.enabled || !this.siteKey || this.registerWidgetId) return;

    const container = document.getElementById('turnstile-register-container');
    if (!container) return;
    container.style.display = 'flex';

    if (typeof turnstile === 'undefined') {
      if (attempt < 40) {
        setTimeout(() => this.renderRegister(attempt + 1), 150);
      }
      return;
    }

    const doRender = () => {
      if (this.registerWidgetId) return;
      try {
        const currentTheme = this.getTheme();
        this.registerWidgetId = turnstile.render('#turnstile-register-container', {
          sitekey: this.siteKey,
          theme: currentTheme,
          callback: (token) => {
            this.registerToken = token;
          },
          'expired-callback': () => {
            this.registerToken = null;
          },
          'error-callback': () => {
            this.registerToken = null;
          }
        });
      } catch (e) {
        console.warn("Turnstile register render xatosi:", e);
      }
    };

    if (typeof turnstile.render === 'function') {
      doRender();
    } else if (typeof turnstile.ready === 'function') {
      turnstile.ready(doRender);
    }
  },

  updateTheme(theme) {
    if (typeof turnstile === 'undefined') return;

    const loginBox = document.getElementById('login-box');
    const isLoginActive = loginBox && loginBox.style.display !== 'none';

    if (this.loginWidgetId) {
      try { turnstile.remove(this.loginWidgetId); } catch (e) {}
      this.loginWidgetId = null;
      this.loginToken = null;
      const c = document.getElementById('turnstile-login-container');
      if (c) c.innerHTML = '';
      if (isLoginActive) {
        this.renderLogin();
      }
    }

    if (this.registerWidgetId) {
      try { turnstile.remove(this.registerWidgetId); } catch (e) {}
      this.registerWidgetId = null;
      this.registerToken = null;
      const c = document.getElementById('turnstile-register-container');
      if (c) c.innerHTML = '';
      if (!isLoginActive) {
        this.renderRegister();
      }
    }
  },

  getLoginToken() {
    if (!this.enabled) return null;
    if (this.loginToken) return this.loginToken;
    if (typeof turnstile !== 'undefined' && this.loginWidgetId) {
      const resp = turnstile.getResponse(this.loginWidgetId);
      if (resp) return resp;
    }
    const form = document.getElementById('login-form');
    const input = form ? form.querySelector('[name="cf-turnstile-response"]') : null;
    return input ? input.value : null;
  },

  getRegisterToken() {
    if (!this.enabled) return null;
    if (this.registerToken) return this.registerToken;
    if (typeof turnstile !== 'undefined' && this.registerWidgetId) {
      const resp = turnstile.getResponse(this.registerWidgetId);
      if (resp) return resp;
    }
    const form = document.getElementById('register-form');
    const input = form ? form.querySelector('[name="cf-turnstile-response"]') : null;
    return input ? input.value : null;
  },

  resetLogin() {
    this.loginToken = null;
    if (typeof turnstile !== 'undefined' && this.loginWidgetId) {
      try { turnstile.reset(this.loginWidgetId); } catch {}
    }
  },

  resetRegister() {
    this.registerToken = null;
    if (typeof turnstile !== 'undefined' && this.registerWidgetId) {
      try { turnstile.reset(this.registerWidgetId); } catch {}
    }
  }
};

window.onloadTurnstileCallback = function() {
  if (window.TurnstileAuth && typeof window.TurnstileAuth.renderWidgets === 'function') {
    window.TurnstileAuth.renderWidgets();
  }
};

window.Auth = Auth;
window.GoogleAuth = GoogleAuth;
window.TurnstileAuth = TurnstileAuth;
document.addEventListener('DOMContentLoaded', () => Auth.init());

