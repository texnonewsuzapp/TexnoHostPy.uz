
(function sanitizeInitialUrl() {
  if (typeof window !== 'undefined' && window.location.hash) {
    const raw = window.location.hash.replace(/^#\/?/, '');
    const cleanSub = raw ? '/' + raw : '/home';
    window.history.replaceState(null, '', '/app' + cleanSub);
  }
})();

const Router = {
  routes: {},
  currentRoute: null,
  basePrefix: '/app',

  init(routes) {
    this.routes = routes;

    window.addEventListener('popstate', () => this.handleRoute());

    window.addEventListener('hashchange', () => {
      if (window.location.hash) {
        const raw = window.location.hash.replace(/^#\/?/, '');
        const cleanSub = raw ? '/' + raw : '/home';
        window.history.replaceState(null, '', this.basePrefix + cleanSub);
        this.handleRoute();
      }
    });

    document.addEventListener('click', (e) => {
      
      const routeEl = e.target.closest('[data-route]');
      if (routeEl) {
        e.preventDefault();
        const targetRoute = routeEl.getAttribute('data-route');
        if (targetRoute) {
          this.navigate(targetRoute);
          return;
        }
      }

      const anchor = e.target.closest('a[href^="/app"]');
      if (anchor && !anchor.hasAttribute('target') && !anchor.hasAttribute('download')) {
        e.preventDefault();
        const href = anchor.getAttribute('href');
        this.navigate(href);
      }
    });

    this.handleRoute();
  },

  navigate(path) {
    if (!path) path = '/home';

    path = path.replace(/^#\/?/, '/');

    if (path.startsWith(this.basePrefix)) {
      path = path.slice(this.basePrefix.length);
    }

    if (!path || path === '/') {
      path = '/home';
    }

    if (!path.startsWith('/')) {
      path = '/' + path;
    }

    const fullUrl = this.basePrefix + path;

    if (window.location.pathname !== fullUrl || window.location.hash) {
      window.history.pushState(null, '', fullUrl);
    }

    this.handleRoute();
  },

  handleRoute() {
    
    if (window.location.hash) {
      const raw = window.location.hash.replace(/^#\/?/, '');
      const cleanSub = raw ? '/' + raw : '/home';
      window.history.replaceState(null, '', this.basePrefix + cleanSub);
    }

    let currentPath = window.location.pathname;

    if (currentPath.startsWith(this.basePrefix)) {
      currentPath = currentPath.slice(this.basePrefix.length);
    }

    if (!currentPath || currentPath === '/' || currentPath === '') {
      currentPath = '/home';
    }
    if (!currentPath.startsWith('/')) {
      currentPath = '/' + currentPath;
    }

    for (const pattern in this.routes) {
      const match = this.matchRoute(pattern, currentPath);
      if (match) {
        if (this.currentRoute && this.currentRoute.startsWith('/logs') && !pattern.startsWith('/logs')) {
          if (window.LogsViewer && typeof window.LogsViewer.destroy === 'function') {
            window.LogsViewer.destroy();
          }
        }
        this.currentRoute = pattern;
        this.updateActiveNav(pattern);
        if (window.App && typeof window.App.toggleSidebar === 'function') {
          window.App.toggleSidebar(false);
        }
        this.routes[pattern](match.params);
        return;
      }
    }

    if (this.routes['/home'] && currentPath !== '/home') {
      this.navigate('/home');
    }
  },

  matchRoute(pattern, path) {
    const patternParts = pattern.split('/').filter(Boolean);
    const pathParts = path.split('/').filter(Boolean);

    if (patternParts.length !== pathParts.length) return null;

    const params = {};
    for (let i = 0; i < patternParts.length; i++) {
      if (patternParts[i].startsWith(':')) {
        const paramName = patternParts[i].slice(1);
        params[paramName] = pathParts[i];
      } else if (patternParts[i] !== pathParts[i]) {
        return null;
      }
    }

    return { params };
  },

  updateActiveNav(routePattern) {
    const links = document.querySelectorAll('.sidebar-link');
    links.forEach(l => {
      const target = l.getAttribute('data-route') || (l.getAttribute('href') ? l.getAttribute('href').replace(/^\/app/, '') : null);
      if (target && (routePattern === target || (target !== '/home' && routePattern.startsWith(target)))) {
        l.classList.add('active');
      } else {
        l.classList.remove('active');
      }
    });
  }
};

window.Router = Router;
