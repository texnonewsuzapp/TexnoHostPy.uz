
import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models

class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='SystemSetting',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('maintenance_mode', models.BooleanField(default=False, help_text="Yoqilsa, oddiy foydalanuvchilarga texnik ta'mirlash sahifasi ko'rsatiladi.", verbose_name='Texnik ishlar rejimi (Maintenance Mode)')),
                ('registration_enabled', models.BooleanField(default=True, help_text="O'chirilsa, yangi foydalanuvchilar ro'yxatdan o'ta olmaydi.", verbose_name="Ro'yxatdan o'tish (Registration)")),
                ('default_disk_mb', models.FloatField(default=50.0, help_text="Yangi ro'yxatdan o'tgan foydalanuvchilarga beriladigan disk hajmi.", verbose_name='Standart disk kvotasi (MB)')),
                ('default_max_bots', models.IntegerField(default=2, help_text="Yangi foydalanuvchilar bir vaqtda ishga tushirishi mumkin bo'lgan maksimal botlar.", verbose_name='Standart maksimal botlar soni')),
                ('max_upload_size_mb', models.IntegerField(default=25, verbose_name='Maksimal fayl yuklash hajmi (MB)')),
                ('announcement_banner', models.TextField(blank=True, default='', verbose_name="Umumiy e'lon banneri")),
                ('announcement_active', models.BooleanField(default=False, verbose_name="E'lon banneri faol")),
                ('updated_at', models.DateTimeField(auto_now=True, verbose_name="So'nggi o'zgartirish")),
            ],
            options={
                'verbose_name': 'Tizim Sozlamasi',
                'verbose_name_plural': 'Tizim Sozlamalari',
            },
        ),
        migrations.CreateModel(
            name='AdminAuditLog',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('action', models.CharField(choices=[('LOGIN', 'Admin Tizimga Kirdi'), ('USER_QUOTA_UPDATE', "Kvota O'zgartirildi"), ('USER_BAN', 'Foydalanuvchi Bloklandi'), ('USER_UNBAN', 'Foydalanuvchi Blokdan Chiqarildi'), ('USER_PASSWORD_RESET', 'Parol Yangilandi'), ('BOT_KILL', "Bot Majburiy To'xtatildi"), ('SETTINGS_UPDATE', "Tizim Sozlamalari O'zgartirildi"), ('BROADCAST_SENT', "Tizim E'loni Yuborildi")], max_length=50, verbose_name='Harakat turi')),
                ('details', models.TextField(blank=True, verbose_name='Tafsilotlar')),
                ('ip_address', models.GenericIPAddressField(blank=True, null=True, verbose_name='IP Manzil')),
                ('created_at', models.DateTimeField(auto_now_add=True, verbose_name='Vaqt')),
                ('admin', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='admin_audit_logs', to=settings.AUTH_USER_MODEL, verbose_name='Admin')),
                ('target_user', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='audit_target_logs', to=settings.AUTH_USER_MODEL, verbose_name='Nishon foydalanuvchi')),
            ],
            options={
                'verbose_name': 'Admin Audit Jurnali',
                'verbose_name_plural': 'Admin Audit Jurnallari',
                'ordering': ['-created_at'],
            },
        ),
    ]
