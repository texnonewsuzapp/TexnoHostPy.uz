from django.contrib import admin
from .models import SystemSetting, AdminAuditLog

@admin.register(SystemSetting)
class SystemSettingAdmin(admin.ModelAdmin):
    list_display = ('__str__', 'maintenance_mode', 'registration_enabled', 'email_verification_required', 'default_disk_mb', 'default_max_bots', 'updated_at')

    def has_add_permission(self, request):
        return not SystemSetting.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False

@admin.register(AdminAuditLog)
class AdminAuditLogAdmin(admin.ModelAdmin):
    list_display = ('created_at', 'admin', 'action', 'target_user', 'ip_address')
    list_filter = ('action', 'created_at')
    search_fields = ('admin__username', 'target_user__username', 'details', 'ip_address')
    ordering = ('-created_at',)
    readonly_fields = ('admin', 'action', 'target_user', 'details', 'ip_address', 'created_at')

    def has_add_permission(self, request):
        return False
