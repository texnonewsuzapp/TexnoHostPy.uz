import os
import psutil
from datetime import datetime, timedelta
from django.utils import timezone
from django.contrib.auth import authenticate, get_user_model
from django.db.models import Sum, Q
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken

from .models import SystemSetting, AdminAuditLog
from .permissions import IsAdminOrSuperuser
from .serializers import (
    SystemSettingSerializer,
    AdminAuditLogSerializer,
    AdminUserListSerializer,
    AdminUserUpdateSerializer,
    AdminBotProcessSerializer,
    AdminBroadcastSerializer
)
from apps.botengine.models import BotProcess, BotLog
from apps.botengine.runner import stop_bot_process
from apps.filemanager.models import File
from apps.accounts.models import UserQuota
from apps.notifications.models import Notification

User = get_user_model()

class AdminLoginAPIView(APIView):
    """
    Dedicated superadmin authentication endpoint.
    Only allows users with is_staff=True or is_superuser=True.
    """
    permission_classes = [AllowAny]

    def post(self, request):
        username = request.data.get('username', '').strip()
        password = request.data.get('password', '').strip()

        if not username or not password:
            return Response(
                {"error": "Login va parolni kiriting."},
                status=status.HTTP_400_BAD_REQUEST
            )

        user = authenticate(request, username=username, password=password)

        if not user:
            return Response(
                {"error": "Login yoki parol noto'g'ri."},
                status=status.HTTP_401_UNAUTHORIZED
            )

        if not (user.is_staff or user.is_superuser):
            return Response(
                {"error": "Kechirasiz, sizda ushbu boshqaruv markaziga kirish huquqi (Admin huquqi) mavjud emas."},
                status=status.HTTP_403_FORBIDDEN
            )

        if not user.is_active:
            return Response(
                {"error": "Ushbu admin hisobi bloklangan."},
                status=status.HTTP_403_FORBIDDEN
            )

        refresh = RefreshToken.for_user(user)
        access = str(refresh.access_token)

        AdminAuditLog.log(
            admin=user,
            action='LOGIN',
            details=f"Admin {user.username} boshqaruv markaziga muvaffaqiyatli kirdi.",
            request=request
        )

        return Response({
            "message": f"Xush kelibsiz, {user.username}!",
            "tokens": {
                "access": access,
                "refresh": str(refresh)
            },
            "user": {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "is_staff": user.is_staff,
                "is_superuser": user.is_superuser
            }
        }, status=status.HTTP_200_OK)

class AdminMetricsAPIView(APIView):
    """
    Real-time server telemetry and platform overview metrics.
    """
    permission_classes = [IsAdminOrSuperuser]

    def get(self, request):
        try:
            cpu_percent = psutil.cpu_percent(interval=None)
            vm = psutil.virtual_memory()
            disk = psutil.disk_usage('/')

            server_telemetry = {
                "cpu_percent": cpu_percent,
                "ram_total_mb": round(vm.total / (1024 * 1024), 1),
                "ram_used_mb": round(vm.used / (1024 * 1024), 1),
                "ram_free_mb": round(vm.available / (1024 * 1024), 1),
                "ram_percent": vm.percent,
                "disk_total_gb": round(disk.total / (1024 * 1024 * 1024), 2),
                "disk_used_gb": round(disk.used / (1024 * 1024 * 1024), 2),
                "disk_free_gb": round(disk.free / (1024 * 1024 * 1024), 2),
                "disk_percent": disk.percent,
            }
        except Exception as e:
            server_telemetry = {
                "cpu_percent": 0.0,
                "ram_total_mb": 0,
                "ram_used_mb": 0,
                "ram_free_mb": 0,
                "ram_percent": 0,
                "disk_total_gb": 0,
                "disk_used_gb": 0,
                "disk_free_gb": 0,
                "disk_percent": 0,
                "error": str(e)
            }

        now = timezone.now()
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

        total_users = User.objects.count()
        active_users = User.objects.filter(is_active=True).count()
        banned_users = User.objects.filter(is_active=False).count()
        today_users = User.objects.filter(date_joined__gte=today_start).count()

        total_bots = BotProcess.objects.count()
        running_bots = BotProcess.objects.filter(status='running').count()
        crashed_bots = BotProcess.objects.filter(status='crashed').count()
        total_files = File.objects.count()

        total_disk_used_mb = UserQuota.objects.aggregate(total=Sum('used_disk_mb'))['total'] or 0.0

        settings_obj = SystemSetting.get_settings()
        recent_logs = AdminAuditLog.objects.all()[:6]

        return Response({
            "telemetry": server_telemetry,
            "platform": {
                "total_users": total_users,
                "active_users": active_users,
                "banned_users": banned_users,
                "today_users": today_users,
                "total_bots": total_bots,
                "running_bots": running_bots,
                "crashed_bots": crashed_bots,
                "total_files": total_files,
                "total_disk_used_mb": round(total_disk_used_mb, 2)
            },
            "settings": {
                "maintenance_mode": settings_obj.maintenance_mode,
                "registration_enabled": settings_obj.registration_enabled,
                "default_disk_mb": settings_obj.default_disk_mb,
                "default_max_bots": settings_obj.default_max_bots,
                "announcement_active": settings_obj.announcement_active
            },
            "recent_audit_logs": AdminAuditLogSerializer(recent_logs, many=True).data
        })

class AdminUsersAPIView(APIView):
    """
    List and search platform users.
    """
    permission_classes = [IsAdminOrSuperuser]

    def get(self, request):
        queryset = User.objects.select_related('quota').all().order_by('-date_joined')

        q = request.query_params.get('q', '').strip()
        if q:
            queryset = queryset.filter(
                Q(username__icontains=q) | Q(email__icontains=q)
            )

        status_filter = request.query_params.get('status', '').strip()
        if status_filter == 'active':
            queryset = queryset.filter(is_active=True)
        elif status_filter == 'banned':
            queryset = queryset.filter(is_active=False)
        elif status_filter == 'admin':
            queryset = queryset.filter(Q(is_staff=True) | Q(is_superuser=True))

        serializer = AdminUserListSerializer(queryset, many=True)
        return Response(serializer.data)

class AdminUserDetailAPIView(APIView):
    """
    Retrieve or update a specific user (quota, ban status, password reset).
    """
    permission_classes = [IsAdminOrSuperuser]

    def get(self, request, user_id):
        try:
            target_user = User.objects.select_related('quota').get(id=user_id)
        except User.DoesNotExist:
            return Response({"error": "Foydalanuvchi topilmadi."}, status=status.HTTP_404_NOT_FOUND)

        user_data = AdminUserListSerializer(target_user).data

        user_bots = BotProcess.objects.filter(owner=target_user)
        bots_data = AdminBotProcessSerializer(user_bots, many=True).data

        return Response({
            "user": user_data,
            "bots": bots_data
        })

    def post(self, request, user_id):
        try:
            target_user = User.objects.select_related('quota').get(id=user_id)
        except User.DoesNotExist:
            return Response({"error": "Foydalanuvchi topilmadi."}, status=status.HTTP_404_NOT_FOUND)

        serializer = AdminUserUpdateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        changes = []

        quota, _ = UserQuota.objects.get_or_create(user=target_user)
        if 'max_disk_mb' in serializer.validated_data:
            old_disk = quota.max_disk_mb
            new_disk = serializer.validated_data['max_disk_mb']
            quota.max_disk_mb = new_disk
            quota.save(update_fields=['max_disk_mb'])
            changes.append(f"Disk kvotasi: {old_disk}MB -> {new_disk}MB")

        if 'max_running_bots' in serializer.validated_data:
            old_bots = quota.max_running_bots
            new_bots = serializer.validated_data['max_running_bots']
            quota.max_running_bots = new_bots
            quota.save(update_fields=['max_running_bots'])
            changes.append(f"Bot limiti: {old_bots} -> {new_bots}")

        if 'is_active' in serializer.validated_data:
            new_active = serializer.validated_data['is_active']
            if target_user.is_active != new_active:
                target_user.is_active = new_active
                target_user.save(update_fields=['is_active'])
                if not new_active:
                    active_bots = BotProcess.objects.filter(owner=target_user, status='running')
                    for b in active_bots:
                        stop_bot_process(b)
                    changes.append("Foydalanuvchi bloklandi (barcha faol botlari to'xtatildi)")
                    AdminAuditLog.log(
                        admin=request.user,
                        action='USER_BAN',
                        target_user=target_user,
                        details="Admin tomonidan bloklandi va botlari to'xtatildi.",
                        request=request
                    )
                else:
                    changes.append("Foydalanuvchi blokdan chiqarildi")
                    AdminAuditLog.log(
                        admin=request.user,
                        action='USER_UNBAN',
                        target_user=target_user,
                        details="Admin tomonidan blokdan chiqarildi.",
                        request=request
                    )

        if serializer.validated_data.get('new_password'):
            new_pass = serializer.validated_data['new_password']
            target_user.set_password(new_pass)
            target_user.save(update_fields=['password'])
            changes.append("Yangi parol o'rnatildi")
            AdminAuditLog.log(
                admin=request.user,
                action='USER_PASSWORD_RESET',
                target_user=target_user,
                details="Admin tomonidan yangi parol belgilandi.",
                request=request
            )

        if changes:
            AdminAuditLog.log(
                admin=request.user,
                action='USER_QUOTA_UPDATE',
                target_user=target_user,
                details="; ".join(changes),
                request=request
            )

        return Response({
            "message": "Foydalanuvchi muvaffaqiyatli yangilandi.",
            "changes": changes,
            "user": AdminUserListSerializer(target_user).data
        })

class AdminBotsAPIView(APIView):
    """
    List all running and registered bots across the entire server.
    """
    permission_classes = [IsAdminOrSuperuser]

    def get(self, request):
        queryset = BotProcess.objects.select_related('owner', 'file').all().order_by('-updated_at')

        status_filter = request.query_params.get('status', '').strip()
        if status_filter:
            queryset = queryset.filter(status=status_filter)

        serializer = AdminBotProcessSerializer(queryset, many=True)
        return Response(serializer.data)

class AdminKillBotAPIView(APIView):
    """
    Forcibly terminate any running bot process on the server.
    """
    permission_classes = [IsAdminOrSuperuser]

    def post(self, request, bot_id):
        try:
            bot = BotProcess.objects.select_related('owner', 'file').get(id=bot_id)
        except BotProcess.DoesNotExist:
            return Response({"error": "Bot topilmadi."}, status=status.HTTP_404_NOT_FOUND)

        stop_bot_process(bot)

        if bot.pid:
            try:
                p = psutil.Process(bot.pid)
                p.kill()
            except Exception:
                pass

        bot.status = 'stopped'
        bot.stopped_at = timezone.now()
        bot.save(update_fields=['status', 'stopped_at'])

        AdminAuditLog.log(
            admin=request.user,
            action='BOT_KILL',
            target_user=bot.owner,
            details=f"Bot '{bot.file.name}' (PID: {bot.pid}) majburiy to'xtatildi.",
            request=request
        )

        return Response({
            "message": f"'{bot.file.name}' boti majburiy to'xtatildi.",
            "bot": AdminBotProcessSerializer(bot).data
        })

class AdminBotLogsAPIView(APIView):
    """
    Retrieve execution logs for any bot.
    """
    permission_classes = [IsAdminOrSuperuser]

    def get(self, request, bot_id):
        try:
            bot = BotProcess.objects.select_related('owner', 'file').get(id=bot_id)
        except BotProcess.DoesNotExist:
            return Response({"error": "Bot topilmadi."}, status=status.HTTP_404_NOT_FOUND)

        logs = BotLog.objects.filter(process=bot).order_by('-timestamp')[:200]
        logs_list = [
            {
                "id": l.id,
                "level": l.level,
                "message": l.message,
                "timestamp": l.timestamp.strftime('%H:%M:%S')
            }
            for l in reversed(logs)
        ]

        return Response({
            "bot_name": bot.file.name,
            "owner": bot.owner.username,
            "status": bot.status,
            "logs": logs_list
        })

class AdminSettingsAPIView(APIView):
    """
    Retrieve or update global platform settings.
    """
    permission_classes = [IsAdminOrSuperuser]

    def get(self, request):
        settings_obj = SystemSetting.get_settings()
        return Response(SystemSettingSerializer(settings_obj).data)

    def post(self, request):
        settings_obj = SystemSetting.get_settings()
        serializer = SystemSettingSerializer(settings_obj, data=request.data, partial=True)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        serializer.save()

        AdminAuditLog.log(
            admin=request.user,
            action='SETTINGS_UPDATE',
            details=f"Tizim sozlamalari yangilandi. Maintenance: {settings_obj.maintenance_mode}",
            request=request
        )

        return Response({
            "message": "Tizim sozlamalari muvaffaqiyatli saqlandi.",
            "settings": serializer.data
        })

class AdminBroadcastAPIView(APIView):
    """
    Send platform announcements or direct targeted messages.
    """
    permission_classes = [IsAdminOrSuperuser]

    def post(self, request):
        serializer = AdminBroadcastSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data
        target_user = None

        if data['target_type'] == 'single':
            recipient_id = data.get('recipient_id')
            if not recipient_id:
                return Response(
                    {"error": "Alohida foydalanuvchiga yuborish uchun recipient_id ko'rsatilishi shart."},
                    status=status.HTTP_400_BAD_REQUEST
                )
            try:
                target_user = User.objects.get(id=recipient_id)
            except User.DoesNotExist:
                return Response({"error": "Qabul qiluvchi topilmadi."}, status=status.HTTP_404_NOT_FOUND)

        notification = Notification.objects.create(
            title=data['title'],
            message=data['message'],
            type=data['type'],
            target_type=data['target_type'],
            recipient=target_user,
            created_by=request.user
        )

        AdminAuditLog.log(
            admin=request.user,
            action='BROADCAST_SENT',
            target_user=target_user,
            details=f"E'lon yuborildi: '{notification.title}' ({notification.get_target_type_display()})",
            request=request
        )

        return Response({
            "message": "Bildirishnoma muvaffaqiyatli tarqatildi!",
            "notification_id": notification.id
        }, status=status.HTTP_201_CREATED)

class AdminAuditLogsAPIView(APIView):
    """
    View audit history of superadmin operations.
    """
    permission_classes = [IsAdminOrSuperuser]

    def get(self, request):
        logs = AdminAuditLog.objects.all().order_by('-created_at')[:100]
        return Response(AdminAuditLogSerializer(logs, many=True).data)
