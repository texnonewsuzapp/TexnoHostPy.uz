from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import SystemSetting, AdminAuditLog
from apps.botengine.models import BotProcess
from apps.filemanager.models import File
from apps.accounts.models import UserQuota

User = get_user_model()

class SystemSettingSerializer(serializers.ModelSerializer):
    class Meta:
        model = SystemSetting
        fields = [
            'maintenance_mode',
            'registration_enabled',
            'email_verification_required',
            'default_disk_mb',
            'default_max_bots',
            'max_upload_size_mb',
            'announcement_banner',
            'announcement_active',
            'google_client_id',
            'google_client_secret',
            'turnstile_enabled',
            'turnstile_site_key',
            'turnstile_secret_key',
            'updated_at'
        ]
        read_only_fields = ['updated_at']

class AdminAuditLogSerializer(serializers.ModelSerializer):
    admin_username = serializers.CharField(source='admin.username', read_only=True, default='Tizim')
    target_username = serializers.CharField(source='target_user.username', read_only=True, default=None)
    action_display = serializers.CharField(source='get_action_display', read_only=True)

    class Meta:
        model = AdminAuditLog
        fields = [
            'id',
            'admin_username',
            'action',
            'action_display',
            'target_username',
            'details',
            'ip_address',
            'created_at'
        ]

class AdminUserListSerializer(serializers.ModelSerializer):
    used_disk_mb = serializers.FloatField(source='quota.used_disk_mb', read_only=True, default=0.0)
    max_disk_mb = serializers.FloatField(source='quota.max_disk_mb', read_only=True, default=50.0)
    max_running_bots = serializers.IntegerField(source='quota.max_running_bots', read_only=True, default=2)
    running_bots_count = serializers.SerializerMethodField()
    files_count = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            'id',
            'username',
            'email',
            'is_active',
            'is_staff',
            'is_superuser',
            'date_joined',
            'last_login',
            'used_disk_mb',
            'max_disk_mb',
            'max_running_bots',
            'running_bots_count',
            'files_count'
        ]

    def get_running_bots_count(self, obj):
        return BotProcess.objects.filter(owner=obj, status='running').count()

    def get_files_count(self, obj):
        return File.objects.filter(owner=obj).count()

class AdminUserUpdateSerializer(serializers.Serializer):
    max_disk_mb = serializers.FloatField(required=False, min_value=1.0)
    max_running_bots = serializers.IntegerField(required=False, min_value=1, max_value=50)
    is_active = serializers.BooleanField(required=False)
    new_password = serializers.CharField(required=False, min_length=6, allow_blank=True)

class AdminBotProcessSerializer(serializers.ModelSerializer):
    owner_username = serializers.CharField(source='owner.username', read_only=True)
    file_name = serializers.CharField(source='file.name', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)

    class Meta:
        model = BotProcess
        fields = [
            'id',
            'owner_username',
            'file_name',
            'file_id',
            'status',
            'status_display',
            'pid',
            'container_id',
            'started_at',
            'stopped_at',
            'restart_count',
            'last_error',
            'updated_at'
        ]

class AdminBroadcastSerializer(serializers.Serializer):
    title = serializers.CharField(max_length=200)
    message = serializers.CharField()
    type = serializers.ChoiceField(choices=['info', 'success', 'warning', 'danger'], default='info')
    target_type = serializers.ChoiceField(choices=['all', 'single'], default='all')
    recipient_id = serializers.IntegerField(required=False, allow_null=True)
