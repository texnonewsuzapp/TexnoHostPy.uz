from django.urls import path
from .views import (
    AdminLoginAPIView,
    AdminMetricsAPIView,
    AdminUsersAPIView,
    AdminUserDetailAPIView,
    AdminBotsAPIView,
    AdminKillBotAPIView,
    AdminBotLogsAPIView,
    AdminSettingsAPIView,
    AdminBroadcastAPIView,
    AdminAuditLogsAPIView
)

urlpatterns = [
    path('auth/login/', AdminLoginAPIView.as_view(), name='admin_login_api'),

    path('metrics/', AdminMetricsAPIView.as_view(), name='admin_metrics_api'),

    path('users/', AdminUsersAPIView.as_view(), name='admin_users_api'),
    path('users/<int:user_id>/', AdminUserDetailAPIView.as_view(), name='admin_user_detail_api'),

    path('bots/', AdminBotsAPIView.as_view(), name='admin_bots_api'),
    path('bots/<int:bot_id>/kill/', AdminKillBotAPIView.as_view(), name='admin_kill_bot_api'),
    path('bots/<int:bot_id>/logs/', AdminBotLogsAPIView.as_view(), name='admin_bot_logs_api'),

    path('settings/', AdminSettingsAPIView.as_view(), name='admin_settings_api'),

    path('broadcast/', AdminBroadcastAPIView.as_view(), name='admin_broadcast_api'),

    path('audit-logs/', AdminAuditLogsAPIView.as_view(), name='admin_audit_logs_api'),
]
