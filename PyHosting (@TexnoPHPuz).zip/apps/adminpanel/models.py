from django.db import models
from django.conf import settings

class SystemSetting(models.Model):
    """
    Singleton model for global PyHosting platform configuration.
    """
    maintenance_mode = models.BooleanField(
        default=False,
        verbose_name="Texnik ishlar rejimi (Maintenance Mode)",
        help_text="Yoqilsa, oddiy foydalanuvchilarga texnik ta'mirlash sahifasi ko'rsatiladi."
    )
    registration_enabled = models.BooleanField(
        default=True,
        verbose_name="Ro'yxatdan o'tish (Registration)",
        help_text="O'chirilsa, yangi foydalanuvchilar ro'yxatdan o'ta olmaydi."
    )
    default_disk_mb = models.FloatField(
        default=50.0,
        verbose_name="Standart disk kvotasi (MB)",
        help_text="Yangi ro'yxatdan o'tgan foydalanuvchilarga beriladigan disk hajmi."
    )
    default_max_bots = models.IntegerField(
        default=2,
        verbose_name="Standart maksimal botlar soni",
        help_text="Yangi foydalanuvchilar bir vaqtda ishga tushirishi mumkin bo'lgan maksimal botlar."
    )
    max_upload_size_mb = models.IntegerField(
        default=25,
        verbose_name="Maksimal fayl yuklash hajmi (MB)"
    )
    announcement_banner = models.TextField(
        blank=True,
        default="",
        verbose_name="Umumiy e'lon banneri"
    )
    announcement_active = models.BooleanField(
        default=False,
        verbose_name="E'lon banneri faol"
    )
    google_client_id = models.CharField(
        max_length=255,
        blank=True,
        default="",
        verbose_name="Google OAuth Client ID",
        help_text="Google Cloud Console Client ID (masalan: 123456789-xxx.apps.googleusercontent.com)"
    )
    google_client_secret = models.CharField(
        max_length=255,
        blank=True,
        default="",
        verbose_name="Google OAuth Client Secret",
        help_text="Google Cloud Console Client Secret"
    )
    turnstile_enabled = models.BooleanField(
        default=False,
        verbose_name="Cloudflare Turnstile (CAPTCHA) Faol",
        help_text="Kirish va ro'yxatdan o'tish formalarida Cloudflare Turnstile robot himoyasini yoqish"
    )
    turnstile_site_key = models.CharField(
        max_length=255,
        blank=True,
        default="",
        verbose_name="Turnstile Site Key",
        help_text="Cloudflare Turnstile Public Site Key (masalan: 0x4AAAAAA...)"
    )
    turnstile_secret_key = models.CharField(
        max_length=255,
        blank=True,
        default="",
        verbose_name="Turnstile Secret Key",
        help_text="Cloudflare Turnstile Secret Key (masalan: 0x4AAAAAA...)"
    )
    email_verification_required = models.BooleanField(
        default=False,
        verbose_name="Email tasdiqlash majburiy",
        help_text="Yoqilsa, yangi foydalanuvchilar pochtadagi havolani faollashtirmaguncha akkaunt ochilmaydi."
    )
    updated_at = models.DateTimeField(auto_now=True, verbose_name="So'nggi o'zgartirish")

    class Meta:
        verbose_name = "Tizim Sozlamasi"
        verbose_name_plural = "Tizim Sozlamalari"

    def __str__(self):
        return f"PyHosting Tizim Sozlamalari (Maintenance: {self.maintenance_mode})"

    @classmethod
    def get_settings(cls):
        try:
            obj, _ = cls.objects.get_or_create(id=1)
            return obj
        except Exception:
            return cls(
                id=1,
                maintenance_mode=False,
                registration_enabled=True,
                default_disk_mb=50.0,
                default_max_bots=2,
                email_verification_required=False,
                turnstile_enabled=False
            )

class AdminAuditLog(models.Model):
    """
    Audit logging for all critical superadmin actions.
    """
    ACTION_CHOICES = (
        ('LOGIN', 'Admin Tizimga Kirdi'),
        ('USER_QUOTA_UPDATE', 'Kvota O\'zgartirildi'),
        ('USER_BAN', 'Foydalanuvchi Bloklandi'),
        ('USER_UNBAN', 'Foydalanuvchi Blokdan Chiqarildi'),
        ('USER_PASSWORD_RESET', 'Parol Yangilandi'),
        ('BOT_KILL', 'Bot Majburiy To\'xtatildi'),
        ('SETTINGS_UPDATE', 'Tizim Sozlamalari O\'zgartirildi'),
        ('BROADCAST_SENT', 'Tizim E\'loni Yuborildi'),
        ('SECURITY_ALERT', '🚨 Xavfsizlik Qoidabuzarligi'),
    )

    admin = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='admin_audit_logs',
        verbose_name="Admin"
    )
    action = models.CharField(max_length=50, choices=ACTION_CHOICES, verbose_name="Harakat turi")
    target_user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='audit_target_logs',
        verbose_name="Nishon foydalanuvchi"
    )
    details = models.TextField(blank=True, verbose_name="Tafsilotlar")
    ip_address = models.GenericIPAddressField(null=True, blank=True, verbose_name="IP Manzil")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Vaqt")

    class Meta:
        verbose_name = "Admin Audit Jurnali"
        verbose_name_plural = "Admin Audit Jurnallari"
        ordering = ['-created_at']

    def __str__(self):
        admin_name = self.admin.username if self.admin else 'Tizim'
        return f"[{self.created_at.strftime('%Y-%m-%d %H:%M')}] {admin_name} -> {self.get_action_display()}"

    @classmethod
    def log(cls, admin, action: str, target_user=None, details: str = "", request=None):
        ip = None
        if request:
            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            if x_forwarded_for:
                ip = x_forwarded_for.split(',')[0].strip()
            else:
                ip = request.META.get('REMOTE_ADDR')

        return cls.objects.create(
            admin=admin if (admin and admin.is_authenticated) else None,
            action=action,
            target_user=target_user,
            details=details,
            ip_address=ip
        )
