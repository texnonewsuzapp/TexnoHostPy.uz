from django.apps import AppConfig

class AdminpanelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.adminpanel'
    verbose_name = 'Boshqaruv Markazi'
