"""PyHosting Admin Panel App"""
