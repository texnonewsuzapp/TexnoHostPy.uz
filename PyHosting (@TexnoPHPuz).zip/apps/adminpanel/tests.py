from django.test import TestCase, Client
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework_simplejwt.tokens import RefreshToken

from .models import SystemSetting, AdminAuditLog
from apps.accounts.models import UserQuota
from apps.botengine.models import BotProcess
from apps.filemanager.models import File
from apps.notifications.models import Notification

User = get_user_model()

class AdminPanelTestCase(TestCase):
    def setUp(self):
        self.admin = User.objects.create_superuser(
            username='rootadmin',
            email='root@pyhosting.uz',
            password='AdminPassword123!'
        )

        self.user = User.objects.create_user(
            username='regularuser',
            email='regular@pyhosting.uz',
            password='UserPassword123!'
        )

        self.admin_client = APIClient()
        self.admin_client.credentials(HTTP_AUTHORIZATION=f'Bearer {str(RefreshToken.for_user(self.admin).access_token)}')

        self.user_client = APIClient()
        self.user_client.credentials(HTTP_AUTHORIZATION=f'Bearer {str(RefreshToken.for_user(self.user).access_token)}')

        self.anon_client = APIClient()

    def test_admin_login_success(self):
        """Superadmin can log in via /api/admin/auth/login/."""
        res = self.anon_client.post('/api/admin/auth/login/', {
            'username': 'rootadmin',
            'password': 'AdminPassword123!'
        })
        self.assertEqual(res.status_code, 200)
        self.assertIn('tokens', res.data)
        self.assertIn('access', res.data['tokens'])

    def test_regular_user_cannot_login_to_admin_panel(self):
        """Regular user gets 403 Forbidden when attempting to log in to admin panel."""
        res = self.anon_client.post('/api/admin/auth/login/', {
            'username': 'regularuser',
            'password': 'UserPassword123!'
        })
        self.assertEqual(res.status_code, 403)
        self.assertIn('error', res.data)

    def test_admin_metrics_access(self):
        """Admin can access server telemetry & platform counts; regular user is blocked."""
        res_admin = self.admin_client.get('/api/admin/metrics/')
        self.assertEqual(res_admin.status_code, 200)
        self.assertIn('telemetry', res_admin.data)
        self.assertIn('platform', res_admin.data)
        self.assertIn('cpu_percent', res_admin.data['telemetry'])

        res_user = self.user_client.get('/api/admin/metrics/')
        self.assertEqual(res_user.status_code, 403)

    def test_admin_user_management(self):
        """Admin can list users and update quota / ban status."""
        res_list = self.admin_client.get('/api/admin/users/')
        self.assertEqual(res_list.status_code, 200)
        self.assertGreaterEqual(len(res_list.data), 2)

        res_update = self.admin_client.post(f'/api/admin/users/{self.user.id}/', {
            'max_disk_mb': 250.0,
            'max_running_bots': 5
        })
        self.assertEqual(res_update.status_code, 200)

        self.user.quota.refresh_from_db()
        self.assertEqual(self.user.quota.max_disk_mb, 250.0)
        self.assertEqual(self.user.quota.max_running_bots, 5)

        res_ban = self.admin_client.post(f'/api/admin/users/{self.user.id}/', {
            'is_active': False
        })
        self.assertEqual(res_ban.status_code, 200)
        self.user.refresh_from_db()
        self.assertFalse(self.user.is_active)

    def test_admin_settings_update(self):
        """Admin can retrieve and update global system settings."""
        res_get = self.admin_client.get('/api/admin/settings/')
        self.assertEqual(res_get.status_code, 200)
        self.assertFalse(res_get.data['maintenance_mode'])

        res_post = self.admin_client.post('/api/admin/settings/', {
            'maintenance_mode': True,
            'default_disk_mb': 100.0,
            'default_max_bots': 3
        })
        self.assertEqual(res_post.status_code, 200)

        settings_obj = SystemSetting.get_settings()
        self.assertTrue(settings_obj.maintenance_mode)
        self.assertEqual(settings_obj.default_disk_mb, 100.0)
        self.assertEqual(settings_obj.default_max_bots, 3)

    def test_admin_broadcast(self):
        """Admin can send broadcast and targeted notifications."""
        res = self.admin_client.post('/api/admin/broadcast/', {
            'title': 'Test Announcement',
            'message': 'Welcome to PyHosting update!',
            'type': 'info',
            'target_type': 'all'
        })
        self.assertEqual(res.status_code, 201)
        self.assertTrue(Notification.objects.filter(title='Test Announcement').exists())

    def test_maintenance_mode_middleware(self):
        """When maintenance mode is active, API returns 503 for normal users, while admin has access."""
        settings_obj = SystemSetting.get_settings()
        settings_obj.maintenance_mode = True
        settings_obj.save()

        res_user = self.user_client.get('/api/notifications/')
        self.assertEqual(res_user.status_code, 503)

        res_admin = self.admin_client.get('/api/admin/metrics/')
        self.assertEqual(res_admin.status_code, 200)

        settings_obj.maintenance_mode = False
        settings_obj.save()
