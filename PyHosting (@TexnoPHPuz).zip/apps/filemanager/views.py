import os
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from django.shortcuts import get_object_or_404
from django.core.exceptions import ValidationError
from .models import Folder, File, ALLOWED_EXTENSIONS, sanitize_name
from .serializers import FolderSerializer, FileSerializer, FileContentSerializer
from apps.accounts.serializers import UserQuotaSerializer

SAMPLE_BOT_TEMPLATE = """# Py Hosting - Telegram Bot (telebot)
# Serverda xotira (RAM) tejash va 24/7 stabil ishlash uchun telebot tavsiya etiladi.
import telebot
from telebot import apihelper
import time

# Tarmoq uzilishlari va "Connection reset by peer" xatolarini oldini olish:
apihelper.SESSION_TIME_TO_LIVE = 180  # Har 3 daqiqada eski sessiyalarni yangilash

# BotFather'dan olgan bot tokeningizni bu yerga yozing:
TOKEN = "SIZNING_BOT_TOKENINGIZ"
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.reply_to(message, "Salom! Men PyHosting serverida 24/7 faol ishlamoqdaman! 🚀")

@bot.message_handler(func=lambda message: True)
def echo_all(message):
    bot.reply_to(message, f"Siz yozdingiz: {message.text}")

if __name__ == "__main__":
    print("⚡ Bot muvaffaqiyatli ishga tushdi va xabarlarni kutmoqda...")
    # 24/7 tarmoq uzilishlariga (Read timeout) bardoshli rejim:
    bot.infinity_polling(timeout=10, long_polling_timeout=5)
"""

class FileTreeView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        folders = list(Folder.objects.filter(owner=user).select_related('parent').order_by('name'))
        files = list(File.objects.filter(owner=user).select_related('folder', 'folder__parent').prefetch_related('processes').order_by('name'))

        folder_dict = {f.id: f for f in folders}
        def get_cached_rel_path(f):
            parts = [f.name]
            curr_id = f.parent_id
            while curr_id and curr_id in folder_dict:
                parent_f = folder_dict[curr_id]
                parts.insert(0, parent_f.name)
                curr_id = parent_f.parent_id
            return "/".join(parts)

        folder_map = {}
        for folder in folders:
            folder_map[folder.id] = {
                'id': folder.id,
                'name': folder.name,
                'parent': folder.parent_id,
                'relative_path': get_cached_rel_path(folder),
                'folders': [],
                'files': [],
            }

        root_folders = []
        for folder in folders:
            item = folder_map[folder.id]
            if folder.parent_id and folder.parent_id in folder_map:
                folder_map[folder.parent_id]['folders'].append(item)
            else:
                root_folders.append(item)

        root_files = []
        for file in files:
            file_data = FileSerializer(file).data
            if file.folder_id and file.folder_id in folder_map:
                folder_map[file.folder_id]['files'].append(file_data)
            else:
                root_files.append(file_data)

        quota_data = UserQuotaSerializer(user.quota).data if hasattr(user, 'quota') else None

        return Response({
            'tree': root_folders,
            'root_files': root_files,
            'quota': quota_data
        })

class FolderCreateView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        name = request.data.get('name', '').strip()
        parent_id = request.data.get('parent_id')
        parent = None

        if parent_id:
            parent = get_object_or_404(Folder, id=parent_id, owner=request.user)

        try:
            cleaned_name = sanitize_name(name)
        except ValidationError as e:
            return Response({'error': str(e.message if hasattr(e, 'message') else e)}, status=status.HTTP_400_BAD_REQUEST)

        if Folder.objects.filter(owner=request.user, parent=parent, name=cleaned_name).exists():
            return Response({'error': "Bu papka allaqachon mavjud."}, status=status.HTTP_400_BAD_REQUEST)

        folder = Folder.objects.create(owner=request.user, parent=parent, name=cleaned_name)
        folder.get_disk_path().mkdir(parents=True, exist_ok=True)

        return Response(FolderSerializer(folder).data, status=status.HTTP_201_CREATED)

class FileUploadView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        uploaded_files = request.FILES.getlist('files')
        if not uploaded_files:
            single = request.FILES.get('file')
            if single:
                uploaded_files = [single]

        if not uploaded_files:
            return Response({'error': "Yuklash uchun fayl tanlanmadi."}, status=status.HTTP_400_BAD_REQUEST)

        folder_id = request.data.get('folder_id')
        folder = None
        if folder_id:
            folder = get_object_or_404(Folder, id=folder_id, owner=request.user)

        user_quota = request.user.quota
        created_files = []

        for f in uploaded_files:
            try:
                cleaned_name = sanitize_name(f.name)
            except ValidationError as e:
                return Response({'error': f"Fayl nomi xato: {f.name}"}, status=status.HTTP_400_BAD_REQUEST)

            ext = os.path.splitext(cleaned_name)[1].lower()
            if ext not in ALLOWED_EXTENSIONS:
                return Response({
                    'error': f"'{f.name}' fayl kengaytmasi ruxsat etilmagan. Faqat {', '.join(ALLOWED_EXTENSIONS)} qabul qilinadi."
                }, status=status.HTTP_400_BAD_REQUEST)

            if ext in ['.db', '.sqlite', '.sqlite3']:
                content = f.read()
                size_mb = len(content) / (1024.0 * 1024.0)
            else:
                raw_bytes = f.read()
                content = raw_bytes.decode('utf-8', errors='replace')
                size_mb = len(raw_bytes) / (1024.0 * 1024.0)

            if not user_quota.has_disk_space(size_mb):
                return Response({
                    'error': f"50MB disk kvotasi oshib ketdi! Qolgan bo'sh joy: {user_quota.max_disk_mb - user_quota.used_disk_mb:.2f} MB"
                }, status=status.HTTP_400_BAD_REQUEST)

            file_obj, _ = File.objects.get_or_create(
                owner=request.user,
                folder=folder,
                name=cleaned_name,
                defaults={'extension': ext}
            )
            try:
                file_obj.write_content(content)
            except ValidationError as val_err:
                if not file_obj.read_content():
                    file_obj.delete()
                err_text = val_err.message if hasattr(val_err, 'message') else str(val_err)
                return Response({'error': err_text}, status=status.HTTP_400_BAD_REQUEST)

            created_files.append(FileSerializer(file_obj).data)

        user_quota.recalculate_usage()
        return Response({
            'files': created_files,
            'message': f"{len(created_files)} ta fayl muvaffaqiyatli yuklandi!"
        }, status=status.HTTP_201_CREATED)

class FileCreateEmptyView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        name = request.data.get('name', '').strip()
        folder_id = request.data.get('folder_id')
        template_type = request.data.get('template', 'default')

        folder = None
        if folder_id:
            folder = get_object_or_404(Folder, id=folder_id, owner=request.user)

        try:
            cleaned_name = sanitize_name(name)
        except ValidationError as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

        ext = os.path.splitext(cleaned_name)[1].lower()
        if ext not in ALLOWED_EXTENSIONS:
            return Response({
                'error': f"Faqat quyidagi kengaytmalar ruxsat etiladi: {', '.join(ALLOWED_EXTENSIONS)}"
            }, status=status.HTTP_400_BAD_REQUEST)

        if File.objects.filter(owner=request.user, folder=folder, name=cleaned_name).exists():
            return Response({'error': "Bu nomdagi fayl allaqachon mavjud."}, status=status.HTTP_400_BAD_REQUEST)

        file_obj = File.objects.create(
            owner=request.user,
            folder=folder,
            name=cleaned_name,
            extension=ext
        )

        initial_content = ""
        if ext == '.py':
            initial_content = SAMPLE_BOT_TEMPLATE
        elif cleaned_name == 'requirements.txt':
            initial_content = "# PyHosting serverida oldindan o'rnatilgan ruxsat etilgan kutubxonalar:\npyTelegramBotAPI\nrequests\n"

        file_obj.write_content(initial_content)
        return Response(FileSerializer(file_obj).data, status=status.HTTP_201_CREATED)

class FileContentView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk):
        file_obj = get_object_or_404(File, id=pk, owner=request.user)
        try:
            file_obj.ensure_on_disk()
        except Exception:
            pass
        return Response(FileContentSerializer(file_obj).data)

    def patch(self, request, pk):
        file_obj = get_object_or_404(File, id=pk, owner=request.user)
        content = request.data.get('content')
        if content is None:
            return Response({'error': "'content' maydoni talab qilinadi."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            file_obj.write_content(content)
        except ValidationError as e:
            return Response({'error': str(e.message if hasattr(e, 'message') else e)}, status=status.HTTP_400_BAD_REQUEST)

        return Response(FileContentSerializer(file_obj).data)

class FileRenameView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, pk):
        file_obj = get_object_or_404(File, id=pk, owner=request.user)
        new_name = request.data.get('name', '').strip()

        try:
            cleaned_name = sanitize_name(new_name)
        except ValidationError as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

        ext = os.path.splitext(cleaned_name)[1].lower()
        if ext not in ALLOWED_EXTENSIONS:
            return Response({'error': f"Faqat {ALLOWED_EXTENSIONS} kengaytmalari ruxsat etiladi."}, status=status.HTTP_400_BAD_REQUEST)

        if File.objects.filter(owner=request.user, folder=file_obj.folder, name=cleaned_name).exclude(id=file_obj.id).exists():
            return Response({'error': "Bu nomdagi fayl allaqachon mavjud."}, status=status.HTTP_400_BAD_REQUEST)

        old_disk_path = file_obj.get_disk_path()
        file_obj.name = cleaned_name
        file_obj.extension = ext
        new_disk_path = file_obj.get_disk_path()

        if old_disk_path.exists():
            old_disk_path.rename(new_disk_path)

        file_obj.save(update_fields=['name', 'extension', 'updated_at'])
        return Response(FileSerializer(file_obj).data)

class FileDeleteView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def delete(self, request, pk):
        file_obj = get_object_or_404(File, id=pk, owner=request.user)
        for proc in file_obj.processes.filter(status='running'):
            from apps.botengine.runner import stop_bot_process
            stop_bot_process(proc)

        file_obj.delete()
        return Response({'message': "Fayl muvaffaqiyatli o'chirildi."}, status=status.HTTP_200_OK)

class FolderDeleteView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def delete(self, request, pk):
        folder = get_object_or_404(Folder, id=pk, owner=request.user)
        def get_all_folder_ids(f):
            ids = [f.id]
            for child in f.subfolders.all():
                ids.extend(get_all_folder_ids(child))
            return ids

        all_folder_ids = get_all_folder_ids(folder)
        files_in_folder = File.objects.filter(owner=request.user, folder_id__in=all_folder_ids)
        for f in files_in_folder:
            for proc in f.processes.filter(status='running'):
                from apps.botengine.runner import stop_bot_process
                stop_bot_process(proc)

        folder.delete()
        return Response({'message': "Papka muvaffaqiyatli o'chirildi."}, status=status.HTTP_200_OK)

from django.http import FileResponse, Http404
from .db_inspector import list_user_databases, get_database_schema, get_table_data, create_sample_database

class DatabaseListView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        databases = list_user_databases(request.user)
        return Response({'databases': databases})

class DatabaseSchemaView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, file_id):
        try:
            schema = get_database_schema(request.user, file_id)
            return Response(schema)
        except ValueError as e:
            return Response({'error': str(e)}, status=status.HTTP_404_NOT_FOUND)

class DatabaseTableView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, file_id, table_name):
        try:
            page = int(request.query_params.get('page', 1))
            page_size = int(request.query_params.get('page_size', 25))
            search = request.query_params.get('search', '')
            data = get_table_data(request.user, file_id, table_name, page, page_size, search)
            return Response(data)
        except ValueError as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class DatabaseSampleCreateView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        try:
            result = create_sample_database(request.user)
            return Response(result, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class DatabaseExportView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, file_id):
        file_obj = get_object_or_404(File, id=file_id, owner=request.user)
        disk_path = file_obj.get_disk_path()
        if not disk_path.exists():
            raise Http404("Fayl diskda topilmadi.")

        response = FileResponse(open(disk_path, 'rb'), as_attachment=True, filename=file_obj.name)
        return response
