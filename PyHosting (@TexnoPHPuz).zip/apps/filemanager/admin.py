from django.contrib import admin
from .models import Folder, File

@admin.register(Folder)
class FolderAdmin(admin.ModelAdmin):
    list_display = ('name', 'owner', 'parent', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('name', 'owner__username')
    ordering = ('owner', 'name')

@admin.register(File)
class FileAdmin(admin.ModelAdmin):
    list_display = ('name', 'owner', 'folder', 'extension', 'size_kb', 'updated_at')
    list_filter = ('extension', 'created_at', 'updated_at')
    search_fields = ('name', 'owner__username')
    ordering = ('-updated_at',)
    readonly_fields = ('size_kb', 'content_hash', 'created_at', 'updated_at')
