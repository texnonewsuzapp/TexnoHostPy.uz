import os
import hashlib
from pathlib import Path
from django.db import models
from django.conf import settings
from django.core.exceptions import ValidationError

ALLOWED_EXTENSIONS = ['.py', '.txt', '.db', '.sqlite', '.sqlite3', '.sql', '.env', '.json']

def sanitize_name(name: str) -> str:
    if not name:
        raise ValidationError("Nom bo'sh bo'lishi mumkin emas.")
    raw = name.strip()
    forbidden_chars = ['..', '/', '\\', '\0', ':', '*', '?', '"', '<', '>', '|']
    if any(c in raw for c in forbidden_chars):
        raise ValidationError("Nomda xavfli yoki taqiqlangan belgilar aniqlandi.")
    cleaned = os.path.basename(raw)
    upper_name = cleaned.upper().split('.')[0]
    if upper_name in ['CON', 'PRN', 'AUX', 'NUL', 'COM1', 'COM2', 'COM3', 'COM4', 'LPT1', 'LPT2']:
        raise ValidationError("Ushbu tizim fayl nomi ruxsat etilmagan.")
    return cleaned

class Folder(models.Model):
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='folders')
    name = models.CharField(max_length=120)
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='subfolders')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('owner', 'name', 'parent')
        ordering = ['name']

    def __str__(self):
        return f"{self.owner.username}: {self.get_relative_path()}"

    def clean(self):
        self.name = sanitize_name(self.name)
        cur = self.parent
        while cur is not None:
            if cur.id == self.id:
                raise ValidationError("Papka o'z-o'ziga ichma-ich joylashishi mumkin emas.")
            cur = cur.parent

    def get_relative_path(self) -> str:
        parts = [self.name]
        curr = self.parent
        while curr:
            parts.insert(0, curr.name)
            curr = curr.parent
        return "/".join(parts)

    def get_disk_path(self) -> Path:
        storage_base = getattr(settings, 'USER_STORAGE_ROOT', Path(settings.MEDIA_ROOT) / 'users')
        user_root = (storage_base / str(self.owner.id)).resolve()
        target = (user_root / Path(self.get_relative_path())).resolve()
        if not target.is_relative_to(user_root):
            raise ValidationError("Xavfsizlik xatosi: Papka yo'li foydalanuvchi katalogidan tashqariga chiqishi taqiqlangan.")
        return target

    def ensure_on_disk(self) -> Path:
        disk_path = self.get_disk_path()
        disk_path.mkdir(parents=True, exist_ok=True)
        return disk_path

    def delete(self, *args, **kwargs):
        disk_path = self.get_disk_path()
        super().delete(*args, **kwargs)
        if disk_path.exists():
            import shutil
            shutil.rmtree(disk_path, ignore_errors=True)
        if hasattr(self.owner, 'quota'):
            self.owner.quota.recalculate_usage()

class File(models.Model):
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='files')
    folder = models.ForeignKey(Folder, on_delete=models.CASCADE, null=True, blank=True, related_name='files')
    name = models.CharField(max_length=150)
    extension = models.CharField(max_length=10)
    size_kb = models.FloatField(default=0.0)
    content = models.TextField(blank=True, default='')
    is_binary = models.BooleanField(default=False)
    content_hash = models.CharField(max_length=64, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('owner', 'folder', 'name')
        ordering = ['name']

    def __str__(self):
        return f"{self.owner.username}: {self.get_relative_path()}"

    def clean(self):
        self.name = sanitize_name(self.name)
        ext = os.path.splitext(self.name)[1].lower()
        if ext not in ALLOWED_EXTENSIONS:
            raise ValidationError(f"Faqat quyidagi kengaytmalar ruxsat etiladi: {', '.join(ALLOWED_EXTENSIONS)}")
        self.extension = ext

    def get_relative_path(self) -> str:
        if self.folder:
            return f"{self.folder.get_relative_path()}/{self.name}"
        return self.name

    def get_disk_path(self) -> Path:
        storage_base = getattr(settings, 'USER_STORAGE_ROOT', Path(settings.MEDIA_ROOT) / 'users')
        user_root = (storage_base / str(self.owner.id)).resolve()
        if self.folder:
            target = (user_root / Path(self.folder.get_relative_path()) / self.name).resolve()
        else:
            target = (user_root / self.name).resolve()
        if not target.is_relative_to(user_root):
            raise ValidationError("Xavfsizlik xatosi: Fayl yo'li foydalanuvchi katalogidan tashqariga chiqishi taqiqlangan.")
        return target

    def ensure_on_disk(self) -> Path:
        """
        Guarantees that the file is physically present on disk.
        If the server container restarted or woke up from sleep (ephemeral disk wiped),
        this instantly reconstructs the file from the persistent PostgreSQL cloud database.
        """
        disk_path = self.get_disk_path()
        if not disk_path.exists():
            disk_path.parent.mkdir(parents=True, exist_ok=True)
            if self.is_binary and self.content:
                import base64
                try:
                    data = base64.b64decode(self.content.encode('ascii'))
                    disk_path.write_bytes(data)
                except Exception:
                    disk_path.write_text(self.content or '', encoding='utf-8')
            else:
                disk_path.write_text(self.content or '', encoding='utf-8')
        return disk_path

    def read_content(self) -> str:
        if self.content is not None and len(self.content) > 0:
            try:
                self.ensure_on_disk()
            except Exception:
                pass
            return self.content

        disk_path = self.get_disk_path()
        if disk_path.exists():
            try:
                disk_text = disk_path.read_text(encoding='utf-8', errors='replace')
                if disk_text:
                    self.content = disk_text
                    self.save(update_fields=['content'])
                return disk_text
            except Exception:
                return ""
        return self.content or ""

    def write_content(self, content):
        from apps.filemanager.security import inspect_file_content
        is_safe, err_msg = inspect_file_content(content, self.name, self.owner)
        if not is_safe:
            raise ValidationError(err_msg)

        disk_path = self.get_disk_path()
        disk_path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(content, str):
            content_bytes = content.encode('utf-8')
            disk_path.write_text(content, encoding='utf-8')
            self.content = content
            self.is_binary = False
        else:
            import base64
            content_bytes = content
            disk_path.write_bytes(content_bytes)
            self.content = base64.b64encode(content_bytes).decode('ascii')
            self.is_binary = True

        new_size_kb = len(content_bytes) / 1024.0

        size_diff_mb = (new_size_kb - self.size_kb) / 1024.0
        if hasattr(self.owner, 'quota'):
            if not self.owner.quota.has_disk_space(size_diff_mb):
                raise ValidationError(f"50MB disk kvotasi oshib ketdi! Mavjud bo'sh joy yetarli emas.")

        self.size_kb = round(new_size_kb, 3)
        self.content_hash = hashlib.sha256(content_bytes).hexdigest()
        self.save(update_fields=['content', 'is_binary', 'size_kb', 'content_hash', 'updated_at'])
        if hasattr(self.owner, 'quota'):
            self.owner.quota.recalculate_usage()

    def delete(self, *args, **kwargs):
        disk_path = self.get_disk_path()
        super().delete(*args, **kwargs)
        if disk_path.exists():
            try:
                disk_path.unlink()
            except Exception:
                pass
        if hasattr(self.owner, 'quota'):
            self.owner.quota.recalculate_usage()
