import os
from rest_framework import serializers
from .models import Folder, File, ALLOWED_EXTENSIONS, sanitize_name

class FolderSerializer(serializers.ModelSerializer):
    relative_path = serializers.SerializerMethodField()

    class Meta:
        model = Folder
        fields = ['id', 'name', 'parent', 'created_at', 'relative_path']
        read_only_fields = ['id', 'created_at', 'relative_path']

    def get_relative_path(self, obj):
        return obj.get_relative_path()

    def validate_name(self, value):
        return sanitize_name(value)

class FileSerializer(serializers.ModelSerializer):
    relative_path = serializers.SerializerMethodField()
    bot_status = serializers.SerializerMethodField()

    class Meta:
        model = File
        fields = ['id', 'name', 'extension', 'size_kb', 'folder', 'created_at', 'updated_at', 'relative_path', 'bot_status']
        read_only_fields = ['id', 'extension', 'size_kb', 'created_at', 'updated_at', 'relative_path', 'bot_status']

    def get_relative_path(self, obj):
        return obj.get_relative_path()

    def get_bot_status(self, obj):
        processes = list(obj.processes.all())
        return processes[0].status if processes else 'stopped'

    def validate_name(self, value):
        cleaned = sanitize_name(value)
        ext = os.path.splitext(cleaned)[1].lower()
        if ext not in ALLOWED_EXTENSIONS:
            raise serializers.ValidationError(f"Faqat quyidagi fayl turlariga ruxsat beriladi: {', '.join(ALLOWED_EXTENSIONS)}")
        return cleaned

class FileContentSerializer(serializers.ModelSerializer):
    content = serializers.SerializerMethodField()
    bot_status = serializers.SerializerMethodField()

    class Meta:
        model = File
        fields = ['id', 'name', 'content', 'size_kb', 'bot_status', 'updated_at']
        read_only_fields = ['id', 'name', 'size_kb', 'bot_status', 'updated_at']

    def get_content(self, obj):
        return obj.read_content()

    def get_bot_status(self, obj):
        processes = list(obj.processes.all())
        return processes[0].status if processes else 'stopped'
