from django.urls import path
from .views import (
    FileTreeView, FolderCreateView, FileUploadView, FileCreateEmptyView,
    FileContentView, FileRenameView, FileDeleteView, FolderDeleteView
)

urlpatterns = [
    path('tree/', FileTreeView.as_view(), name='file_tree'),
    path('folder/', FolderCreateView.as_view(), name='folder_create'),
    path('folder/<int:pk>/', FolderDeleteView.as_view(), name='folder_delete'),
    path('upload/', FileUploadView.as_view(), name='file_upload'),
    path('create/', FileCreateEmptyView.as_view(), name='file_create'),
    path('<int:pk>/content/', FileContentView.as_view(), name='file_content'),
    path('<int:pk>/rename/', FileRenameView.as_view(), name='file_rename'),
    path('<int:pk>/', FileDeleteView.as_view(), name='file_delete'),
]
