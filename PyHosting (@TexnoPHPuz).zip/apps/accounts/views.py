import requests
from django.conf import settings
from django.shortcuts import render
from django.views.generic import View
from rest_framework import generics, status, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django.contrib.auth import get_user_model
from .serializers import (
    RegisterSerializer, UserProfileSerializer,
    ChangePasswordSerializer, HostingSettingsSerializer
)
from .throttles import AuthRateThrottle, BruteForceProtector

User = get_user_model()

class AuthPageView(View):
    """
    Renders auth.html template with server-provided security and auth settings.
    """
    def get(self, request):
        from apps.adminpanel.models import SystemSetting
        settings_obj = SystemSetting.get_settings()
        turnstile_enabled = bool(settings_obj.turnstile_enabled and settings_obj.turnstile_site_key)
        path = request.path
        is_confirm_email = 'confirm-email' in path
        return render(request, 'auth.html', {
            'turnstile_enabled': turnstile_enabled,
            'turnstile_site_key': settings_obj.turnstile_site_key if turnstile_enabled else '',
            'google_client_id': settings_obj.google_client_id or getattr(settings, 'GOOGLE_CLIENT_ID', ''),
            'activate_uid': request.GET.get('uid', ''),
            'activate_token': request.GET.get('token', '') if not is_confirm_email else '',
            'confirm_email_token': request.GET.get('token', '') if is_confirm_email else '',
        })

class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self, attrs):
        username_or_email = attrs.get('username', '').strip()
        if '@' in username_or_email:
            user = User.objects.filter(email__iexact=username_or_email).first()
        else:
            user = User.objects.filter(username__iexact=username_or_email).first()

        if user:
            attrs['username'] = user.username
            if user.check_password(attrs.get('password')) and not user.is_active:
                from rest_framework import serializers as drf_serializers
                raise drf_serializers.ValidationError({
                    'detail': f"Hisobingiz hali faollashtirilmagan. Iltimos, '{user.email}' pochtangizga yuborilgan havola orqali akkauntni tasdiqlang.",
                    'not_activated': True,
                    'email': user.email,
                    'username': user.username
                })

        data = super().validate(attrs)
        if hasattr(self.user, 'quota'):
            self.user.quota.recalculate_usage()

        data['user'] = UserProfileSerializer(self.user).data
        return data

def verify_turnstile(token, ip=None):
    from apps.adminpanel.models import SystemSetting
    settings_obj = SystemSetting.get_settings()
    if not settings_obj.turnstile_enabled:
        return True, None

    if not settings_obj.turnstile_secret_key:
        return True, None

    if not token:
        return False, "Iltimos, CAPTCHA xavfsizlik tekshiruvidan o'ting."

    try:
        res = requests.post(
            "https://challenges.cloudflare.com/turnstile/v0/siteverify",
            data={
                "secret": settings_obj.turnstile_secret_key,
                "response": token,
                "remoteip": ip or ""
            },
            timeout=5
        )
        if res.status_code == 200:
            result = res.json()
            if result.get("success"):
                return True, None
            return False, "CAPTCHA tasdiqlanmadi yoki muddati o'tgan. Iltimos qaytadan urinib ko'ring."
        return False, "CAPTCHA tekshirishda xatolik yuz berdi."
    except Exception:
        return False, "CAPTCHA serveriga ulanishda xatolik yuz berdi."

class TurnstileConfigView(APIView):
    """
    Returns public Turnstile configuration for frontend widget rendering.
    """
    authentication_classes = []
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        from apps.adminpanel.models import SystemSetting
        settings_obj = SystemSetting.get_settings()
        is_enabled = bool(settings_obj.turnstile_enabled and settings_obj.turnstile_site_key)
        return Response({
            "enabled": is_enabled,
            "site_key": settings_obj.turnstile_site_key if is_enabled else ""
        })

class LoginView(TokenObtainPairView):
    permission_classes = [permissions.AllowAny]
    serializer_class = CustomTokenObtainPairSerializer
    throttle_classes = [AuthRateThrottle]

    def post(self, request, *args, **kwargs):
        ip = request.META.get('HTTP_X_FORWARDED_FOR', request.META.get('REMOTE_ADDR', '')).split(',')[0].strip()
        username = request.data.get('username', '')

        turnstile_token = request.data.get('turnstile_token') or request.data.get('cf-turnstile-response')
        is_valid, err_msg = verify_turnstile(turnstile_token, ip)
        if not is_valid:
            return Response({'error': err_msg, 'detail': err_msg}, status=status.HTTP_400_BAD_REQUEST)

        if BruteForceProtector.is_locked_out(ip, username):
            return Response({
                'detail': "Xavfsizlik tizimi: Ko'p marotaba xato parol kiritilgani sababli ushbu hisob 15 daqiqaga vaqtincha bloklandi. Iltimos, keyinroq urinib ko'ring."
            }, status=status.HTTP_429_TOO_MANY_REQUESTS)

        try:
            response = super().post(request, *args, **kwargs)
            if response.status_code == 200:
                BruteForceProtector.record_success(ip, username)
            return response
        except Exception as exc:
            from rest_framework.exceptions import ValidationError as DRFValidationError
            if isinstance(exc, DRFValidationError) and isinstance(exc.detail, dict) and 'not_activated' in exc.detail:
                detail_dict = exc.detail
                email_val = detail_dict.get('email')
                if isinstance(email_val, list):
                    email_val = email_val[0]
                msg_val = detail_dict.get('detail')
                if isinstance(msg_val, list):
                    msg_val = msg_val[0]
                return Response({
                    'detail': str(msg_val),
                    'not_activated': True,
                    'email': str(email_val)
                }, status=status.HTTP_400_BAD_REQUEST)

            attempts = BruteForceProtector.record_failure(ip, username)
            if attempts >= BruteForceProtector.MAX_ATTEMPTS:
                return Response({
                    'detail': "Xavfsizlik tizimi: Ketma-ket 5 marta xato parol kiritildi. Hisob 15 daqiqaga bloklandi."
                }, status=status.HTTP_429_TOO_MANY_REQUESTS)
            raise exc

class RegisterView(generics.CreateAPIView):
    permission_classes = [permissions.AllowAny]
    serializer_class = RegisterSerializer
    throttle_classes = [AuthRateThrottle]

    def create(self, request, *args, **kwargs):
        from apps.adminpanel.models import SystemSetting
        settings_obj = SystemSetting.get_settings()
        if not settings_obj.registration_enabled:
            return Response({
                "detail": "Hozirda serverda yangi foydalanuvchilar ro'yxatdan o'tishi vaqtincha to'xtatilgan."
            }, status=status.HTTP_403_FORBIDDEN)

        ip = request.META.get('HTTP_X_FORWARDED_FOR', request.META.get('REMOTE_ADDR', '')).split(',')[0].strip()
        turnstile_token = request.data.get('turnstile_token') or request.data.get('cf-turnstile-response')
        is_valid, err_msg = verify_turnstile(turnstile_token, ip)
        if not is_valid:
            return Response({'error': err_msg, 'detail': err_msg}, status=status.HTTP_400_BAD_REQUEST)

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        user_data = UserProfileSerializer(user).data

        from .services import send_activation_email
        require_activation = not user.is_active

        if require_activation:
            send_activation_email(user, request=request)
            return Response({
                'user': user_data,
                'require_activation': True,
                'email': user.email,
                'message': f"Ro'yxatdan muvaffaqiyatli o'tdingiz! '{user.email}' pochtangizga faollashtirish havolasi yuborildi."
            }, status=status.HTTP_201_CREATED)
        else:
            tokens = serializer.get_tokens(user)
            return Response({
                'user': user_data,
                'tokens': tokens,
                'require_activation': False,
                'message': "Ro'yxatdan muvaffaqiyatli o'tdingiz!"
            }, status=status.HTTP_201_CREATED)

class ActivateAccountView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        uid = request.query_params.get('uid') or request.GET.get('uid')
        token = request.query_params.get('token') or request.GET.get('token')
        return self._process_activation(uid, token)

    def post(self, request):
        uid = request.data.get('uid')
        token = request.data.get('token')
        return self._process_activation(uid, token)

    def _process_activation(self, uid, token):
        from .services import verify_activation_token
        is_valid, user, message = verify_activation_token(uid, token)

        if is_valid and user:
            from rest_framework_simplejwt.tokens import RefreshToken
            refresh = RefreshToken.for_user(user)
            tokens = {
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            }
            return Response({
                'success': True,
                'message': message,
                'tokens': tokens,
                'user': UserProfileSerializer(user).data
            }, status=status.HTTP_200_OK)
        else:
            return Response({
                'success': False,
                'message': message,
                'email': user.email if user else None
            }, status=status.HTTP_400_BAD_REQUEST)

class ResendActivationEmailView(APIView):
    permission_classes = [permissions.AllowAny]
    throttle_classes = [AuthRateThrottle]

    def post(self, request):
        email_or_username = request.data.get('email') or request.data.get('username') or ''
        email_or_username = email_or_username.strip()

        if not email_or_username:
            return Response({
                'error': "Pochta manzili yoki username kiritilishi shart."
            }, status=status.HTTP_400_BAD_REQUEST)

        if '@' in email_or_username:
            user = User.objects.filter(email__iexact=email_or_username).first()
        else:
            user = User.objects.filter(username__iexact=email_or_username).first()

        if not user:
            return Response({
                'message': "Agar ushbu pochta ro'yxatdan o'tgan bo'lsa, yangi faollashtirish havolasi yuborildi."
            }, status=status.HTTP_200_OK)

        if user.is_active:
            return Response({
                'message': "Ushbu hisob allaqachon faollashtirilgan. Tizimga kirishingiz mumkin.",
                'already_active': True
            }, status=status.HTTP_200_OK)

        from .services import send_activation_email
        send_activation_email(user, request=request)

        return Response({
            'message': f"Yangi faollashtirish havolasi '{user.email}' pochtangizga yuborildi. Iltimos, pochtangizni tekshiring.",
            'email': user.email
        }, status=status.HTTP_200_OK)

class ProfileView(generics.RetrieveUpdateAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = UserProfileSerializer

    def get_object(self):
        user = self.request.user
        if hasattr(user, 'quota'):
            user.quota.recalculate_usage()
        return user

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()

        if 'email' in request.data:
            new_email = (request.data.get('email') or '').strip().lower()
            if not new_email:
                return Response({'email': ["Elektron pochta manzili bo'sh bo'lishi mumkin emas."]}, status=status.HTTP_400_BAD_REQUEST)

            if '@' not in new_email or '.' not in new_email.split('@')[-1]:
                return Response({'email': ["Elektron pochta formati noto'g'ri."]}, status=status.HTTP_400_BAD_REQUEST)

            if new_email == instance.email.lower():
                serializer = self.get_serializer(instance)
                return Response(serializer.data)

            if User.objects.exclude(pk=instance.pk).filter(email__iexact=new_email).exists():
                return Response({'email': ["Bu elektron pochta allaqachon boshqa foydalanuvchi tomonidan band qilingan."]}, status=status.HTTP_400_BAD_REQUEST)

            from apps.adminpanel.models import SystemSetting
            settings_obj = SystemSetting.get_settings()
            req_verify = getattr(settings_obj, 'email_verification_required', True)

            if req_verify:
                from .services import send_email_change_verification
                send_email_change_verification(instance, new_email, request=request)

                data_copy = request.data.copy()
                data_copy.pop('email', None)

                if data_copy:
                    serializer = self.get_serializer(instance, data=data_copy, partial=partial)
                    serializer.is_valid(raise_exception=True)
                    self.perform_update(serializer)
                    resp_data = serializer.data
                else:
                    resp_data = self.get_serializer(instance).data

                resp_data['email_change_pending'] = True
                resp_data['pending_email'] = new_email
                resp_data['message'] = f"Tasdiqlash havolasi '{new_email}' pochtangizga yuborildi. Iltimos, yangi pochtangizga kirib, havolani tasdiqlang."
                return Response(resp_data, status=status.HTTP_200_OK)

        return super().update(request, *args, partial=partial, **kwargs)

class ConfirmEmailChangeView(APIView):
    """
    Validates token and confirms email address change.
    Supports both GET (for direct clicks) and POST (from frontend AJAX).
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        token = request.query_params.get('token') or request.GET.get('token')
        return self._process_confirm(request, token)

    def post(self, request):
        token = request.data.get('token')
        return self._process_confirm(request, token)

    def _process_confirm(self, request, token):
        from .services import verify_email_change_token
        success, user, new_email, message = verify_email_change_token(token)

        if success and user:
            return Response({
                'success': True,
                'message': message,
                'email': new_email,
                'user': UserProfileSerializer(user).data
            }, status=status.HTTP_200_OK)
        else:
            return Response({
                'success': False,
                'message': message,
                'email': new_email
            }, status=status.HTTP_400_BAD_REQUEST)

class CheckAvailabilityView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        username = request.query_params.get('username', '').strip()
        email = request.query_params.get('email', '').strip()

        resp = {}
        if username:
            resp['username_available'] = not User.objects.filter(username__iexact=username).exists()
        if email:
            resp['email_available'] = not User.objects.filter(email__iexact=email).exists()

        return Response(resp)

class ChangePasswordView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    throttle_classes = [AuthRateThrottle]

    def post(self, request):
        serializer = ChangePasswordSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        user = request.user
        if not user.check_password(serializer.validated_data['old_password']):
            return Response({'old_password': ["Eski parol noto'g'ri kiritildi."]}, status=status.HTTP_400_BAD_REQUEST)

        user.set_password(serializer.validated_data['new_password'])
        user.save()
        return Response({'message': "Parolingiz muvaffaqiyatli o'zgartirildi!"}, status=status.HTTP_200_OK)

class HostingSettingsView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        quota = request.user.quota
        serializer = HostingSettingsSerializer(quota)
        return Response(serializer.data)

    def patch(self, request):
        quota = request.user.quota
        serializer = HostingSettingsSerializer(quota, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({
                'settings': serializer.data,
                'message': "Hosting sozlamalari muvaffaqiyatli saqlandi!"
            }, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

import re
import json
import random
import requests
from django.conf import settings
from django.shortcuts import redirect
from django.http import HttpResponse
from rest_framework_simplejwt.tokens import RefreshToken

class GoogleConfigView(APIView):
    """
    Returns public Google OAuth Client ID for frontend initialization.
    """
    authentication_classes = []
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        from apps.adminpanel.models import SystemSetting
        settings_obj = SystemSetting.get_settings()
        client_id = settings_obj.google_client_id or getattr(settings, 'GOOGLE_CLIENT_ID', '')
        return Response({
            "client_id": client_id,
            "configured": bool(client_id)
        })

class GoogleAuthView(APIView):
    """
    Handles Google OAuth2 registration and login using authorization code, credential / ID token, or access token.
    """
    permission_classes = [permissions.AllowAny]
    throttle_classes = [AuthRateThrottle]

    @classmethod
    def get_or_create_google_user(cls, idinfo, settings_obj):
        email = idinfo.get('email')
        google_sub = str(idinfo.get('sub'))
        picture = idinfo.get('picture', '')
        name = idinfo.get('name', '')

        user = User.objects.filter(google_id=google_sub).first()
        if not user:
            user = User.objects.filter(email__iexact=email).first()
            if user:
                user.google_id = google_sub
                if picture and not user.avatar_url:
                    user.avatar_url = picture
                user.save(update_fields=['google_id', 'avatar_url'])
            else:
                if not settings_obj.registration_enabled:
                    return None, "Hozirda yangi foydalanuvchilar ro'yxatdan o'tishi vaqtincha to'xtatilgan."

                base_username = re.sub(r'[^a-z0-9_]', '', email.split('@')[0].lower())
                if len(base_username) < 3:
                    base_username = "user"
                username = base_username
                counter = 1
                while User.objects.filter(username__iexact=username).exists():
                    username = f"{base_username}_{random.randint(100, 9999)}"
                    counter += 1
                    if counter > 30:
                        username = f"user_{random.randint(10000, 99999)}"
                        break

                user = User.objects.create(
                    username=username,
                    email=email,
                    google_id=google_sub,
                    avatar_url=picture,
                    first_name=name[:30]
                )
                user.set_unusable_password()
                user.save()

        return user, None

    def post(self, request):
        code = request.data.get('code')
        redirect_uri = request.data.get('redirect_uri')
        token = request.data.get('credential') or request.data.get('id_token')
        access_token = request.data.get('access_token')

        if not token and not access_token and not code:
            return Response(
                {"error": "Google token (code, credential yoki access_token) kiritilmadi."},
                status=status.HTTP_400_BAD_REQUEST
            )

        from apps.adminpanel.models import SystemSetting
        settings_obj = SystemSetting.get_settings()
        client_id = settings_obj.google_client_id or getattr(settings, 'GOOGLE_CLIENT_ID', '')
        client_secret = settings_obj.google_client_secret or getattr(settings, 'GOOGLE_CLIENT_SECRET', '')

        if code:
            if not redirect_uri:
                redirect_uri = request.build_absolute_uri('/auth/').split('?')[0]
            try:
                token_res = requests.post(
                    "https://oauth2.googleapis.com/token",
                    data={
                        "code": code,
                        "client_id": client_id,
                        "client_secret": client_secret,
                        "redirect_uri": redirect_uri,
                        "grant_type": "authorization_code"
                    },
                    timeout=8
                )
                if token_res.status_code == 200:
                    token_data = token_res.json()
                    access_token = token_data.get('access_token')
                    token = token_data.get('id_token')
                else:
                    return Response(
                        {"error": f"Google kodi tekshirilmadi: {token_res.text}"},
                        status=status.HTTP_400_BAD_REQUEST
                    )
            except Exception as e:
                return Response(
                    {"error": f"Google serveriga ulanishda xatolik: {str(e)}"},
                    status=status.HTTP_400_BAD_REQUEST
                )

        idinfo = None

        if access_token:
            try:
                verify_res = requests.get(
                    "https://www.googleapis.com/oauth2/v3/userinfo",
                    headers={"Authorization": f"Bearer {access_token}"},
                    timeout=5
                )
                if verify_res.status_code == 200:
                    idinfo = verify_res.json()
            except Exception:
                pass

        if not idinfo and token:
            try:
                from google.oauth2 import id_token
                from google.auth.transport import requests as google_requests
                if client_id:
                    idinfo = id_token.verify_oauth2_token(token, google_requests.Request(), client_id)
                else:
                    idinfo = id_token.verify_oauth2_token(token, google_requests.Request())
            except Exception:
                try:
                    verify_res = requests.get(f"https://oauth2.googleapis.com/tokeninfo?id_token={token}", timeout=5)
                    if verify_res.status_code == 200:
                        idinfo = verify_res.json()
                except Exception:
                    pass

        if not idinfo:
            return Response(
                {"error": "Google tokeni yaroqsiz yoki muddati o'tgan."},
                status=status.HTTP_400_BAD_REQUEST
            )

        email = idinfo.get('email')
        email_verified = idinfo.get('email_verified', False)
        if isinstance(email_verified, str):
            email_verified = email_verified.lower() == 'true'

        if not email or not email_verified:
            return Response(
                {"error": "Google hisobidagi elektron pochta tasdiqlanmagan."},
                status=status.HTTP_400_BAD_REQUEST
            )

        user, err_msg = self.get_or_create_google_user(idinfo, settings_obj)
        if err_msg:
            return Response({"error": err_msg}, status=status.HTTP_403_FORBIDDEN)

        if not user.is_active:
            return Response(
                {"error": "Ushbu hisob ma'muriyat tomonidan bloklangan."},
                status=status.HTTP_403_FORBIDDEN
            )

        if hasattr(user, 'quota'):
            user.quota.recalculate_usage()

        refresh = RefreshToken.for_user(user)
        return Response({
            "message": f"Xush kelibsiz, {user.username}!",
            "tokens": {
                "access": str(refresh.access_token),
                "refresh": str(refresh)
            },
            "user": UserProfileSerializer(user).data
        }, status=status.HTTP_200_OK)

class GoogleCallbackView(APIView):
    """
    Direct server-side OAuth2 redirect callback handler.
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        code = request.GET.get('code')
        error = request.GET.get('error')
        if error or not code:
            return redirect(f"/auth/?error={error or 'cancelled'}")

        from apps.adminpanel.models import SystemSetting
        settings_obj = SystemSetting.get_settings()
        client_id = settings_obj.google_client_id or getattr(settings, 'GOOGLE_CLIENT_ID', '')
        client_secret = settings_obj.google_client_secret or getattr(settings, 'GOOGLE_CLIENT_SECRET', '')

        redirect_uri = request.build_absolute_uri('/api/auth/google/callback/').split('?')[0]

        try:
            token_res = requests.post(
                "https://oauth2.googleapis.com/token",
                data={
                    "code": code,
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "redirect_uri": redirect_uri,
                    "grant_type": "authorization_code"
                },
                timeout=8
            )
            if token_res.status_code == 200:
                token_data = token_res.json()
                acc_token = token_data.get('access_token')
                userinfo_res = requests.get(
                    "https://www.googleapis.com/oauth2/v3/userinfo",
                    headers={"Authorization": f"Bearer {acc_token}"},
                    timeout=5
                )
                if userinfo_res.status_code == 200:
                    idinfo = userinfo_res.json()
                    user, err_msg = GoogleAuthView.get_or_create_google_user(idinfo, settings_obj)
                    if user and user.is_active:
                        refresh = RefreshToken.for_user(user)
                        access = str(refresh.access_token)
                        user_data = json.dumps(UserProfileSerializer(user).data)
                        html_content = f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>Kirilmoqda...</title></head><body style="background:#0d1117;color:#c9d1d9;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;"><div style="text-align:center;"><p style="font-size:16px;">Tizimga muvaffaqiyatli kirildi! Dashboard ochilmoqda...</p><script>localStorage.setItem('pyh_access_token', '{access}');localStorage.setItem('pyh_refresh_token', '{str(refresh)}');localStorage.setItem('pyh_user', JSON.stringify({user_data}));window.location.href = '/app/';</script></div></body></html>"""
                        return HttpResponse(html_content, content_type="text/html")
        except Exception:
            pass

        return redirect("/auth/?error=oauth_failed")

