from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import (
    RegisterView, LoginView, ProfileView, CheckAvailabilityView,
    ChangePasswordView, HostingSettingsView, GoogleAuthView, GoogleConfigView,
    GoogleCallbackView, TurnstileConfigView, ActivateAccountView, ResendActivationEmailView,
    ConfirmEmailChangeView
)

urlpatterns = [
    path('register/', RegisterView.as_view(), name='auth_register'),
    path('login/', LoginView.as_view(), name='auth_login'),
    path('refresh/', TokenRefreshView.as_view(), name='auth_refresh'),
    path('activate/', ActivateAccountView.as_view(), name='auth_activate'),
    path('resend-activation/', ResendActivationEmailView.as_view(), name='auth_resend_activation'),
    path('confirm-email-change/', ConfirmEmailChangeView.as_view(), name='auth_confirm_email_change'),
    path('profile/', ProfileView.as_view(), name='auth_profile'),
    path('change-password/', ChangePasswordView.as_view(), name='auth_change_password'),
    path('hosting-settings/', HostingSettingsView.as_view(), name='auth_hosting_settings'),
    path('check/', CheckAvailabilityView.as_view(), name='auth_check'),
    path('google/', GoogleAuthView.as_view(), name='auth_google'),
    path('google/config/', GoogleConfigView.as_view(), name='auth_google_config'),
    path('google/callback/', GoogleCallbackView.as_view(), name='auth_google_callback'),
    path('turnstile/config/', TurnstileConfigView.as_view(), name='auth_turnstile_config'),
]
