from rest_framework import serializers
from rest_framework_simplejwt.tokens import RefreshToken
from .models import User, UserQuota

class UserQuotaSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserQuota
        fields = [
            'max_disk_mb', 'used_disk_mb', 'max_running_bots', 'max_cpu', 'max_ram_mb',
            'python_version', 'default_auto_restart', 'max_restart_attempts',
            'auto_scroll_logs', 'log_buffer_limit'
        ]
        read_only_fields = ['max_disk_mb', 'used_disk_mb', 'max_running_bots', 'max_cpu', 'max_ram_mb']

class HostingSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserQuota
        fields = [
            'python_version', 'default_auto_restart', 'max_restart_attempts',
            'auto_scroll_logs', 'log_buffer_limit',
            'max_disk_mb', 'used_disk_mb', 'max_running_bots', 'max_cpu', 'max_ram_mb'
        ]
        read_only_fields = ['max_disk_mb', 'used_disk_mb', 'max_running_bots', 'max_cpu', 'max_ram_mb']

import re

def validate_password_strength(password: str):
    if len(password) < 8:
        raise serializers.ValidationError("Parol kamida 8 ta belgidan iborat bo'lishi kerak.")
    if password.isdigit():
        raise serializers.ValidationError("Parol faqat raqamlardan iborat bo'lishi mumkin emas.")
    if not re.search(r'[A-Za-z]', password) or not re.search(r'\d', password):
        raise serializers.ValidationError("Parolda kamida bitta harf va bitta raqam bo'lishi shart.")

class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True, min_length=8)
    new_password_confirm = serializers.CharField(required=True, min_length=8)

    def validate(self, attrs):
        if attrs['new_password'] != attrs['new_password_confirm']:
            raise serializers.ValidationError({"new_password_confirm": "Yangi parollar bir-biriga mos kelmadi."})
        if attrs['old_password'] == attrs['new_password']:
            raise serializers.ValidationError({"new_password": "Yangi parol eski paroldan farq qilishi kerak."})
        validate_password_strength(attrs['new_password'])
        return attrs

class UserProfileSerializer(serializers.ModelSerializer):
    quota = UserQuotaSerializer(read_only=True)

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'avatar_url', 'date_joined', 'quota']
        read_only_fields = ['id', 'username', 'date_joined']

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8)
    password_confirm = serializers.CharField(write_only=True, min_length=8)
    tokens = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'password', 'password_confirm', 'tokens']
        extra_kwargs = {
            'email': {'required': True}
        }

    def validate_username(self, value):
        if User.objects.filter(username__iexact=value).exists():
            raise serializers.ValidationError("Bu nomdagi foydalanuvchi allaqachon mavjud.")
        if len(value) < 3:
            raise serializers.ValidationError("Foydalanuvchi nomi kamida 3 ta belgidan iborat bo'lishi kerak.")
        return value

    def validate_email(self, value):
        if User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError("Bu elektron pochta bilan ro'yxatdan o'tilgan.")
        return value

    def validate(self, attrs):
        if attrs.get('password') != attrs.get('password_confirm'):
            raise serializers.ValidationError({"password_confirm": "Parollar bir xil emas."})
        validate_password_strength(attrs.get('password', ''))
        return attrs

    def create(self, validated_data):
        from apps.adminpanel.models import SystemSetting
        settings_obj = SystemSetting.get_settings()
        req_verify = getattr(settings_obj, 'email_verification_required', True)

        validated_data.pop('password_confirm')
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password'],
            is_active=not req_verify
        )
        return user

    def get_tokens(self, obj):
        if not obj.is_active:
            return None
        refresh = RefreshToken.for_user(obj)
        return {
            'refresh': str(refresh),
            'access': str(refresh.access_token),
        }
