from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, UserQuota

class UserQuotaInline(admin.StackedInline):
    model = UserQuota
    can_delete = False
    verbose_name_plural = "Foydalanuvchi kvotasi va sozlamalari"
    fk_name = 'user'
    fields = (
        ('max_disk_mb', 'used_disk_mb'),
        ('max_running_bots', 'max_cpu', 'max_ram_mb'),
        ('python_version', 'default_auto_restart', 'max_restart_attempts'),
        ('auto_scroll_logs', 'log_buffer_limit'),
    )
    readonly_fields = ('used_disk_mb',)

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    inlines = (UserQuotaInline,)
    list_display = ('username', 'email', 'is_staff', 'is_active', 'get_disk_usage', 'get_running_bots', 'date_joined')
    list_filter = ('is_staff', 'is_superuser', 'is_active', 'date_joined')
    search_fields = ('username', 'email', 'first_name', 'last_name')
    ordering = ('-date_joined',)

    def get_disk_usage(self, obj):
        if hasattr(obj, 'quota'):
            return f"{obj.quota.used_disk_mb:.2f} / {obj.quota.max_disk_mb} MB"
        return "—"
    get_disk_usage.short_description = "Disk (ishlatilgan/jami)"

    def get_running_bots(self, obj):
        if hasattr(obj, 'bot_processes'):
            return obj.bot_processes.filter(status='running').count()
        return 0
    get_running_bots.short_description = "Faol botlar"

@admin.register(UserQuota)
class UserQuotaAdmin(admin.ModelAdmin):
    list_display = ('user', 'used_disk_mb', 'max_disk_mb', 'max_running_bots', 'max_ram_mb', 'python_version')
    list_filter = ('python_version', 'default_auto_restart')
    search_fields = ('user__username', 'user__email')
    readonly_fields = ('used_disk_mb',)
