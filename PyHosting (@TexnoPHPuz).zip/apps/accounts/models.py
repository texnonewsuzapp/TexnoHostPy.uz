from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    email = models.EmailField(unique=True)
    google_id = models.CharField(max_length=255, blank=True, null=True, unique=True, verbose_name="Google ID")
    avatar_url = models.URLField(max_length=500, blank=True, null=True, verbose_name="Avatar URL")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.username

class UserQuota(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='quota')
    max_disk_mb = models.FloatField(default=25.0, help_text="Maksimal disk kvotasi (MB)")
    used_disk_mb = models.FloatField(default=0.0, help_text="Ishlatilgan disk hajmi (MB)")
    max_running_bots = models.IntegerField(default=1, help_text="Maksimal ishlayotgan botlar soni")
    max_cpu = models.FloatField(default=0.5, help_text="Maksimal CPU yadrolari")
    max_ram_mb = models.IntegerField(default=180, help_text="Maksimal RAM hajmi (MB)")
    python_version = models.CharField(max_length=10, default="3.12", help_text="Standart Python versiyasi")
    default_auto_restart = models.BooleanField(default=True, help_text="Standart auto-restart holati")
    max_restart_attempts = models.IntegerField(default=5, help_text="Maksimal qayta urinishlar soni")
    auto_scroll_logs = models.BooleanField(default=True, help_text="Terminalda avtomatik pastga tushish")
    log_buffer_limit = models.IntegerField(default=100, help_text="Xotirada saqlanadigan log satrlari soni")

    def __str__(self):
        return f"{self.user.username} - {self.used_disk_mb:.2f}/{self.max_disk_mb} MB"

    def recalculate_usage(self):
        from apps.filemanager.models import File
        total_kb = File.objects.filter(owner=self.user).aggregate(
            total=models.Sum('size_kb')
        )['total'] or 0.0
        self.used_disk_mb = round(total_kb / 1024.0, 5) if total_kb > 0 else 0.0
        self.save(update_fields=['used_disk_mb'])
        return self.used_disk_mb

    def has_disk_space(self, additional_mb=0.0):
        return (self.used_disk_mb + additional_mb) <= self.max_disk_mb

    def can_run_bot(self):
        from apps.botengine.models import BotProcess
        running_count = BotProcess.objects.filter(owner=self.user, status='running').count()
        return running_count < self.max_running_bots
