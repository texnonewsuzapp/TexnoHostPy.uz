from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status

User = get_user_model()

class AccountsAPITest(TestCase):
    def setUp(self):
        self.client = APIClient()

    def test_register_creates_user_and_quota(self):
        payload = {
            'username': 'devuser',
            'email': 'devuser@example.com',
            'password': 'StrongPassword123!',
            'password_confirm': 'StrongPassword123!'
        }
        res = self.client.post('/api/auth/register/', payload)
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)
        self.assertIn('tokens', res.data)
        self.assertIn('access', res.data['tokens'])

        user = User.objects.get(username='devuser')
        self.assertTrue(hasattr(user, 'quota'))
        self.assertEqual(user.quota.max_disk_mb, 50.0)
        self.assertEqual(user.quota.max_running_bots, 2)

    def test_login_jwt(self):
        user = User.objects.create_user(username='testbotuser', email='bot@example.com', password='secretpassword')
        res = self.client.post('/api/auth/login/', {'username': 'testbotuser', 'password': 'secretpassword'})
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertIn('access', res.data)
        self.assertIn('refresh', res.data)

    def test_profile_requires_auth(self):
        res = self.client.get('/api/auth/profile/')
        self.assertEqual(res.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_google_config_endpoint(self):
        res = self.client.get('/api/auth/google/config/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertIn('client_id', res.data)
        self.assertIn('configured', res.data)

    def test_google_auth_missing_token(self):
        res = self.client.post('/api/auth/google/', {})
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('error', res.data)

    def test_turnstile_config_endpoint(self):
        res = self.client.get('/api/auth/turnstile/config/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertIn('enabled', res.data)
        self.assertIn('site_key', res.data)

    def test_turnstile_blocks_login_when_missing_token(self):
        from apps.adminpanel.models import SystemSetting
        settings_obj = SystemSetting.get_settings()
        settings_obj.turnstile_enabled = True
        settings_obj.turnstile_site_key = '0x4AAAAAA...'
        settings_obj.turnstile_secret_key = '0x4AAAAAA...'
        settings_obj.save()

        User.objects.create_user(username='captchauser', email='c@example.com', password='secretpassword')
        res = self.client.post('/api/auth/login/', {'username': 'captchauser', 'password': 'secretpassword'})
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('CAPTCHA', res.data.get('error', ''))

        settings_obj.turnstile_enabled = False
        settings_obj.save()

