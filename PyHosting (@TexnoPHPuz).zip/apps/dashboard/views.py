from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions
from django.utils import timezone
from apps.filemanager.models import File
from apps.botengine.models import BotProcess

class DashboardStatsView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        quota = user.quota
        quota.recalculate_usage()

        running_bots = BotProcess.objects.filter(owner=user, status='running').count()
        total_bots = BotProcess.objects.filter(owner=user).count()
        total_files = File.objects.filter(owner=user).count()

        recent_processes = BotProcess.objects.filter(owner=user).select_related('file').order_by('-updated_at')[:8]
        recent_activity = []
        for p in recent_processes:
            action_text = "To'xtatildi"
            if p.status == 'running':
                action_text = "Ishga tushirildi"
            elif p.status == 'crashed':
                action_text = "Xatolik bilan to'xtadi"
            elif p.status == 'starting':
                action_text = "Ishga tushirilmoqda"

            recent_activity.append({
                'id': p.id,
                'file_id': p.file.id,
                'file_name': p.file.name,
                'status': p.status,
                'action_text': action_text,
                'updated_at': p.updated_at.isoformat(),
                'last_error': p.last_error or None
            })

        return Response({
            'used_disk_mb': quota.used_disk_mb,
            'max_disk_mb': quota.max_disk_mb,
            'disk_percent': round((quota.used_disk_mb / quota.max_disk_mb) * 100, 1) if quota.max_disk_mb > 0 else 0,
            'running_bots': running_bots,
            'max_running_bots': quota.max_running_bots,
            'total_bots': total_bots,
            'total_files': total_files,
            'max_cpu': quota.max_cpu,
            'max_ram_mb': quota.max_ram_mb,
            'recent_activity': recent_activity
        })
