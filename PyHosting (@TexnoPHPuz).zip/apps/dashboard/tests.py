from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status
from apps.filemanager.models import File
from apps.botengine.models import BotProcess

User = get_user_model()

class DashboardAPITest(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(username='dashuser', email='dash@example.com', password='password123')
        self.client.force_authenticate(user=self.user)

        self.file = File.objects.create(owner=self.user, name='test_bot.py', extension='.py')
        self.file.write_content("print('hello')\n")

    def test_dashboard_stats(self):
        res = self.client.get('/api/dashboard/stats/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertIn('used_disk_mb', res.data)
        self.assertIn('max_disk_mb', res.data)
        self.assertIn('running_bots', res.data)
        self.assertIn('total_files', res.data)
        self.assertEqual(res.data['total_files'], 1)
