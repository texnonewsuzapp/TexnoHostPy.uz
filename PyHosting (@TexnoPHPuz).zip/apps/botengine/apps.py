import os
import sys
from django.apps import AppConfig

class BotengineConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.botengine'

    def ready(self):
        cli_cmds = {'migrate', 'makemigrations', 'collectstatic', 'shell', 'createsuperuser', 'test', 'check'}
        is_cli_task = any(cmd in sys.argv for cmd in cli_cmds)
        if not is_cli_task:
            try:
                from .monitor import start_monitoring_daemon
                start_monitoring_daemon()
            except Exception:
                pass
            try:
                from .startup import run_server_startup_sequence
                run_server_startup_sequence()
            except Exception:
                pass
