from django.urls import path
from .views import (
    BotStartView, BotStopView, BotStatusView, BotLogsView, BotListView,
    BotAutoRestartToggleView, BotEnvVarsView, BotTelemetryView,
    BotPipPackagesView, BotPipInstallView
)

urlpatterns = [
    path('', BotListView.as_view(), name='bot_list'),
    path('<int:file_id>/start/', BotStartView.as_view(), name='bot_start'),
    path('<int:file_id>/stop/', BotStopView.as_view(), name='bot_stop'),
    path('<int:file_id>/status/', BotStatusView.as_view(), name='bot_status'),
    path('<int:file_id>/logs/', BotLogsView.as_view(), name='bot_logs'),
    path('<int:file_id>/auto-restart/', BotAutoRestartToggleView.as_view(), name='bot_auto_restart'),
    path('<int:file_id>/env/', BotEnvVarsView.as_view(), name='bot_env_vars'),
    path('<int:file_id>/env/<str:key>/', BotEnvVarsView.as_view(), name='bot_env_var_delete'),
    path('<int:file_id>/telemetry/', BotTelemetryView.as_view(), name='bot_telemetry'),
    path('pip/', BotPipPackagesView.as_view(), name='bot_pip_packages'),
    path('pip/install/', BotPipInstallView.as_view(), name='bot_pip_install'),
]
