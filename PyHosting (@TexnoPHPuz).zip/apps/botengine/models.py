from django.db import models
from django.conf import settings
from apps.filemanager.models import File

STATUS_CHOICES = (
    ('stopped', 'To\'xtatilgan'),
    ('starting', 'Ishga tushirilmoqda'),
    ('running', 'Ishlayapti'),
    ('crashed', 'Xatolik tufayli to\'xtagan'),
)

class BotProcess(models.Model):
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='bot_processes')
    file = models.ForeignKey(File, on_delete=models.CASCADE, related_name='processes')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='stopped')
    container_id = models.CharField(max_length=128, blank=True, null=True, help_text="Docker konteyner IDsi yoki identifikator")
    pid = models.IntegerField(null=True, blank=True, help_text="Subprocess rejimida ishlayotgan PID")
    started_at = models.DateTimeField(null=True, blank=True)
    stopped_at = models.DateTimeField(null=True, blank=True)
    restart_count = models.IntegerField(default=0, help_text="Crash-loop himoyasi uchun qayta ishga tushish soni")
    auto_restart = models.BooleanField(default=True, help_text="Xatolik yuz berganda avtomatik qayta ishga tushirish")
    env_vars = models.JSONField(default=dict, blank=True, help_text="Atrof-muhit o'zgaruvchilari (.env / Secrets)")
    last_error = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-updated_at']

    def __str__(self):
        return f"{self.owner.username} - {self.file.name} [{self.status}]"

    def get_decrypted_env(self) -> dict:
        """Returns decrypted environment dictionary."""
        from .crypto import decrypt_dict
        if not self.env_vars:
            return {}
        if isinstance(self.env_vars, dict):
            if "_encrypted" in self.env_vars:
                return decrypt_dict(self.env_vars["_encrypted"])
            return self.env_vars
        elif isinstance(self.env_vars, str):
            return decrypt_dict(self.env_vars)
        return {}

    def set_encrypted_env(self, data: dict):
        """Encrypts dictionary using AES-256 Fernet before storing in DB."""
        from .crypto import encrypt_dict
        if not data or not isinstance(data, dict):
            self.env_vars = {}
        else:
            self.env_vars = {"_encrypted": encrypt_dict(data)}

class BotLog(models.Model):
    LEVEL_CHOICES = (
        ('INFO', 'Info'),
        ('WARNING', 'Warning'),
        ('ERROR', 'Error'),
    )
    bot_process = models.ForeignKey(BotProcess, on_delete=models.CASCADE, related_name='logs')
    timestamp = models.DateTimeField(auto_now_add=True)
    level = models.CharField(max_length=10, choices=LEVEL_CHOICES, default='INFO')
    log_line = models.TextField()

    class Meta:
        ordering = ['timestamp']

    def __str__(self):
        return f"[{self.timestamp.strftime('%H:%M:%S')}] [{self.level}] {self.log_line[:60]}"
