from rest_framework import serializers
from .models import BotProcess, BotLog

class BotLogSerializer(serializers.ModelSerializer):
    timestamp_formatted = serializers.SerializerMethodField()

    class Meta:
        model = BotLog
        fields = ['id', 'timestamp', 'timestamp_formatted', 'level', 'log_line']

    def get_timestamp_formatted(self, obj):
        return obj.timestamp.strftime('%H:%M:%S')

class BotProcessSerializer(serializers.ModelSerializer):
    file_id = serializers.IntegerField(source='file.id', read_only=True)
    file_name = serializers.CharField(source='file.name', read_only=True)
    file_path = serializers.SerializerMethodField()

    class Meta:
        model = BotProcess
        fields = [
            'id', 'file_id', 'file_name', 'file_path', 'status',
            'started_at', 'stopped_at', 'restart_count', 'auto_restart', 'env_vars', 'last_error', 'container_id'
        ]

    def get_file_path(self, obj):
        return obj.file.get_relative_path()
