from django.contrib import admin
from .models import BotProcess, BotLog

class BotLogInline(admin.TabularInline):
    model = BotLog
    extra = 0
    can_delete = False
    readonly_fields = ('timestamp', 'level', 'log_line')
    ordering = ('-timestamp',)

    def has_add_permission(self, request, obj=None):
        return False

@admin.register(BotProcess)
class BotProcessAdmin(admin.ModelAdmin):
    list_display = ('file', 'owner', 'status', 'pid', 'restart_count', 'auto_restart', 'started_at', 'stopped_at')
    list_filter = ('status', 'auto_restart', 'created_at')
    search_fields = ('file__name', 'owner__username', 'container_id')
    ordering = ('-updated_at',)
    readonly_fields = ('started_at', 'stopped_at', 'created_at', 'updated_at')
    inlines = (BotLogInline,)

@admin.register(BotLog)
class BotLogAdmin(admin.ModelAdmin):
    list_display = ('timestamp', 'bot_process', 'level', 'short_log')
    list_filter = ('level', 'timestamp')
    search_fields = ('log_line', 'bot_process__file__name', 'bot_process__owner__username')
    ordering = ('-timestamp',)
    readonly_fields = ('timestamp', 'bot_process', 'level', 'log_line')

    def short_log(self, obj):
        return obj.log_line[:80]
    short_log.short_description = "Log xabari"

    def has_add_permission(self, request):
        return False
