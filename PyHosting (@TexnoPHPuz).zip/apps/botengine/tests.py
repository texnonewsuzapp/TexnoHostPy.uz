import time
from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status
from apps.filemanager.models import File
from apps.botengine.models import BotProcess

User = get_user_model()

class BotEngineAPITest(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(username='botrunneruser', email='runner@example.com', password='password123')
        self.client.force_authenticate(user=self.user)

        self.file1 = File.objects.create(owner=self.user, name='bot1.py', extension='.py')
        self.file1.write_content("import time\nprint('Bot 1 is running!')\ntime.sleep(1)\n")

        self.file2 = File.objects.create(owner=self.user, name='bot2.py', extension='.py')
        self.file2.write_content("import time\nprint('Bot 2 is running!')\ntime.sleep(1)\n")

        self.file3 = File.objects.create(owner=self.user, name='bot3.py', extension='.py')
        self.file3.write_content("import time\nprint('Bot 3 is running!')\ntime.sleep(1)\n")

    def test_start_and_stop_bot(self):
        start_res = self.client.post(f'/api/bots/{self.file1.id}/start/')
        self.assertEqual(start_res.status_code, status.HTTP_200_OK)

        proc = BotProcess.objects.get(file=self.file1)
        self.assertIn(proc.status, ['running', 'stopped'])

        stop_res = self.client.post(f'/api/bots/{self.file1.id}/stop/')
        self.assertEqual(stop_res.status_code, status.HTTP_200_OK)
        proc.refresh_from_db()
        self.assertEqual(proc.status, 'stopped')

    def test_max_running_bots_quota_enforced(self):
        self.user.quota.max_running_bots = 1
        self.user.quota.save()

        r1 = self.client.post(f'/api/bots/{self.file1.id}/start/')
        self.assertEqual(r1.status_code, status.HTTP_200_OK)

        proc1 = BotProcess.objects.get(file=self.file1)
        proc1.status = 'running'
        proc1.save()

        r2 = self.client.post(f'/api/bots/{self.file2.id}/start/')
        self.assertEqual(r2.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("1 ta bot ishlashi mumkin", r2.data['error'])

    def test_auto_restart_toggle(self):
        res = self.client.post(f'/api/bots/{self.file1.id}/auto-restart/', {'auto_restart': False}, format='json')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertFalse(res.data['auto_restart'])

        res2 = self.client.post(f'/api/bots/{self.file1.id}/auto-restart/', {'auto_restart': True}, format='json')
        self.assertEqual(res2.status_code, status.HTTP_200_OK)
        self.assertTrue(res2.data['auto_restart'])

    def test_environment_variables_api(self):
        res = self.client.post(f'/api/bots/{self.file1.id}/env/', {
            'env_vars': {'BOT_TOKEN': '123456:ABC-DEF', 'ADMIN_ID': '999888'}
        }, format='json')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(res.data['env_vars']['BOT_TOKEN'], '123456:ABC-DEF')

        get_res = self.client.get(f'/api/bots/{self.file1.id}/env/')
        self.assertEqual(get_res.status_code, status.HTTP_200_OK)
        self.assertEqual(get_res.data['env_vars']['ADMIN_ID'], '999888')

        del_res = self.client.delete(f'/api/bots/{self.file1.id}/env/ADMIN_ID/')
        self.assertEqual(del_res.status_code, status.HTTP_200_OK)

        proc = BotProcess.objects.get(file=self.file1)
        self.assertNotIn('ADMIN_ID', proc.env_vars)

    def test_telemetry_api(self):
        res = self.client.get(f'/api/bots/{self.file1.id}/telemetry/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertIn('cpu_percent', res.data)
        self.assertIn('memory_mb', res.data)
        self.assertIn('max_memory_mb', res.data)

    def test_pip_packages_catalog_api(self):
        res = self.client.get('/api/bots/pip/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertIn('popular', res.data)
        self.assertTrue(len(res.data['popular']) > 0)
        self.assertEqual(res.data['popular'][0]['name'], 'aiogram')
