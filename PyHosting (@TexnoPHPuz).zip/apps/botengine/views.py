from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from django.shortcuts import get_object_or_404
from .models import BotProcess, BotLog
from .serializers import BotProcessSerializer, BotLogSerializer
from .runner import start_bot_process, stop_bot_process
from apps.filemanager.models import File

class BotStartView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, file_id):
        file_obj = get_object_or_404(File, id=file_id, owner=request.user)
        try:
            bot_proc = start_bot_process(file_id, request.user)
            return Response({
                'process': BotProcessSerializer(bot_proc).data,
                'message': f"'{file_obj.name}' muvaffaqiyatli ishga tushirildi!"
            }, status=status.HTTP_200_OK)
        except (ValueError, PermissionError) as ve:
            return Response({'error': str(ve)}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': f"Ishga tushirishda xatolik: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class BotStopView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, file_id):
        file_obj = get_object_or_404(File, id=file_id, owner=request.user)
        proc = BotProcess.objects.filter(file=file_obj, owner=request.user).first()
        if not proc or proc.status == 'stopped':
            return Response({'message': "Bot allaqachon to'xtatilgan.", 'status': 'stopped'})

        stopped_proc = stop_bot_process(proc)
        return Response({
            'process': BotProcessSerializer(stopped_proc).data,
            'message': f"'{file_obj.name}' to'xtatildi."
        }, status=status.HTTP_200_OK)

class BotStatusView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, file_id):
        file_obj = get_object_or_404(File, id=file_id, owner=request.user)
        proc = BotProcess.objects.filter(file=file_obj, owner=request.user).first()
        if not proc:
            return Response({
                'file_id': file_id,
                'file_name': file_obj.name,
                'status': 'stopped',
                'started_at': None,
                'restart_count': 0
            })
        return Response(BotProcessSerializer(proc).data)

class BotLogsView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, file_id):
        file_obj = get_object_or_404(File, id=file_id, owner=request.user)
        proc = BotProcess.objects.filter(file=file_obj, owner=request.user).first()
        if not proc:
            return Response({'logs': []})

        limit = int(request.query_params.get('limit', 100))
        logs = BotLog.objects.filter(bot_process=proc).order_by('-timestamp')[:limit]
        return Response({
            'logs': BotLogSerializer(reversed(list(logs)), many=True).data
        })

class BotListView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        processes = BotProcess.objects.filter(owner=request.user).select_related('file')
        return Response(BotProcessSerializer(processes, many=True).data)

class BotAutoRestartToggleView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, file_id):
        file_obj = get_object_or_404(File, id=file_id, owner=request.user)
        proc, _ = BotProcess.objects.get_or_create(file=file_obj, owner=request.user)
        auto_restart = request.data.get('auto_restart')
        if auto_restart is None:
            proc.auto_restart = not proc.auto_restart
        elif isinstance(auto_restart, bool):
            proc.auto_restart = auto_restart
        elif isinstance(auto_restart, str):
            proc.auto_restart = auto_restart.lower() in ['true', '1', 'yes']
        else:
            proc.auto_restart = bool(auto_restart)
        proc.save(update_fields=['auto_restart'])
        return Response({
            'auto_restart': proc.auto_restart,
            'message': "Avtomatik qayta yoqish faollashtirildi" if proc.auto_restart else "Avtomatik qayta yoqish o'chirildi"
        })

class BotEnvVarsView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, file_id):
        file_obj = get_object_or_404(File, id=file_id, owner=request.user)
        proc, _ = BotProcess.objects.get_or_create(file=file_obj, owner=request.user)
        from .runner import load_folder_env
        folder_env = load_folder_env(file_obj.get_disk_path().parent)
        db_env = proc.get_decrypted_env()
        merged = {**folder_env, **db_env}
        return Response({'env_vars': merged})

    def post(self, request, file_id):
        file_obj = get_object_or_404(File, id=file_id, owner=request.user)
        proc, _ = BotProcess.objects.get_or_create(file=file_obj, owner=request.user)
        env_vars = request.data.get('env_vars')
        if isinstance(env_vars, dict):
            proc.set_encrypted_env(env_vars)
        elif 'key' in request.data:
            k = str(request.data['key']).strip()
            v = str(request.data.get('value', '')).strip()
            current = proc.get_decrypted_env()
            if k:
                current[k] = v
            proc.set_encrypted_env(current)
        proc.save(update_fields=['env_vars'])
        return Response({
            'env_vars': proc.get_decrypted_env(),
            'message': "Muhit o'zgaruvchilari xavfsiz (AES-256) shifrlangan holda saqlandi!"
        })

    def delete(self, request, file_id, key=None):
        file_obj = get_object_or_404(File, id=file_id, owner=request.user)
        proc = BotProcess.objects.filter(file=file_obj, owner=request.user).first()
        if proc and key:
            current = proc.get_decrypted_env()
            if key in current:
                del current[key]
                proc.set_encrypted_env(current)
                proc.save(update_fields=['env_vars'])
        return Response({'message': f"'{key}' muvaffaqiyatli o'chirildi."})

class BotTelemetryView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, file_id):
        file_obj = get_object_or_404(File, id=file_id, owner=request.user)
        proc = BotProcess.objects.filter(file=file_obj, owner=request.user).first()
        if not proc:
            return Response({
                'status': 'stopped',
                'cpu_percent': 0.0,
                'memory_mb': 0.0,
                'max_memory_mb': 128.0,
                'cpu_limit': 0.25,
                'uptime_seconds': 0,
                'restart_count': 0,
                'auto_restart': True
            })
        from .telemetry import get_bot_telemetry
        stats = get_bot_telemetry(proc)
        return Response(stats)

class BotPipPackagesView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        from .pip_manager import POPULAR_PACKAGES, list_installed_packages
        return Response({
            'popular': POPULAR_PACKAGES,
            'installed': list_installed_packages()
        })

class BotPipInstallView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        return Response({
            'success': False,
            'error': "Xavfsizlik talablariga muvofiq, foydalanuvchilar tomonidan qo'lda paket o'rnatish butunlay to'sib qo'yilgan."
        }, status=status.HTTP_403_FORBIDDEN)
