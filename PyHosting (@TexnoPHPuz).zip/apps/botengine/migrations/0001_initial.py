
import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models

class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('filemanager', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='BotProcess',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('status', models.CharField(choices=[('stopped', "To'xtatilgan"), ('starting', 'Ishga tushirilmoqda'), ('running', 'Ishlayapti'), ('crashed', "Xatolik tufayli to'xtagan")], default='stopped', max_length=20)),
                ('container_id', models.CharField(blank=True, help_text='Docker konteyner IDsi yoki identifikator', max_length=128, null=True)),
                ('pid', models.IntegerField(blank=True, help_text='Subprocess rejimida ishlayotgan PID', null=True)),
                ('started_at', models.DateTimeField(blank=True, null=True)),
                ('stopped_at', models.DateTimeField(blank=True, null=True)),
                ('restart_count', models.IntegerField(default=0, help_text='Crash-loop himoyasi uchun qayta ishga tushish soni')),
                ('last_error', models.TextField(blank=True, null=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('file', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='processes', to='filemanager.file')),
                ('owner', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='bot_processes', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'ordering': ['-updated_at'],
            },
        ),
        migrations.CreateModel(
            name='BotLog',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('timestamp', models.DateTimeField(auto_now_add=True)),
                ('level', models.CharField(choices=[('INFO', 'Info'), ('WARNING', 'Warning'), ('ERROR', 'Error')], default='INFO', max_length=10)),
                ('log_line', models.TextField()),
                ('bot_process', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='logs', to='botengine.botprocess')),
            ],
            options={
                'ordering': ['timestamp'],
            },
        ),
    ]
